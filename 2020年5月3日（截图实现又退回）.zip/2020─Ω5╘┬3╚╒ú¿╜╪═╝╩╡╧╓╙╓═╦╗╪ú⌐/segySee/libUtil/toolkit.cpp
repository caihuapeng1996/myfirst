#include "toolkit.h"

#include <QTextCodec>

Toolkit::Toolkit()
{
}

std::string Toolkit::utf2Gbk(QString s)
{
    QTextCodec *code = QTextCodec::codecForName("GBK");
    return code->fromUnicode(s).toStdString();
}

QString Toolkit::gbk2Utf(std::string s)
{
    return "";
}
