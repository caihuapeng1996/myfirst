#ifndef TOOLKIT_H
#define TOOLKIT_H

#include <QString>
#include <iostream>

class Toolkit
{
public:
    Toolkit();

    static std::string utf2Gbk(QString s);
    QString gbk2Utf(std::string s);
};

#endif // TOOLKIT_H
