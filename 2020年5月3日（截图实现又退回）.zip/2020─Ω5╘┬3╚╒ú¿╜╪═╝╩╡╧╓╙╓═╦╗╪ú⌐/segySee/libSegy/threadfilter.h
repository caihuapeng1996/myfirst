#ifndef THREADFILTER_H
#define THREADFILTER_H

#include <QObject>
#include <QThread>
#include "segyreadwrite.h"
#include "segy.h"
#include "guidefilter2d.h"

class ThreadFilter : public QThread
{
    Q_OBJECT
public:
    QString inputFile;
    QString outputFile;
    int length_x;
    int length_t;

public:
    ThreadFilter(QString inputFile, QString outputPath, int length_x, int length_t);
    ~ThreadFilter();
    void run()override;

signals:

public slots:
};

#endif // THREADFILTER_H
