#ifndef GUIDEFILTER2D_H
#define GUIDEFILTER2D_H
#include <QObject>
#include "segy.h"

/**
 * @brief 滤波器，采用导向滤波算法。
 */
class GuideFilter2D : public QObject
{
    Q_OBJECT
    float eps;
    int length_x;
    int length_t;

    void guidedfilter2d(float **data_input, float **data_guided, float **data_output, float eps, int length_x, int length_t, int nx, int nt);
    void boxfilter2D(float **data_input,float **data_output,int nx,int nt,int length_half_t,int length_half_x);

public:
    GuideFilter2D(int length_x,int length_t,float eps=1);
    ~GuideFilter2D();
//    void filtrate(Segy* input, Segy* ouput);//接口方法
    void filtrate(Pointer_segy input, Pointer_segy ouput);//接口方法

signals:
    void showText(QString s);
    void showProgress();
};

#endif // GUIDEFILTER2D_H
