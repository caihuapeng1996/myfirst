#include "guidefilter2d.h"
#include "../libUtil/alloc.h"
#include<cstring>

void GuideFilter2D::guidedfilter2d(float **data_input,float **data_guided,float **data_output,float eps,int length_x,int length_t,int nx,int nt)
{
    float **mean_I = nullptr;
    float **mean_p = nullptr;
    float **mean_Ip = nullptr;
    float **mean_II = nullptr;
    float **Ip = nullptr;
    float **II = nullptr;
    float **cov_Ip = nullptr;
    float **var_I = nullptr;

    float **a = nullptr;
    float **b = nullptr;
    float **mean_a = nullptr;
    float **mean_b = nullptr;

    float max_I=0.0;
    float min_I=0.0;

    float max_p=0.0;
    float min_p=0.0;


//    mean_I = allocate2D(nt,nx);
//    mean_p = allocate2D(nt,nx);
//    mean_Ip = allocate2D(nt,nx);
//    mean_II = allocate2D(nt,nx);
//    Ip = allocate2D(nt,nx);
//    II = allocate2D(nt,nx);
//    cov_Ip = allocate2D(nt,nx);
//    var_I = allocate2D(nt,nx);
//    a = allocate2D(nt,nx);
//    b = allocate2D(nt,nx);
//    mean_a = allocate2D(nt,nx);
//    mean_b = allocate2D(nt,nx);

    mean_I=alloc2float(nt,nx);
    mean_p=alloc2float(nt,nx);
    mean_Ip=alloc2float(nt,nx);
    mean_II=alloc2float(nt,nx);
    Ip=alloc2float(nt,nx);
    II=alloc2float(nt,nx);
    cov_Ip=alloc2float(nt,nx);
    var_I=alloc2float(nt,nx);
    a=alloc2float(nt,nx);
    b=alloc2float(nt,nx);
    mean_a=alloc2float(nt,nx);
    mean_b=alloc2float(nt,nx);


    memset(mean_II[0],0,nt*nx*sizeof(float));
    memset(mean_I[0],0,nt*nx*sizeof(float));
    memset(mean_p[0],0,nt*nx*sizeof(float));
    memset(mean_Ip[0],0,nt*nx*sizeof(float));
    memset(Ip[0],0,nt*nx*sizeof(float));
    memset(II[0],0,nt*nx*sizeof(float));
    memset(cov_Ip[0],0,nt*nx*sizeof(float));
    memset(var_I[0],0,nt*nx*sizeof(float));

    memset(a[0],0,nt*nx*sizeof(float));
    memset(b[0],0,nt*nx*sizeof(float));
    memset(mean_a[0],0,nt*nx*sizeof(float));
    memset(mean_b[0],0,nt*nx*sizeof(float));


    max_I=data_input[0][0];
    min_I=data_input[0][0];
    max_p=data_guided[0][0];
    min_p=data_guided[0][0];

    for(int ix=0;ix<nx;ix++)
    {
        emit showProgress();
         for(int it=0;it<nt;it++){
            if(max_I<data_input[ix][it]){
                max_I=data_input[ix][it];
            }

            if(min_I>data_input[ix][it]){
                min_I=data_input[ix][it];
            }
            if(max_p<data_guided[ix][it]){
                max_p=data_guided[ix][it];
            }
            if(min_p>data_guided[ix][it]){
                min_p=data_guided[ix][it];
            }
        }
    }


    for(int ix=0;ix<nx;ix++)
    {
        emit showProgress();
        for(int it=0;it<nt;it++){
            data_input[ix][it]=(data_input[ix][it]-min_I)/(max_I-min_I);
            data_guided[ix][it]=(data_guided[ix][it]-min_p)/(max_I-min_p);
        }
    }

    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
            Ip[ix][it]=data_input[ix][it]*data_guided[ix][it];
            II[ix][it]=data_input[ix][it]*data_input[ix][it];
        }
    }

    boxfilter2D(data_input,mean_I,nx,nt,length_t,length_x);
    boxfilter2D(data_guided,mean_p,nx,nt,length_t,length_x);
    boxfilter2D(II,mean_II,nx,nt,length_t,length_x);
    boxfilter2D(Ip,mean_Ip,nx,nt,length_t,length_x);


    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
            cov_Ip[ix][it]=mean_Ip[ix][it]-mean_I[ix][it]*mean_p[ix][it];
            var_I[ix][it]=mean_II[ix][it]-mean_I[ix][it]*mean_I[ix][it];
        }
    }

    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
            a[ix][it]=cov_Ip[ix][it]/(eps+var_I[ix][it]);
            b[ix][it]=mean_p[ix][it]-a[ix][it]*mean_I[ix][it];
        }
    }

    boxfilter2D(a,mean_a,nx,nt,length_t,length_x);
    boxfilter2D(b,mean_b,nx,nt,length_t,length_x);

    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
          data_output[ix][it]=a[ix][it]*data_input[ix][it]+b[ix][it];
        }
    }

    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
          data_output[ix][it]=a[ix][it]*data_input[ix][it]+b[ix][it];
        }
    }

    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
          data_output[ix][it]=(a[ix][it]*data_input[ix][it]+b[ix][it])*(max_I-min_I)+min_I;
        }
    }

    /*for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
          data_output[ix][it]=10*abs(data_input[ix][it]-data_output[ix][it])+data_output[ix][it];
        }
    }*/

    free2float(mean_I);
    free2float(mean_p);
    free2float(mean_Ip);
    free2float(mean_II);
    free2float(Ip);
    free2float(II);
    free2float(cov_Ip);
    free2float(var_I);
    free2float(a);
    free2float(b);
    free2float(mean_a);
    free2float(mean_b);

//    free2D(mean_I,nx);
//    free2D(mean_p,nx);
//    free2D(mean_Ip,nx);
//    free2D(mean_II,nx);
//    free2D(Ip,nx);
//    free2D(II,nx);
//    free2D(cov_Ip,nx);
//    free2D(var_I,nx);
//    free2D(a,nx);
//    free2D(b,nx);
//    free2D(mean_a,nx);
//    free2D(mean_b,nx);

}

void GuideFilter2D::boxfilter2D(float **data_input, float **data_output, int nx, int nt, int length_half_t, int length_half_x)
{
    float sum=0.0;
    int index_x=0;
    int index_t=0;
    int N_w=(2*length_half_t+1)*(2*length_half_x+1);

    for(int ix=0;ix<nx;ix++){
        emit showProgress();
        for(int it=0;it<nt;it++){
            sum=0.0;
            for(int iw_x=-length_half_x;iw_x<=length_half_x;iw_x++){
                for(int iw_t=-length_half_t;iw_t<=length_half_t;iw_t++){
                    index_t=it+iw_t;
                    index_x=ix+iw_x;
                    if(index_t<=0){
                        index_t=0;
                    }

                    if(index_x<=0){
                        index_x=0;
                    }
                    if(index_t>=nt-1){
                        index_t=nt-1;
                    }
                    if(index_x>=nx-1){
                        index_x=nx-1;
                    }
                    sum=sum+data_input[index_x][index_t];
                }
            }

            data_output[ix][it]=sum/N_w;
        }
    }
}

GuideFilter2D::GuideFilter2D(int length_x, int length_t, float eps)
{
    this->eps = eps;
    this->length_x = length_x;
    this->length_t = length_t;
}

GuideFilter2D::~GuideFilter2D()
{
    //非构造方法中自己动态分配的指针空间，不要释放。
}

void GuideFilter2D::filtrate(Pointer_segy input, Pointer_segy output)
{
    float **data_input = input->traceData;
    float **data_output = output->traceData;
    int nt = input->sampleCount;
    int nx = input->traceCount;

    float **data_guide = allocate2DFrom(nt,nx,data_input);
    guidedfilter2d(data_input,data_guide,data_output,eps,length_x,length_t,nx,nt);

    free2D(data_guide,nx);
}
