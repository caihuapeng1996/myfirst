#include "threadfilter.h"
#include "../libUtil/alloc.h"

#include <QRegularExpression>
#include <QDebug>

ThreadFilter::ThreadFilter(QString inputFile, QString outputPath,int length_x, int length_t)
{
    this-> inputFile = inputFile;
    int t = inputFile.indexOf(QRegularExpression("/[^/]+$"));
    this-> outputFile = outputPath+"new_"+inputFile.mid(t+1);
    this->length_x = length_x;
    this->length_t = length_t;
}

ThreadFilter::~ThreadFilter()
{
}

void ThreadFilter::run()
{
//    //读
//    SegyReadWrite srw(inputFile);

//    //滤波
//    Segy output(*srw.segy);
//    GuideFilter2D gf(length_x,length_t);
////    gf.filtrate(srw.getSegy(),&output);
//    gf.filtrate(srw.getSegy(),&output);

//    //写
//    srw.writeSegy(outputFile,&output);
}
