#include "segyreadwrite.h"
#include <iostream>
#include <fstream>

#include <QTextCodec>
#include <QDebug>

QString SegyReadWrite::getInputFile() const
{
    return inputFile;
}

int SegyReadWrite::getDataType() const
{
    return dataType;
}

int SegyReadWrite::getSamplePerTrace() const
{
    return samplePerTrace;
}

int SegyReadWrite::getTraceCount() const
{
    return traceCount;
}

int SegyReadWrite::getInterval() const
{
    return interval;
}

long long SegyReadWrite::getFileSize() const
{
    return fileSize;
}

long long SegyReadWrite::getLineSize() const
{
    return lineSize;
}

long long SegyReadWrite::getTraceSize() const
{
    return traceSize;
}

int SegyReadWrite::getTracePerLine() const
{
    return tracePerLine;
}

int SegyReadWrite::getInlineCount() const
{
    return inlineCount;
}

int SegyReadWrite::getXlineBegin() const
{
    return xlineBegin;
}

int SegyReadWrite::getXlineEnd() const
{
    return xlineEnd;
}

int SegyReadWrite::getInlineBegin() const
{
    return inlineBegin;
}

int SegyReadWrite::getInlineEnd() const
{
    return inlineEnd;
}

int SegyReadWrite::getTimeBegin() const
{
    return timeBegin;
}

int SegyReadWrite::getTimeEnd() const
{
    return timeEnd;
}

SegyReadWrite::SegyReadWrite()
{
    segy_physic = nullptr;
    EBCDIC_logic = nullptr;
    binaryHead_logic = nullptr;
    traceHead_logic = nullptr;
    traceData_logic = nullptr;
}

SegyReadWrite::SegyReadWrite(QString inputFile)
{
    this->inputFile = inputFile;
    segy_physic = nullptr;
    EBCDIC_logic = nullptr;
    binaryHead_logic = nullptr;
    traceHead_logic = nullptr;
    traceData_logic = nullptr;

    readSegy(inputFile);
}

/**
 * @brief SegyReadWrite::SegyReadWrite
 * 拷贝构造函数
 * @param origin
 */
SegyReadWrite::SegyReadWrite(const SegyReadWrite &origin)
{
    this->inputFile = origin.inputFile;
    this->dataType = origin.dataType;
    this->samplePerTrace = origin.samplePerTrace;
    this->traceCount = origin.traceCount;
    this->interval = origin.interval;
    this->fileSize = origin.fileSize;
    this->lineSize = origin.lineSize;
    this->traceSize = origin.traceSize;
    this->tracePerLine = origin.tracePerLine;
    this->inlineCount = origin.inlineCount;
    this->xlineBegin = origin.xlineBegin;
    this->xlineEnd = origin.xlineEnd;
    this->inlineBegin = origin.inlineBegin;
    this->inlineEnd = origin.inlineEnd;
    this->timeBegin = origin.timeBegin;
    this->timeEnd = origin.timeEnd;
    this->is2dimension = origin.is2dimension;

    this->segy_physic = origin.segy_physic;
    this->EBCDIC_logic = origin.EBCDIC_logic;
    this->binaryHead_logic = origin.binaryHead_logic;
    this->traceHead_logic = new TraceHead*[origin.traceCount];
    this->traceData_logic = new float*[origin.traceCount];
//    memcpy(this->traceHead_logic,origin.traceHead_logic,origin.traceCount);
//    memcpy(this->traceData_logic,origin.traceData_logic,origin.traceCount);
    for(int i=0; i<origin.traceCount; i++)
    {
        this->traceHead_logic[i] = origin.traceHead_logic[i];
        this->traceData_logic[i] = origin.traceData_logic[i];
    }
    this->dataMin = origin.dataMin;
    this->dataMax = origin.dataMax;
    this->dataAbsMax = origin.dataAbsMax;
}

/**
 * @brief SegyReadWrite::operator =
 * 		重写赋值操作符函数
 * @param o
 * 		const修饰的右值引用
 * @return 自身对象的引用(修改自己this的属性)
 */
SegyReadWrite &SegyReadWrite::operator=(const SegyReadWrite &o)
{
    if(this != &o)
    {
        this->inputFile = o.inputFile;
        this->dataType = o.dataType;
        this->samplePerTrace = o.samplePerTrace;
        this->traceCount = o.traceCount;
        this->interval = o.interval;
        this->fileSize = o.fileSize;
        this->lineSize = o.lineSize;
        this->traceSize = o.traceSize;
        this->tracePerLine = o.tracePerLine;
        this->inlineCount = o.inlineCount;
        this->xlineBegin = o.xlineBegin;
        this->xlineEnd = o.xlineEnd;
        this->inlineBegin = o.inlineBegin;
        this->inlineEnd = o.inlineEnd;
        this->timeBegin = o.timeBegin;
        this->timeEnd = o.timeEnd;
        this->is2dimension = o.is2dimension;

        this->segy_physic = o.segy_physic;
        this->EBCDIC_logic = o.EBCDIC_logic;
        this->binaryHead_logic = o.binaryHead_logic;
        if(this->traceHead_logic != nullptr)
        {
            delete [] this->traceHead_logic;
        }
        if(this->traceData_logic != nullptr)
        {
            delete [] this->traceData_logic;
        }
        this->traceHead_logic = new TraceHead*[o.traceCount];
        this->traceData_logic = new float*[o.traceCount];
        for(int i=0; i<o.traceCount; i++)
        {
            this->traceHead_logic[i] = o.traceHead_logic[i];
            this->traceData_logic[i] = o.traceData_logic[i];
        }
        this->dataMin = o.dataMin;
        this->dataMax = o.dataMax;
        this->dataAbsMax = o.dataAbsMax;
    }
    return *this;
}

SegyReadWrite::~SegyReadWrite()
{
//    delete [] EBCDIC_logic;
//    delete [] binaryHead_logic;
    delete[] traceHead_logic;
    delete[] traceData_logic;
}

/**
 * @brief SegyReadWrite::readSegy  读取SEGY文件.
 * 		先读取部分特定值和计算出道数，再读取整个文件，并做数据类型转换。
 * 		一个SegyReadWrite实例对象可以多次读不同segy文件。
 * @param inputFile  segy文件的绝对路径
 */
void SegyReadWrite::readSegy(QString inputFile)
{
    this->inputFile = inputFile;

    std::string ipt = Toolkit::utf2Gbk(inputFile);//c++ I/O处理中的中文路径处理
    std::ifstream in(ipt,std::ifstream::binary);
    char *buffer = new char[2];

    //读取数据类型
    in.seekg(3224,in.beg);
    in.read(buffer,sizeof (short));
    short k = *reinterpret_cast<short*>(buffer);
    if(k==1 || swapShort(k)==1)
    {
        dataType = 1;
    }
    else{
        dataType = 5;
    }

    //读取采样点
    in.seekg(3220,in.beg);
    in.read(buffer,sizeof (short));
    if(dataType==1)
    {
        samplePerTrace = swapShort(*reinterpret_cast<short*>(buffer));
    }
    else {
        samplePerTrace = *reinterpret_cast<short*>(buffer);
    }

    //读取采样间隔
    in.seekg(3216,in.beg);
    in.read(buffer,sizeof (short));
    if(dataType==1)
    {
        interval = swapShort(*reinterpret_cast<short*>(buffer));
    }
    else {
        interval = *reinterpret_cast<short*>(buffer);
    }

    //计算总道数(特别是对于3D数据，直接读取道数往往不准,故要根据文件计算)
    traceSize = 240 + 4*samplePerTrace;
    in.seekg(0,in.end);
    fileSize = in.tellg();
    traceCount = (fileSize-3600)/traceSize;

    //读取数据
    delete[] buffer;
    this->segy_physic = std::make_shared<Segy>(traceCount,samplePerTrace);
    in.seekg(0,in.beg);
    in.read(this->segy_physic->EBCDIC[0],3200);
    in.read(reinterpret_cast<char*>(&segy_physic->binaryHead),400);
    for(int i=0;i<segy_physic->traceCount;i++){
        in.read(reinterpret_cast<char*>(&segy_physic->traceHead[i]),240);
        in.read(reinterpret_cast<char*>(segy_physic->traceData[i]),4*samplePerTrace);
    }
    in.close();

    //数据类型转换
    trans();

    //
    init();
}

void SegyReadWrite::writeSegy(QString outputFile, Segy* segy)
{
    //数据转换
    std::string ot = Toolkit::utf2Gbk(outputFile);
    std::ofstream out(ot,std::ofstream::binary);
    out.write(segy->EBCDIC[0],3200);
    out.write(reinterpret_cast<char*>(&segy->binaryHead),400);
    for(int i=0;i<traceCount;i++){
        out.write(reinterpret_cast<char*>(&segy->traceHead[i]),240);
        for(int j=0; j<samplePerTrace; j++){
            int temp = ieee2Ibm(segy->traceData[i][j]);
            out.write(reinterpret_cast<char*>(&temp),4);
        }
    }
    out.close();
}

/**
 * @brief SegyReadWrite::getData
 * 		获取采样点的二维数组
 * @return  二维数组
 */
float** SegyReadWrite::getData() const
{
    /* 测试roi函数  */
//    SegyReadWrite s = roi(inlineBegin,inlineEnd,xlineBegin,xlineEnd,timeBegin,timeEnd);
//    SegyReadWrite s = getInLine(inlineBegin+1);
//    SegyReadWrite s = getXLine(xlineBegin+1);
//    SegyReadWrite s = getTLine(timeBegin+2);
//    for (int i=0; i<s.inlineCount; i++) {
//        qDebug()<<s.traceData_logic[i*s.tracePerLine][0];
//        qDebug()<<s.traceData_logic[i*s.tracePerLine][1];
//        qDebug()<<s.traceData_logic[i*s.tracePerLine+s.tracePerLine-1][0];
//        qDebug()<<s.traceData_logic[i*s.tracePerLine+s.tracePerLine-1][1];
//        qDebug()<<s.traceHead_logic[i*s.tracePerLine].sx<<s.traceHead_logic[i*s.tracePerLine].sy;
//        qDebug()<<s.traceHead_logic[i*s.tracePerLine+s.tracePerLine-1].sx<<s.traceHead_logic[i*s.tracePerLine+s.tracePerLine-1].sy;
//        qDebug()<<"";
//    }
//    qDebug()<<"dataType:"<<s.dataType;
//    qDebug()<<"traceCount:"<<s.traceCount;
//    qDebug()<<"samplePerTrace:"<<s.samplePerTrace;
//    qDebug()<<"interval:"<<s.interval;
//    qDebug()<<"inlineBegin:"<<s.inlineBegin;
//    qDebug()<<"inlineEnd:"<<s.inlineEnd;
//    qDebug()<<"inlineCount:"<<s.inlineCount;
//    qDebug()<<"xlineBeg:"<<s.xlineBegin;
//    qDebug()<<"xlineEnd:"<<s.xlineEnd;
//    qDebug()<<"tracePerLine:"<<s.tracePerLine;
//    qDebug()<<"timeBegin:"<<s.timeBegin;
//    qDebug()<<"timeEnd:"<<s.timeEnd;
//    qDebug()<<"is2D:"<<s.is2D();
//    qDebug()<<"filesize:"<<s.getFileSize();
//    qDebug()<<"lineSize:"<<s.getLineSize();
//    qDebug()<<"traceSize:"<<s.getTraceSize();
//    qDebug()<<"data:min,max,absMax"<<s.dataMin<<s.dataMax<<s.dataAbsMax;
    return this->traceData_logic;

}

/**
 * @brief SegyReadWrite::getXLine
 * 		获取xline的切片
 * @param x xline值
 * @return 新的对象
 */
SegyReadWrite SegyReadWrite::getXLine(int x)
{
    return roi(inlineBegin,inlineEnd,x,x,timeBegin,timeEnd);
}

/**
 * @brief SegyReadWrite::getInLine
 * 		获取inline的切片
 * @param i inline的index
 * @return 	新的对象
 */
SegyReadWrite SegyReadWrite::getInLine(int i)
{
    return roi(i,i,xlineBegin,xlineEnd,timeBegin,timeEnd);
}

/**
 * @brief SegyReadWrite::getTline
 * 		获取time方向的切片
 * @param t 采样点的时间值（毫秒），必须是采样间隔interval(微秒)的整数倍，即t= interval/1000*n
 * @return  新的对象
 */
SegyReadWrite SegyReadWrite::getTLine(int t)
{
    return roi(inlineBegin,inlineEnd,xlineBegin,xlineEnd,t,t);
}

float SegyReadWrite::getSample(int inLine, int xLine, int time)
{
    int inline_d = tracePerLine*(inLine-inlineBegin);
    int xline_d = xLine-xlineBegin;
    int time_d = (time-timeBegin)/(interval/1000);
    return traceData_logic[inline_d+xline_d][time_d];
}

/**
 * @brief SegyReadWrite::getEBCDIC
 * 		获取EBCIC编码的文本头信息
 * @return 经转换成ASCII码的文本
 */
char *SegyReadWrite::getEBCDIC() const
{
//    return this->segy_physic->EBCDIC[0];
    return this->EBCDIC_logic;
}

/**
 * @brief SegyReadWrite::getBinaryHead
 * 		二进制头
 * @return 经转换的二进制头信息
 */
BinaryHead* SegyReadWrite::getBinaryHead() const
{
//    return this->segy_physic->binaryHead;
    return this->binaryHead_logic;
}

/**
 * @brief SegyReadWrite::getTraceHead
 * 		道头数组
 * @return 经转换后的道头数组指针
 */
TraceHead** SegyReadWrite::getTraceHead() const
{
//    return this->segy_physic->traceHead;
    return this->traceHead_logic;
}

/**
 * @brief SegyReadWrite::roi
 * 		创建感兴趣区，参考openCV的Mat类
 * @param xlineBegin	xline开始位置
 * @param xlineEnd		xline结束位置
 * @param inlineBegin	inline开始位置
 * @param inlineEnd		inline 结束位置
 * @param timeBegin		time采样点开始位置
 * @param timeEnd		time采样点结束位置
 * @return
 */
SegyReadWrite SegyReadWrite::roi(int inlineBegin, int inlineEnd, int xlineBegin, int xlineEnd, int timeBegin, int timeEnd) const
{
    //越界处理

    SegyReadWrite srw(*this);
    srw.xlineBegin = xlineBegin;
    srw.xlineEnd = xlineEnd;
    srw.inlineBegin = inlineBegin;
    srw.inlineEnd = inlineEnd;
    srw.timeBegin = timeBegin;
    srw.timeEnd = timeEnd;
    srw.tracePerLine = srw.xlineEnd-srw.xlineBegin+1;
    srw.is2dimension = srw.inlineBegin==srw.inlineEnd;
    srw.samplePerTrace = (srw.timeEnd-srw.timeBegin)*1000/this->interval+1;
    srw.inlineCount = srw.inlineEnd-srw.inlineBegin+1;
    srw.traceCount = srw.tracePerLine*srw.inlineCount;
    srw.traceSize = srw.samplePerTrace*4+240;
    srw.lineSize = srw.tracePerLine*srw.traceSize;
    srw.fileSize = 3600 + srw.lineSize*srw.inlineCount;

    //数据的处理
    delete[] srw.traceHead_logic;
    delete[] srw.traceData_logic;
    srw.traceHead_logic = new TraceHead*[srw.traceCount];
    srw.traceData_logic = new float*[srw.traceCount];
    int inline_d = (srw.inlineBegin-this->inlineBegin)*this->tracePerLine;
    int xline_d = srw.xlineBegin-this->xlineBegin;
    int time_d = (srw.timeBegin-this->timeBegin)/(interval/1000);
    int t = 0;
    for(int i=0; i<srw.inlineCount; i++)
    {
        int di = i*this->tracePerLine;
        for(int j=0; j<srw.tracePerLine; j++)
        {
//            srw.traceHead_logic[t] = srw.segy_physic->traceHead[inline_d+di+xline_d+j];
            srw.traceHead_logic[t] = &srw.segy_physic->traceHead[inline_d+di+xline_d+j];//当重新计算
            srw.traceData_logic[t++] = &srw.segy_physic->traceData[inline_d+di+xline_d+j][time_d];
        }
    }

    //最值的重新计算
    float min,max,abs_max;
    min = max = abs_max = srw.traceData_logic[0][0];
    for(int i=0; i<srw.traceCount; i++)
    {
        for(int j=0; j<srw.samplePerTrace; j++)
        {
            if(min>srw.traceData_logic[i][j])
            {
                min = srw.traceData_logic[i][j];
            }
            else if(max<srw.traceData_logic[i][j])
            {
                max = srw.traceData_logic[i][j];
            }
        }
    }
    srw.dataMin = min;
    srw.dataMax = max;
    srw.dataAbsMax = qAbs(min)>qAbs(max) ? qAbs(min): qAbs(max);

    return srw;
}

/**
 * @brief SegyReadWrite::is2D	判断segy文件是2D的还是3D的
 * @return 	true为2D，false为3D。
 */
bool SegyReadWrite::is2D()
{
    return is2dimension;
}

float SegyReadWrite::getMax() const
{
    return dataMax;
}

float SegyReadWrite::getMin() const
{
    return dataMin;
}

float SegyReadWrite::getAbsMax() const
{
    return dataAbsMax;
}

void SegyReadWrite::trans()
{
    transEBCDI();
    transBinaryHead();
    transTraceHead();
    if(dataType==1)
    {
        transTraceData();
    }
}

void SegyReadWrite::transEBCDI()
{
    for (int i=0; i<40; i++) {
        for (int j=0; j<80; j++) {
            this->segy_physic->EBCDIC[i][j] = e2a(this->segy_physic->EBCDIC[i][j]);
        }
    }
}

void SegyReadWrite::transBinaryHead()
{
    BinaryHead &bh = this->segy_physic->binaryHead;
    bh.jobid = swapFloat(bh.jobid);
    bh.lino = swapFloat(bh.lino);
    bh.reno = swapFloat(bh.reno);
    bh.ntrpr = swapShort(bh.ntrpr);
    bh.nart = swapShort(bh.nart);
    bh.hdt = swapShort(bh.hdt);
    bh.dto = swapShort(bh.dto);
    bh.hns = swapShort(bh.hns);
    bh.nso = swapShort(bh.nso);
    bh.format = swapShort(bh.format);
    bh.fold = swapShort(bh.fold);
    bh.tsort = swapShort(bh.tsort);
    bh.vscode = swapShort(bh.vscode);
    bh.hsfs = swapShort(bh.hsfs);
    bh.hsfe = swapShort(bh.hsfe);
    bh.hslen = swapShort(bh.hslen);
    bh.hstyp = swapShort(bh.hstyp);
    bh.schn = swapShort(bh.schn);
    bh.hstas = swapShort(bh.hstas);
    bh.hstae = swapShort(bh.hstae);
    bh.htatyp = swapShort(bh.htatyp);
    bh.hcorr = swapShort(bh.hcorr);
    bh.bgrcv = swapShort(bh.bgrcv);
    bh.rcvm = swapShort(bh.rcvm);
    bh.mfeet = swapShort(bh.mfeet);
    bh.polyt = swapShort(bh.polyt);
    bh.vpol = swapShort(bh.vpol);
    for (int i=0; i<170; i++) {
        bh.hunass[i] = swapShort(bh.hunass[i]);
    }
}

void SegyReadWrite::transTraceHead()
{
    for (int i=0 ; i<traceCount ; i++) {
        TraceHead &th = this->segy_physic->traceHead[i];
        th.tracl = swapFloat(th.tracl);
        th.tracr = swapFloat(th.tracr);
        th.fldr = swapFloat(th.fldr);
        th.tracf = swapFloat(th.tracf);
        th.ep = swapFloat(th.ep);
        th.cdp = swapFloat(th.cdp);
        th.cdpt = swapFloat(th.cdpt);
        th.trid = swapShort(th.trid);
        th.nvs = swapShort(th.nvs);
        th.nhs = swapShort(th.nhs);
        th.duse = swapShort(th.duse);
        th.offset = swapFloat(th.offset);
        th.gelev = swapFloat(th.gelev);
        th.selev = swapFloat(th.selev);
        th.sdepth = swapFloat(th.sdepth);
        th.gdel = swapFloat(th.gdel);
        th.sdel = swapFloat(th.sdel);
        th.swdep = swapFloat(th.swdep);
        th.gwdep = swapFloat(th.gwdep);
        th.scalel = swapShort(th.scalel);
        th.scalco = swapShort(th.scalco);
        th.sx = swapFloat(th.sx);
        th.sy = swapFloat(th.sy);
        th.gx = swapFloat(th.gx);
        th.gy = swapFloat(th.gy);
        th.counit = swapShort(th.counit);
        th.wevel = swapShort(th.wevel);
        th.swevel = swapShort(th.swevel);
        th.sut = swapShort(th.sut);
        th.gut = swapShort(th.gut);
        th.sstat = swapShort(th.sstat);
        th.gstat = swapShort(th.gstat);
        th.tstat = swapShort(th.tstat);
        th.laga = swapShort(th.laga);
        th.lagb = swapShort(th.lagb);
        th.delrt = swapShort(th.delrt);
        th.muts = swapShort(th.muts);
        th.mute = swapShort(th.mute);
        th.ns = swapShort(th.ns);
        th.dt = swapShort(th.dt);
        th.gain = swapShort(th.gain);
        th.igc = swapShort(th.igc);
        th.igi = swapShort(th.igi);
        th.corr = swapShort(th.corr);
        th.sfs = swapShort(th.sfs);
        th.sfe = swapShort(th.sfe);
        th.slen = swapShort(th.slen);
        th.styp = swapShort(th.styp);
        th.stas = swapShort(th.stas);
        th.stae = swapShort(th.stae);
        th.tatyp = swapShort(th.tatyp);
        th.afilf = swapShort(th.afilf);
        th.afils = swapShort(th.afils);
        th.nofilf = swapShort(th.nofilf);
        th.lcf = swapShort(th.lcf);
        th.hcf = swapShort(th.hcf);
        th.lcs = swapShort(th.lcs);
        th.hcs = swapShort(th.hcs);
        th.year = swapShort(th.year);
        th.day = swapShort(th.day);
        th.hour = swapShort(th.hour);
        th.minute = swapShort(th.minute);
        th.sec = swapShort(th.sec);
        th.timbas = swapShort(th.timbas);
        th.trwf = swapShort(th.trwf);
        th.grnors = swapShort(th.grnors);
        th.grnofr = swapShort(th.grnofr);
        th.grnlof = swapShort(th.grnlof);
        th.gaps = swapShort(th.gaps);
        th.otrav = swapShort(th.otrav);
        for (int i=0 ;i<30 ; i++) {
            th.unass[i] = swapShort(th.unass[i]);
        }
    }
}

/**
 * @brief SegyReadWrite::transTraceData
 * IBM float 转换到 IEEE float.并计算出采样点的最大、最小、绝对值的最大值。
 */
void SegyReadWrite::transTraceData()
{
    float min=0;
    float max =0;//初值为0可能不太合理
    for(int i=0;i<traceCount;i++){
        for(int j=0;j<samplePerTrace;j++){
            int *t = reinterpret_cast<int*>(&segy_physic->traceData[i][j]);
            float temp = ibm2Ieee(t);
            segy_physic->traceData[i][j] = temp;

            if(temp<min)
            {
                min = temp;
            }
            else if(temp>max) {
                max = temp;
            }
        }
    }

    this->dataMin = min;
    this->dataMax = max;
    this->dataAbsMax = qAbs(min)>qAbs(max) ? qAbs(min) : qAbs(max);
}

unsigned char SegyReadWrite::e2a(unsigned char c)
{
//    static unsigned char e[256] = { 0,1,2,3,156,9,134,
//127,151,141,142,11,12,13,14,15,16,17,18,19,157,133,
//8,135,24,25,146,143,28,29,30,31,128,129,130,131,132,
//10,23,27,136,137,138,139,140,5,6,7,144,145,22,147,
//148,149,150,4,152,153,154,155,20,21,158,26,32,160,
//161,162,163,164,165,166,167,168,91,46,60,40,43,33,
//38,169,170,171,172,173,174,175,176,177,93,36,42,41,
//59,94,45,47,178,179,180,181,182,183,184,185,124,44,
//37,95,62,63,186,187,188,189,190,191,192,193,194,96,
//58,35,64,39,61,34,195,97,98,99,100,101,102,103,104,
//105,196,197,198,199,200,201,202,106,107,108,109,110,
//111,112,113,114,203,204,205,206,207,208,209,126,115,
//116,117,118,119,120,121,122,210,211,212,213,214,215,
//216,217,218,219,220,221,222,223,224,225,226,227,228,
//229,230,231,123,65,66,67,68,69,70,71,72,73,232,233,
//234,235,236,237,125,74,75,76,77,78,79,80,81,82,238,
//239,240,241,242,243,92,159,83,84,85,86,87,88,89,90,
//244,245,246,247,248,249,48,49,50,51,52,53,54,55,56,
//57,250,251,252,253,254,255
//    };
    static unsigned char e[256]={
        0x00, 0x01, 0x02, 0x03, 0x85, 0x09, 0x86, 0x7f, /* 00-0f:           */
        0x87, 0x8d, 0x8e, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, /* ................ */
        0x10, 0x11, 0x12, 0x13, 0x8f, 0x0a, 0x08, 0x97, /* 10-1f:           */
        0x18, 0x19, 0x9c, 0x9d, 0x1c, 0x1d, 0x1e, 0x1f, /* ................ */
        0x80, 0x81, 0x82, 0x83, 0x84, 0x92, 0x17, 0x1b, /* 20-2f:           */
        0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x05, 0x06, 0x07, /* ................ */
        0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04, /* 30-3f:           */
        0x98, 0x99, 0x9a, 0x9b, 0x14, 0x15, 0x9e, 0x1a, /* ................ */
        0x20, 0xa0, 0xe2, 0xe4, 0xe0, 0xe1, 0xe3, 0xe5, /* 40-4f:           */
        0xe7, 0xf1, 0xa2, 0x2e, 0x3c, 0x28, 0x2b, 0x7c, /*  ...........<(+| */
        0x26, 0xe9, 0xea, 0xeb, 0xe8, 0xed, 0xee, 0xef, /* 50-5f:           */
        0xec, 0xdf, 0x21, 0x24, 0x2a, 0x29, 0x3b, 0x5e, /* &.........!$*);^ */
        0x2d, 0x2f, 0xc2, 0xc4, 0xc0, 0xc1, 0xc3, 0xc5, /* 60-6f:           */
        0xc7, 0xd1, 0xa6, 0x2c, 0x25, 0x5f, 0x3e, 0x3f, /* -/.........,%_>? */
        0xf8, 0xc9, 0xca, 0xcb, 0xc8, 0xcd, 0xce, 0xcf, /* 70-7f:           */
        0xcc, 0x60, 0x3a, 0x23, 0x40, 0x27, 0x3d, 0x22, /* .........`:#@'=" */
        0xd8, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, /* 80-8f:           */
        0x68, 0x69, 0xab, 0xbb, 0xf0, 0xfd, 0xfe, 0xb1, /* .abcdefghi...... */
        0xb0, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70, /* 90-9f:           */
        0x71, 0x72, 0xaa, 0xba, 0xe6, 0xb8, 0xc6, 0xa4, /* .jklmnopqr...... */
        0xb5, 0x7e, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, /* a0-af:           */
        0x79, 0x7a, 0xa1, 0xbf, 0xd0, 0x5b, 0xde, 0xae, /* .~stuvwxyz...[.. */
        0xac, 0xa3, 0xa5, 0xb7, 0xa9, 0xa7, 0xb6, 0xbc, /* b0-bf:           */
        0xbd, 0xbe, 0xdd, 0xa8, 0xaf, 0x5d, 0xb4, 0xd7, /* .............].. */
        0x7b, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, /* c0-cf:           */
        0x48, 0x49, 0xad, 0xf4, 0xf6, 0xf2, 0xf3, 0xf5, /* {ABCDEFGHI...... */
        0x7d, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, 0x50, /* d0-df:           */
        0x51, 0x52, 0xb9, 0xfb, 0xfc, 0xf9, 0xfa, 0xff, /* }JKLMNOPQR...... */
        0x5c, 0xf7, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, /* e0-ef:           */
        0x59, 0x5a, 0xb2, 0xd4, 0xd6, 0xd2, 0xd3, 0xd5, /* \.STUVWXYZ...... */
        0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, /* f0-ff:           */
        0x38, 0x39, 0xb3, 0xdb, 0xdc, 0xd9, 0xda, 0x9f
    };

    return e[c];
}

short SegyReadWrite::swapShort(short s)
{
    short temp = ((s & 0xff00)>>8) | ((s&0x00ff)<<8);
    return temp;
}

int SegyReadWrite::swapFloat(int i)
{
    int result;
    result = ((i & 0xff000000) >> 24) | ((i & 0x00ff0000) >> 8) | (( i & 0x0000ff00) << 8) | ((i & 0x000000ff ) << 24) ;
    return result;
}

float SegyReadWrite::ibm2Ieee(int *c)
{
    int x =  swapFloat(*c);
    int s,e,m,r;
    float result,m2;

    if(x)//特殊值：+0
    {
        s = x>>31&0x01;
        e = x>>24&0x7f;
        m = x&0x00ffffff;
        //特殊值:非数字
        if(e == 127 && (m & 0x00800000) && !(m & 0x007fffff))
        {
            r = (s<<31) | 0x7f800001;
            result = r;
            return result;
        }
        //特殊值：无穷大
        if(e>96)
        {
            r = (s<<31) | 0x7f800000;
            result = r;
            return result;
        }
        else if(e<32)//特殊值：-0
        {
            result = 0;
        }
        else{//其他情况：按公式转换
            e = e-64;
            m2 = (float)(m)/pow(2,24);
            result = (1-2*s)*m2*pow(16,e);
        }
        return result;
    }
    result = x;
    return  result;
}

int SegyReadWrite::ieee2Ibm(float f)
{
    int s,e,m;
    int result = *(reinterpret_cast<int*>(&f));
    s = result>>31 & 0x01;
    e = result >> 23 & 0xff;
    m = 0x007fffff & result;
    if(e == 255 && m)
    {
        result = (s<<31) | 0x7f800000;
        return result;
    }
    else if(e == 255 && ! m)
    {
        result = (s << 31) & 0x7f000000;
        return result;
    }
    if(result)
    {
        m = m | 0x00800000;
        e -=126;
        while(e & 0x3){
            e++;
            m >>=1;
        }
        e = (e>>2)+64;
        result = (s<<31) | (e<<24) |m;
    }
    return swapFloat(result);
}

/**
 * @brief SegyReadWrite::init
 * 		根据文件信息，计算其余重要属性，完成逻辑存储的分配与映射
 */
void SegyReadWrite::init()
{
    inlineBegin = segy_physic->traceHead[0].fldr;
    inlineEnd = segy_physic->traceHead[traceCount-1].fldr;
    inlineCount = inlineEnd-inlineBegin+1;
    is2dimension = inlineBegin==inlineEnd;
    lineSize = (fileSize-3600)/inlineCount;

    tracePerLine = lineSize/traceSize;
    xlineBegin = segy_physic->traceHead[0].tracf;
    xlineEnd = xlineBegin+tracePerLine-1;

    timeBegin = segy_physic->traceHead[0].delrt;
    timeEnd = timeBegin + interval*(samplePerTrace-1)/1000;

    //逻辑映射物理,注意只析构一层
    if(traceHead_logic != nullptr)
    {
        delete [] traceHead_logic;
    }
    if(traceData_logic != nullptr)
    {
        delete[] traceData_logic;
    }
//    EBCDIC_logic = (char**)this->segy_physic->EBCDIC;
    EBCDIC_logic = reinterpret_cast<char*>(this->segy_physic->EBCDIC);
    binaryHead_logic = &this->segy_physic->binaryHead;
    traceHead_logic = new TraceHead*[traceCount];
    traceData_logic = new float*[traceCount];
    for (int i=0; i<traceCount; i++) {
        traceHead_logic[i] = &segy_physic->traceHead[i];
        traceData_logic[i] = segy_physic->traceData[i];
    }
}
