#ifndef SEGYREADWRITE_H
#define SEGYREADWRITE_H

#include "segy.h"

#include <QString>
#include "../libUtil/toolkit.h"

/**
 * @brief The SegyReadWrite class
 * 对segy类的操作，主要是读、转换、写。
 * 注意：本类的设计参考openCv中的Mat类。可以创建数据的roi。
 * 具体实现：重写拷贝构造函数、赋值运算符函数，以及对Segy使用智能指针对象。
 */
class SegyReadWrite
{
private:
    //基本属性
    QString inputFile;
    int dataType;
    int samplePerTrace;
    int traceCount;//总道数，对于2d是一条线的总道数=等于tracePerLine
    int interval;//单位.微秒（1毫秒=1000微秒）
    //
    long long fileSize;//segy文件总字节数
    long long lineSize;//线(记录）字节大小
    long long traceSize;//线中的每道的字节大小

    int inlineBegin,inlineEnd;//inline
    int inlineCount;//总线数
    int xlineBegin,xlineEnd;//xline
    int tracePerLine;//每线的总道数
    int timeBegin,timeEnd;//time采样点(时刻),单位毫秒
    //
    bool is2dimension;
    float dataMin,dataMax,dataAbsMax;//采样点的最值，便于绘图时使用
    //segy文件物理存储的一份逻辑映射,独立的.注意析构
    char *EBCDIC_logic;
    BinaryHead * binaryHead_logic;
    TraceHead **traceHead_logic;
    float** traceData_logic;
    //segy文件的一份物理存储,共享的，引用计数析构
    Pointer_segy segy_physic;

public:
    SegyReadWrite();
    SegyReadWrite(QString inputFile);
    SegyReadWrite(const SegyReadWrite& origin);
    SegyReadWrite& operator=(const SegyReadWrite& o);
    ~SegyReadWrite();

    void readSegy(QString inputFile);
    void writeSegy(QString outputFile, Segy* segy_physic);

    SegyReadWrite getXLine(int x);
    SegyReadWrite getInLine(int i);
    SegyReadWrite getTLine(int t);
    char* getEBCDIC()const;//文本头
    BinaryHead* getBinaryHead()const;//二进制卷头
    TraceHead** getTraceHead()const;//道头
    float** getData()const;//道数据
    float getSample(int inLine, int xLine, int time);
    //getter
    bool is2D();
    float getMax() const;
    float getMin() const;
    float getAbsMax() const;
    QString getInputFile() const;
    int getDataType() const;
    int getSamplePerTrace() const;
    int getTraceCount() const;
    int getInterval() const;
    long long getFileSize() const;
    long long getLineSize() const;
    long long getTraceSize() const;
    int getTracePerLine() const;
    int getInlineCount() const;
    int getXlineBegin() const;
    int getXlineEnd() const;
    int getInlineBegin() const;
    int getInlineEnd() const;
    int getTimeBegin() const;
    int getTimeEnd() const;

private:
    void trans();
    void transEBCDI();
    void transBinaryHead();
    void transTraceHead();
    void transTraceData();
    unsigned char e2a(unsigned char c);
    short swapShort(short s);
    int swapFloat(int i);
    float ibm2Ieee(int* c);
    int ieee2Ibm(float f);

    void init();
    SegyReadWrite roi(int inlineBegin, int inlineEnd, int xlineBegin, int xlineEnd, int timeBegin, int timeEnd)const;

};

#endif // SEGYREADWRITE_H
