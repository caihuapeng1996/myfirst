#include "basemapwidget.h"
#include "ui_basemapwidget.h"
#include <QHBoxLayout>
#include "tracegraphicsitem.h"
#include "basemapview.h"
#include <QDebug>
#include <QObjectList>

BaseMapWidget::BaseMapWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BaseMapWidget)
{
    ui->setupUi(this);

    ui->graphicsView->setRenderHint(QPainter::Antialiasing,true);
//    view->setDragMode(QGraphicsView::RubberBandDrag);
//    view->setOptimizationFlags(QGraphicsView::DontSavePainterState);
//    view->setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);
//    view->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);

//    scene = new QGraphicsScene;
//    ui->graphicsView->setScene(scene);
    connect(ui->graphicsView,SIGNAL(toggleProfile(int,int)),this,SLOT(toggleProf(int,int)));
}

void BaseMapWidget::paintBaseMap(const SegyReadWrite &s)
{
    this->srw = s;
    //
    int inline_interval = s.getInlineEnd()-s.getInlineBegin();
    inline_d = inline_interval/10;
    ui->spBox_inline->setRange(inline_interval/10,inline_interval/2);
    ui->spBox_inline->setSingleStep(inline_interval/10);

    int xline_interval = s.getXlineEnd()-s.getXlineBegin();
    xline_d = xline_interval/10;
    ui->spBox_xline->setRange(xline_interval/10, xline_interval/2);
    ui->spBox_xline->setSingleStep(xline_interval/10);

    int tline_interval = s.getTimeEnd()-s.getTimeBegin();
    tline_d = tline_interval/10;
    ui->spBox_tline->setRange(tline_interval/10,tline_interval/2);
    ui->spBox_tline->setSingleStep(tline_interval/10);

    if(scene != nullptr)
    {
        delete scene;
        scene = nullptr;
    }
    scene = new QGraphicsScene;
    ui->graphicsView->setScene(scene);
    ui->graphicsView->resetMatrix();
    paintMap();
}

void BaseMapWidget::paintCoordinate(int width, int height)
{
    //标尺Y，左边
    QLineF line_y = QLineF(0,height/2,0,-height/2-10);
    QLineF line_y_l = QLineF(-5,5,0,0);
    QLineF line_y_r = QLineF(5,5,0,0);
    QGraphicsItem *yItem_left = new QGraphicsLineItem(line_y);
    yItem_left->setPos(-width/2,0);
    QGraphicsItem *yItem_l = new QGraphicsLineItem(line_y_l,yItem_left);
    yItem_l->setPos(0,-height/2-10);
    QGraphicsItem *yItem_r = new QGraphicsLineItem(line_y_r,yItem_left);
    yItem_r->setPos(0,-height/2-10);
    //标尺Y，右边
    QLineF line_y_right = QLineF(0,height/2,0,-height/2);
    QGraphicsItem *yItem_right = new QGraphicsLineItem(line_y_right);
    yItem_right->setPos(width/2,0);

    //标尺X，下面
    QLineF line_x = QLineF(-width/2,0,width/2+10,0);
    QLineF line_x_l = QLineF(-5,-5,0,0);
    QLineF line_x_r = QLineF(-5,5,0,0);
    QGraphicsItem *xItem_bottom = new QGraphicsLineItem(line_x);
    xItem_bottom->setPos(0,height/2);
    QGraphicsItem *xItem_l = new QGraphicsLineItem(line_x_l,xItem_bottom);
    xItem_l->setPos(width/2+10,0);
    QGraphicsItem *xItem_r = new QGraphicsLineItem(line_x_r,xItem_bottom);
    xItem_r->setPos(width/2+10,0);
    //标尺X，上面
    QLineF line_x_top = QLineF(-width/2,0,width/2,0);
    QGraphicsItem *xItem_top = new QGraphicsLineItem(line_x_top);
    xItem_top->setPos(0,-height/2);

    scene->addItem(yItem_left);
    scene->addItem(yItem_right);
    scene->addItem(xItem_bottom);
    scene->addItem(xItem_top);

}

void BaseMapWidget::paintRuler(const SegyReadWrite &s, int width, int height)
{
    //inline(x)轴
    //inline第一个刻度
    QGraphicsItem *item_inline_beg = new QGraphicsLineItem(0,0,0,5);
    item_inline_beg->setPos(-width/2,height/2);
    QGraphicsItem *item_inline_beg_text = new QGraphicsTextItem(QString::number(s.getInlineBegin()),item_inline_beg);
    item_inline_beg_text->setPos(-10,2);
    item_inline_beg_text->setScale(0.4);
    scene->addItem(item_inline_beg);
    //inline最后一个
    QGraphicsItem *item_inline_end = new QGraphicsLineItem(0,0,0,5);
    item_inline_end->setPos(width/2,height/2);
    QGraphicsItem *item_inline_end_text = new QGraphicsTextItem(QString::number(s.getInlineEnd())+"(inline)",item_inline_end);
    item_inline_end_text->setPos(-10,2);
    item_inline_end_text->setScale(0.4);
    scene->addItem(item_inline_end);
    //中间刻度值
    int inline_beg = s.getInlineBegin();
    int inline_end = s.getInlineEnd();
    for (int i = 0; i < ceil(1.0*(inline_end-inline_beg)/inline_d) - 1; ++i) {
        //刻度
        QGraphicsItem *item_inline = new QGraphicsLineItem(0,0,0,5);
        int inline_num = inline_beg+inline_d*(i+1);
        int x = 1.0*(inline_num-inline_beg) / (inline_end-inline_beg) * width;//inline_num映射为普通坐标
        x = x - width/2;//普通坐标映射为scene坐标
        item_inline->setPos(x,height/2);
        //刻度值
        QGraphicsItem *item_inline_text = new QGraphicsTextItem(QString::number(inline_num),item_inline);
        item_inline_text->setPos(-10,2);
        item_inline_text->setScale(0.4);
        //刻度线
        if(lineType == 0)
        {
            QGraphicsItem *item_inline_line = new QGraphicsLineItem(0,0,0,-height,item_inline);
            item_inline_line->setPos(0,0);
        }
        scene->addItem(item_inline);
    }


    //xline(x)轴
    //xline第一个刻度
    QGraphicsItem *item_xline_beg = new QGraphicsLineItem(0,0,-5,0);
    item_xline_beg->setPos(-width/2,height/2);
    QGraphicsItem *item_xline_beg_text = new QGraphicsTextItem(QString::number(s.getXlineBegin()),item_xline_beg);
    item_xline_beg_text->setPos(-20,-5);
    item_xline_beg_text->setScale(0.4);
    scene->addItem(item_xline_beg);
    //xline最后一个
    QGraphicsItem *item_xline_end = new QGraphicsLineItem(0,0,-5,0);
    item_xline_end->setPos(-width/2,-height/2);
    QGraphicsItem *item_xline_end_text = new QGraphicsTextItem("(Xline)"+QString::number(s.getXlineEnd()),item_xline_end);
    item_xline_end_text->setPos(-40,-5);
    item_xline_end_text->setScale(0.4);
    scene->addItem(item_xline_end);
    //中间刻度值
    int xline_beg = s.getXlineBegin();
    int xline_end = s.getXlineEnd();
    for (int i = 0; i < ceil(1.0*(xline_end-xline_beg)/xline_d) - 1; ++i) {
        //刻度
        QGraphicsItem *item_xline = new QGraphicsLineItem(0,0,-5,0);
        int xline_num = xline_beg+xline_d*(i+1);
        int y = 1.0*(xline_num-xline_beg) / (xline_end-xline_beg) * height;//inline_num映射为普通坐标
        y = y - height/2;//普通坐标映射为scene坐标
        item_xline->setPos(-width/2,y);
        //刻度值
        QGraphicsItem *item_xline_text = new QGraphicsTextItem(QString::number(xline_num),item_xline);
        item_xline_text->setPos(-20,-5);
        item_xline_text->setScale(0.4);
        //刻度线
        if(lineType == 1)
        {
            QGraphicsItem *item_xline_line = new QGraphicsLineItem(0,0,width,0,item_xline);
            item_xline_line->setPos(0,0);
        }
        scene->addItem(item_xline);
    }
}

void BaseMapWidget::switchLineType(int lineType)
{
    ui->lineEdit->setText("");
    delete scene;
    scene = new QGraphicsScene;
    ui->graphicsView->setScene(scene);
    ui->graphicsView->resetMatrix();

    if(lineType == 0)
    {
        inline_d = ui->spBox_inline->value();
        paintMap();
    }
    else if(lineType == 1)
    {
        xline_d = ui->spBox_xline->value();
        paintMap();
    }
    else if(lineType ==2)
    {
        tline_d = ui->spBox_tline->value();
        paintMap();

    }
}

void BaseMapWidget::toggleProf(int lineType, int num)
{
    emit toggleProfile(lineType,num);
    this->lineNum = num;
    ui->lineEdit->setText(QString::number(num));

}

void BaseMapWidget::paintEvent(QPaintEvent *event)
{
//    QPainter painter(this);
//    painter.drawRect(this->rect());
}

void BaseMapWidget::paintMap()
{
    int dx = 1;
    int dy = 1;
    int dz = 1;
    int width = dx*(srw.getInlineCount()+1);
    int height = dy*(srw.getTracePerLine()+1);
    int depth = dz*(srw.getSamplePerTrace()+1);
//    double angle = atan2(srw.getTraceHead()[srw.getTracePerLine()-1].sy-srw.getTraceHead()[0].sy , srw.getTraceHead()[srw.getTracePerLine()-1].sx-srw.getTraceHead()[0].sx);
    double angle = atan2(srw.getTraceHead()[srw.getTracePerLine()-1]->sy-srw.getTraceHead()[0]->sy , srw.getTraceHead()[srw.getTracePerLine()-1]->sx-srw.getTraceHead()[0]->sx);
    double _angle= angle*360/3.1415926;//角度制

    //inline
    if(lineType == 0)
    {
        for(int i=0; i<srw.getInlineCount(); i++)
        {
            QGraphicsItem *item = new TraceGraphicsItem(height,0,i+srw.getInlineBegin());
            item->setRotation(_angle);
            item->setPos(-width/2+i*dx,0);
            scene->addItem(item);
        }
    }

    //xline
    if(lineType == 1)
    {
        for(int i=0; i<srw.getTracePerLine(); i++)
        {
            QGraphicsItem *item = new TraceGraphicsItem(width,1,i+srw.getXlineBegin());
            item->setPos(0,-height/2+i*dy);
            item->setRotation(90);
            scene->addItem(item);
        }
    }

    if(lineType ==0 || lineType==1)
    {
        paintCoordinate(width,height);
        paintRuler(srw,width,height);
        ui->graphicsView->scale(ui->graphicsView->width()*0.8/width,ui->graphicsView->height()*0.8/height);
    }

    //tline
    if(lineType == 2)
    {
        for(int i=0; i<srw.getSamplePerTrace(); i++)
        {
            QGraphicsItem *item = new TraceGraphicsItem(30,2,i*srw.getInterval()/1000+srw.getTimeBegin());
            item->setRotation(90);
            item->setPos(0,-depth/2+i*dz);
            scene->addItem(item);
        }
        //箭头线
        QGraphicsItem *item_line = new QGraphicsLineItem(0,depth/2+15,0,-depth/2);
        scene->addItem(item_line);
        QGraphicsItem *item_line_l = new QGraphicsLineItem(-5,0,0,5,item_line);
        item_line_l->setPos(0,depth/2+10);
        QGraphicsItem *item_line_r = new QGraphicsLineItem(5,0,0,5,item_line);
        item_line_r->setPos(0,depth/2+10);

        //刻度线
        //首
        QGraphicsItem *item_tline_beg = new QGraphicsLineItem(0,0,5,0);
        item_tline_beg->setPos(0,-depth/2);
        QGraphicsItem *item_tline_beg_text = new QGraphicsTextItem(QString::number(srw.getTimeBegin())+"time",item_tline_beg);
        item_tline_beg_text->setPos(15,-5);
        item_tline_beg_text->setScale(0.4);
        scene->addItem(item_tline_beg);
        //尾
        QGraphicsItem *item_tline_end = new QGraphicsLineItem(0,0,5,0);
        item_tline_end->setPos(0,depth/2);
        QGraphicsItem *item_tline_end_text = new QGraphicsTextItem(QString::number(srw.getTimeEnd()),item_tline_end);
        item_tline_end_text->setPos(15,-5);
        item_tline_end_text->setScale(0.4);
        scene->addItem(item_tline_end);
        //中间
        int tline_beg = srw.getTimeBegin();
        int tline_end = srw.getTimeEnd();
        for(int i=0; i<ceil(1.0*(tline_end-tline_beg)/tline_d) -1; i++)
        {
            QGraphicsItem *item_tline = new QGraphicsLineItem(0,0,5,0);
            int tline_num = tline_beg+tline_d*(i+1);
            int z = 1.0*(tline_num-tline_beg) / (tline_end-tline_beg) * depth;//inline_num映射为普通坐标
            z = z - depth/2;//普通坐标映射为scene坐标
            item_tline->setPos(0,z);
            //刻度值
            QGraphicsItem *item_tline_text = new QGraphicsTextItem(QString::number(tline_num),item_tline);
            item_tline_text->setPos(15,-5);
            item_tline_text->setScale(0.4);

            scene->addItem(item_tline);
        }

        ui->graphicsView->scale(ui->graphicsView->width()*0.8/width,ui->graphicsView->height()*0.8/depth);
    }
}

void BaseMapWidget::on_spBox_inline_editingFinished()
{
    switchLineType(0);
}

void BaseMapWidget::on_spBox_xline_editingFinished()
{
    switchLineType(1);
}

void BaseMapWidget::on_cmbBox_currentIndexChanged(int index)
{
    lineType = index;
    switchLineType(index);
    if(lineType == 0)
    {
        emit toggleProfile(lineType,srw.getInlineBegin());//默认切换剖面类型时，绘制对应类型的首剖面
    }
    else if(lineType == 1)
    {
        emit toggleProfile(lineType,srw.getXlineBegin());//默认切换剖面类型时，绘制对应类型的首剖面
    }
    else if(lineType == 2)
    {
        emit toggleProfile(lineType,srw.getTimeBegin());//默认切换剖面类型时，绘制对应类型的首剖面
    }
}

void BaseMapWidget::on_pBtn_sub_clicked()
{
    int num = ui->lineEdit->text().toInt();

    //越界检查
    if(num == 0)
    {
        return;
    }
    if(lineType == 0)
    {
        if(num>srw.getInlineEnd() || num<srw.getInlineBegin())
        {
            ui->lineEdit->setText(QString::number(srw.getInlineBegin()));
            return;
        }
    }
    else if(lineType ==1)
    {
        if(num>srw.getXlineEnd() || num<srw.getXlineBegin())
        {
            ui->lineEdit->setText(QString::number(srw.getXlineBegin()));
            return;
        }
    }
    else if(lineType ==2)
    {
        if(num<srw.getTimeBegin() || num>srw.getTimeEnd())
        {
            return;
        }
    }

    QList<QGraphicsItem*> list = scene->items();
    for(int i=0; i<list.count(); i++)
    {
        TraceGraphicsItem * item = dynamic_cast<TraceGraphicsItem*>(list[i]);
        if(item)
        {
            if(item->num == num)
            {
                this->lineNum = num;
                scene->selectedItems()[0]->setSelected(false);
                item->setSelected(true);
                emit toggleProfile(item->lineType,item->num);
                return;
            }
        }
    }
}

void BaseMapWidget::on_pBtn_pre_clicked()
{
    //用户没用鼠标选line时直接退出
    if(ui->lineEdit->text() == "")
    {
        return;
    }

    int newNum = lineNum -1;
    if(lineType ==0)
    {
        if(newNum<srw.getInlineBegin() || newNum>srw.getInlineEnd())
        {
            return;
        }
    }
    else if(lineType ==1)
    {
        if(newNum<srw.getXlineBegin() || newNum>srw.getXlineEnd())
        {
            return;
        }
    }
    else if(lineType ==2)
    {
        if(newNum<srw.getTimeBegin() || newNum>srw.getTimeEnd())
        {
            return;
        }
    }

    this->lineNum--;
    ui->lineEdit->setText(QString::number(lineNum));
    QList<QGraphicsItem*> list = scene->items();
    for(int i=0; i<list.count(); i++)
    {
        TraceGraphicsItem * item = dynamic_cast<TraceGraphicsItem*>(list[i]);
        if(item)
        {
            if(item->num == lineNum)
            {
                scene->selectedItems()[0]->setSelected(false);
                item->setSelected(true);
                emit toggleProfile(item->lineType,item->num);
                return;
            }
        }
    }
}

void BaseMapWidget::on_pBtn_next_clicked()
{
    //用户没用鼠标选line时直接退出
    if(ui->lineEdit->text() == "")
    {
        return;
    }

    int newNum = lineNum +1;
    if(lineType ==0)
    {
        if(newNum<srw.getInlineBegin() || newNum>srw.getInlineEnd())
        {
            return;
        }
    }
    else if(lineType ==1)
    {
        if(newNum<srw.getXlineBegin() || newNum>srw.getXlineEnd())
        {
            return;
        }
    }
    else if(lineType ==2)
    {
        if(newNum<srw.getTimeBegin() || newNum>srw.getTimeEnd())
        {
            return;
        }
    }

    this->lineNum ++;
    ui->lineEdit->setText(QString::number(lineNum));
    QList<QGraphicsItem*> list = scene->items();
    for(int i=0; i<list.count(); i++)
    {
        TraceGraphicsItem * item = dynamic_cast<TraceGraphicsItem*>(list[i]);
        if(item)
        {
            if(item->num == lineNum)
            {
                scene->selectedItems()[0]->setSelected(false);
                item->setSelected(true);
                emit toggleProfile(item->lineType,item->num);
                return;
            }
        }
    }
}

void BaseMapWidget::on_spBox_tline_editingFinished()
{
    switchLineType(2);
}
