#include "basemapview.h"

#include <QMouseEvent>
#include "tracegraphicsitem.h"
#include <QDebug>

BaseMapView::BaseMapView(QWidget *parent)
{
    this->setParent(parent);

}

void BaseMapView::mousePressEvent(QMouseEvent *event)
{
    QGraphicsView::mousePressEvent(event);
    if(QGraphicsItem *item = itemAt(event->pos()))
    {
        if(TraceGraphicsItem *ti = dynamic_cast<TraceGraphicsItem*>(item))
        {
            emit toggleProfile(ti->lineType,ti->num);
        }
    }

}
