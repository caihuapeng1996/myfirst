#ifndef TRACEGRAPHICSITEM_H
#define TRACEGRAPHICSITEM_H

#include <QGraphicsItem>

class TraceGraphicsItem : public QGraphicsItem
{
    int length;//长度
public:
    int lineType;//0位inline，1为xline,2为tline
    int num;//所在序号

public:
    TraceGraphicsItem(int length, int lineType, int num);

    QRectF boundingRect() const override;
    QPainterPath shape() const override;//用于碰撞检测
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
};

#endif // TRACEGRAPHICSITEM_H
