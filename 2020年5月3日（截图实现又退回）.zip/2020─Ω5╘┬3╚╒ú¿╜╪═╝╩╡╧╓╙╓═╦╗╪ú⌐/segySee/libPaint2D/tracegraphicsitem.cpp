#include "tracegraphicsitem.h"

#include <QPainter>
#include <QPen>
#include <QStyleOptionGraphicsItem>
#include <QDebug>

TraceGraphicsItem::TraceGraphicsItem(int length, int lineType, int num)
{
    this->length = length;
    this->lineType = lineType;
    this->num = num;

    setFlags(QGraphicsItem::ItemIsFocusable | QGraphicsItem::ItemIsSelectable);
    setAcceptHoverEvents(true);
}

QRectF TraceGraphicsItem::boundingRect() const
{
    int adjust = 1;
    return QRectF(-1,-length/2-adjust,3,length+2*adjust);
}

QPainterPath TraceGraphicsItem::shape() const
{
    QPainterPath path;
    path.addRect(-1,-length/2-1,3,length+2*2);
    return path;
}

void TraceGraphicsItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget);

    QPen oldPen = painter->pen();
    painter->setPen(QColor(255,255,255));
    if(option->state & QStyle::State_Selected)
    {
        painter->setPen(QColor(255,0,0));
    }
    painter->drawLine(0,-length/2,0,length/2);
    painter->setPen(oldPen);

}

void TraceGraphicsItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsItem::mousePressEvent(event);
    update();
}

void TraceGraphicsItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsItem::mouseReleaseEvent(event);
    update();
}
