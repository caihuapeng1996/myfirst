#include "imagelabel.h"
#include "paint2dform.h"
#include "ui_paint2dform.h"
#include "waveitem.h"

#include <QFileDialog>
#include <QDebug>
#include <QPainter>
#include <QMouseEvent>
#include <QScrollBar>
#include <QColorDialog>
#include <QPixmap>
#include <QGraphicsItem>
#include <QSvgGenerator>
#include <QGraphicsSvgItem>
#include <QtConcurrent>

Paint2DForm::Paint2DForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Paint2DForm)
{
    ui->setupUi(this);

    originData = nullptr;
    m_oscillogram = nullptr;
    m_density = nullptr;
//    m_topRuler = nullptr;
//    m_leftRuler = nullptr;

    mapType = -1;
    needRepaint = false;
    k = 1;//默认图像大小显示适应窗口

//    connect(ui->label_image,&ImageLabel::selectRect,this,&Paint2DForm::zoomByRect);
    setPalette(QPalette(Qt::white));
    setAutoFillBackground(true);
}

Paint2DForm::~Paint2DForm()
{
    delete ui;
    delete m_oscillogram;
    delete m_density;
//    delete m_topRuler;
//    delete m_leftRuler;
}

void Paint2DForm::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    this->viewRect = ui->scrollArea->geometry();
    initImageRect = imageRect = ui->graphicsView->geometry();
}

void Paint2DForm::openSGY(const SegyReadWrite& s, int lineType, int mapType, int presetColor)
{
    srw = s;
//    srw = s.getInLine(s.getInlineBegin()+s.getInlineCount()/2);
//    srw = s.getXLine(s.getXlineBegin()+s.getTracePerLine()/2);
//    srw = s.getTLine(s.getTimeBegin()+(s.getTimeEnd()-s.getTimeBegin())/2);
    //处理绘制数据,计算最值
    originData = srw.getData();
    seis_data_min = srw.getMin();
    seis_data_max = srw.getMax();
    max_abs = srw.getAbsMax();

    dataType = srw.getDataType();
    if(lineType == 0)
    {
        ncut = srw.getTracePerLine();//绘制inline剖面
        nt = srw.getSamplePerTrace();//绘制inline、xline
    }
    else if(lineType ==1)
    {
        ncut = srw.getInlineCount();//绘制xline剖面
        nt = srw.getSamplePerTrace();//绘制inline、xline
    }
    else if(lineType ==2)
    {
        ncut = srw.getInlineCount();
        nt = srw.getTracePerLine();//绘制tline剖面
    }
    dt = srw.getInterval()/1000;
    beginTime = beginTime_ruler = srw.getTimeBegin();
    endTime = endTime_ruler = srw.getTimeEnd();
    beginTrace = beginTrace_ruler = srw.getInlineBegin();
    endTrace = endTrace_ruler = srw.getInlineEnd();


//    qDebug()<<"=======paint2dform::openSGY===========:";
//    qDebug()<<"dataType:"<<dataType;
//    qDebug()<<"traceCount:"<<ncut<<srw.getTraceCount();
//    qDebug()<<"sampleCount:"<<nt;
//    qDebug()<<"intervel:"<<dt<<"";

//    qDebug()<<"xlineBeg:"<<srw.getXlineBegin();
//    qDebug()<<"xlineEnd:"<<srw.getXlineEnd();
//    qDebug()<<"inlineBegin:"<<beginTrace;
//    qDebug()<<"inlineEnd:"<<endTrace;
//    qDebug()<<"timeBegin:"<<beginTime;
//    qDebug()<<"timeEnd:"<<endTime;
//    qDebug()<<"is2D:"<<srw.is2D();

//    qDebug()<<"tracePerline:"<<srw.getTracePerLine();
//    qDebug()<<"inlineCount:"<<srw.getInlineCount();
//    qDebug()<<"fileSize:"<<srw.getFileSize();
//    qDebug()<<"lineSize:"<<srw.getLineSize();
//    qDebug()<<"traceSize:"<<srw.getTraceSize();
//    qDebug()<<"dataMin,dataMax,dataAbsMax:"<<seis_data_min<<seis_data_max<<max_abs;


    //初始绘图区尺寸
//    initImageRect = imageRect = ui->label_image->frameGeometry();
    //每次打开要绘制的文件,都需要重新绘制标尺、图像，且默认绘制波形图
//    mapType = 1;
    this->lineType = lineType;
    this->mapType = mapType;
    setColorList(presetColor);
    needRepaint = true;

    update();
}

void Paint2DForm::swithImage(int i)
{
    mapType = i;
    needRepaint = true;
    update();
}

void Paint2DForm::changeColor(int i)
{
    setColorList(i);
    needRepaint = true;
    update();
}

void Paint2DForm::paintEvent(QPaintEvent *event)
{
    if(needRepaint)
    {
        if(mapType == -1)
        {
            return;
        }
        else if(mapType == 0)
        {
            delete m_density;
            m_density = nullptr;
            paintDensity(event);
        }
        else
        {
            paintWave(event);
        }
        needRepaint = false;
    }

    //刻度尺
//    if(m_topRuler != nullptr || m_leftRuler != nullptr)
//    {
//        delete m_topRuler;
//        delete m_leftRuler;
//    }
//    paintRuler(event);

}

/**
 * @brief Paint2DForm::paintWave
 * @param event
 * @param MapType 波形图类型:1为波形正极性填充图，2为波形负极性填充图，3为正极性填充图,4为负极性填充图，5为波形图
 *绘制波形图
 *关键是：
 *	1)相邻道、采样点的像素间隔
 *	2)绘制每道时，相邻两采样点的关系（>0、<0、=0）,共3*3=9种。
 */
void Paint2DForm::paintWave(QPaintEvent *event)
{
    qDebug()<<"paint_wave";

    if(scene != nullptr)
    {
        delete scene;
        scene = nullptr;
    }
    scene = new QGraphicsScene;

    generateScene();

    ui->graphicsView->resetMatrix();
    ui->graphicsView->setScene(scene);

//    watcher = new QFutureWatcher<QGraphicsScene*>;
//    connect(watcher,SIGNAL(finished()), this, SLOT(sceneFinished()));
//    QFuture<QGraphicsScene*> future = QtConcurrent::run(this, &Paint2DForm::generateScene, ncut, nt, originData, max_abs, scene);
//    watcher->setFuture(future);

    //适应QGraphicsView
//    qreal sw = 1;
//    qreal sh = 1;
//    qreal width = ui->graphicsView->scene()->width();
//    qreal height = ui->graphicsView->scene()->height();
//    if(width > imageRect.width())
//    {
//        sw = 1.0*(imageRect.width()-5)/width;
//    }
//    if(height > imageRect.height())
//    {
//        sh = 1.0*(imageRect.height()-5)/height;
//    }
//    ui->graphicsView->scale(sw,sh);

}

/**
 * @brief Paint2DForm::paintDensity	绘制变面积图
 * @param event
 * 重点：振幅值——（映射）——>颜色索引
 * 归一化处理：f(x)=(x-min)/(max-min)，0<=f(x)<=1
 */
void Paint2DForm::paintDensity(QPaintEvent *event)
{
    qDebug()<<"paint_density";
    m_density = new QImage(ncut,nt,QImage::Format_RGB32);
    for(int i=0; i<ncut; i++)
    {
        for(int j=0;j<nt;j++)
        {
            float cons =2;//色彩补偿。值越大，颜色越浓
            int index = 100*(cons*originData[i][j]-seis_data_min)/(seis_data_max-seis_data_min);
            if(index<0)index=0;
            if(index>99)index=99;
            m_density->setPixel(i,j,colorList[index]);
        }
    }

    //QGraphicsPixmapItem
    if(scene != nullptr)
    {
        delete scene;
        scene = nullptr;
    }
    scene = new QGraphicsScene;
    QGraphicsPixmapItem * pixItem = new QGraphicsPixmapItem(QPixmap::fromImage(*m_density));
    pixItem->setTransformationMode(Qt::SmoothTransformation);
    scene->addItem(pixItem);
    ui->graphicsView->setScene(scene);
    ui->graphicsView->resetMatrix();

    //适应QGraphicsView
    qreal sw = 1;
    qreal sh = 1;
    if(m_density->width() > imageRect.width())
    {
        sw = 1.0*(imageRect.width()-5)/m_density->width();
    }
    if(m_density->height() > imageRect.height())
    {
        sh = 1.0*(imageRect.height()-5)/m_density->height();
    }
    ui->graphicsView->scale(sw,sh);

}

void Paint2DForm::paintRuler(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);
    QRect hr = ui->horizontalSpacer->geometry();

    //  绘制时间纵标轴（左边）,分10个刻度
    QRect leftRect(0,hr.bottom(),hr.width(),viewRect.height());
    QLocale qvariant;
    for(int i=0;i<10;i++)
    {
        int tmp=beginTime_ruler+i*(endTime_ruler-beginTime_ruler)/9;
        QString string = qvariant.toString(tmp);
        int y = hr.bottom()+leftRect.height()/9.0*i;
        int x = leftRect.right();
        if(i == 0)
        {
            painter.setPen(Qt::blue);
            painter.drawLine(x,y,x-5,y);
            painter.setPen(Qt::black);
            painter.drawText(x-45,y,40,15,Qt::AlignRight,("(ms)")+string);//text宽、高：40、15

        }
        else if(i == 9)
        {
            painter.setPen(Qt::blue);
            painter.drawLine(x,y,x-5,y);
            painter.setPen(Qt::black);
            painter.drawText(x-45,y-15,40,15,Qt::AlignTop,string);//text宽、高：40、15

        }
        else
        {
            painter.setPen(Qt::blue);
            painter.drawLine(x,y,x-5,y);
            painter.setPen(Qt::black);
            painter.drawText(x-45,y-8,40,15,Qt::AlignRight,string);//text宽、高：40、15

        }
    }

    //绘制道数横坐标（上边）,分10个刻度
    QRect topRect(hr.right(),0,viewRect.width(),hr.height());
    for(int i=0;i<10;i++)
    {
        int tmp=beginTrace_ruler+i*(endTrace_ruler-beginTrace_ruler)/9;
        QString string = qvariant.toString(tmp);
        int x = hr.right()+topRect.width()*i/9.0;
        int y = topRect.bottom();
        if(i == 0)
        {
            painter.setPen(Qt::blue);//画笔颜色
            painter.drawLine(x,y,x,y-5);
            painter.setPen(Qt::black);
            painter.drawText(x,y-20,100,15,Qt::AlignLeft,string+tr("(trace)"));
        }
        else if(i == 9)
        {
            painter.setPen(Qt::blue);//画笔颜色
            painter.drawLine(x-1,y,x-1,y-5);
            painter.setPen(Qt::black);
            painter.drawText(x-40,y-20,40,15,Qt::AlignCenter,string);
        }
        else
        {
            painter.setPen(Qt::blue);//画笔颜色
            painter.drawLine(x,y,x,y-5);
            painter.setPen(Qt::black);
            painter.drawText(x-20,y-20,40,15,Qt::AlignCenter,string);
        }
    }

    painter.end();
}

void Paint2DForm::setColorList(int i)
{
    int counts=100;
    switch(i)
    {
        //红白蓝
        case 0:
        {
            colorList.clear();
            //红(255,0,0),白(255,255,255),蓝(0,0,255)，
            for(int i =0;i<counts;i++)
            {
                if(i<=counts/2)
                {
                    colorList.append(qRgb(255,int(i*5.1),int(i*5.1)));//List中从0－50存放的是红色开始的颜色
                }
                if(i>counts/2)
                {
                    colorList.append(qRgb(255-int((i-50)*5.1),255-int((i-50)*5.1),255));//50－99存放的是黑色开始的颜色
                }
            }
            break;
        }
        //红白黑
        case 1:
        {
            colorList.clear();
            for(int i =0;i<counts;i++)
            {
                if(i<=counts/2)
                {
                    colorList.append(qRgb(255,int(i*5.1),int(i*5.1)));//List中从0－50存放的是红色开始的颜色
                }
                if(i>counts/2)
                {
                    colorList.append(qRgb(255-int((i-50)*5.1),255-int((i-50)*5.1),255-int((i-50)*5.1)));//50－99存放的是黑色开始的颜色
                }
            }
            break;
        }
        //红白黄
        case 2:
        {
            colorList.clear();
            for(int i =0;i<counts;i++)
            {
                if(i<=counts/2)
                {
                    colorList.append(qRgb(255,int(i*5.1),int(i*5.1)));//List中从0－50存放的是红色开始的颜色
                }
                if(i>counts/2)
                {
                    colorList.append(qRgb(255,255,255-int((i-50)*5.1)));//50－99存放的是黄色开始的颜色
                }
            }
            break;
        }
        //白灰黑
        case 3:
        {
            colorList.clear();
            for(int i =0;i<counts;i++)
            {
                if(i<=counts/2&&(255-i*1.2)>=192)
                {
                    colorList.append(qRgb(int(255-i*1.2),int(255-i*1.2),int(255-i*1.2)));//List中从0－50存放的是红色开始的颜色
                }
                if(i>counts/2)
                {
                    colorList.append(qRgb(192-int((i-50)*3.8),192-int((i-50)*3.8),192-int((i-50)*3.5)));//50－99存放的是黄色开始的颜色
                }
            }
            break;
        }
        //彩虹
        case 4:
        {
            colorList.clear();
            for(int i =0;i<counts;i++)
            {
                if(i<=20)
                {
                    colorList.append(qRgb(0,int(i*12.7),255));//List中从0－20存放的是蓝色开始的颜色
                }
                if(i>20&&i<=30)
                {
                    colorList.append(qRgb(0,255,255-int((i-20)*25.5)));//50－99存放的是青色开始的颜色
                }
                if(i>30&&i<=60)
                {
                    colorList.append(qRgb(int((i-30)*8.5),255,0));//50－99存放的是绿色开始的颜色
                }
                if(i>60&&i<=70)
                {
                    colorList.append(qRgb(255,255-int((i-60)*25.5),0));//50－99存放的是黄色开始的颜色
                }
                if(i>70&&i<=100)
                {
                    colorList.append(qRgb(255,0,int((i-70)*8.5)));//50－99存放的是红色开始的颜色
                }
            }
            break;
        }
        //红黄黑
        case 5:
        {
            colorList.clear();
            for(int i =0;i<counts;i++)
            {
                if(i<=25)
                {
                    colorList.append(qRgb(255,int(i*6.1),int(i*0.72)));//List中从0－25存放的是红色开始的颜色
                }
                if(i>25&&i<=50)
                {
                    colorList.append(qRgb(255,153+int((i-25)*4),18+int((i-25)*9.4)));//25－50存放的是黄色开始的颜色
                }
                if(i>50&&i<=100)
                {
                    colorList.append(qRgb(255-int((i-50)*5.1),255-int((i-50)*5.1),255-int((i-50)*5.1)));//50－99存放的是黑色开始的颜色
                }
            }
            break;
        }

    }
}

QColor Paint2DForm::changeOurColor(QString s)
{
    return QColorDialog::getColor(s);
}

void Paint2DForm::setchangecolorList()
{
    c1=changeOurColor("颜色一");
    c2=changeOurColor("颜色二");
    c3=changeOurColor("颜色三");
    colorList.clear();

    insertColor(c1,30);
    insertColor(c2,30);
    insertColor(c3,40);

}

void Paint2DForm::insertColor(QColor c, int number)
{
    for(int i=0;i<number;i++){
        if(c.red()>c.green()){
            if(c.red()>c.blue()){
                colorList.append(qRgb(c.red(),(((c.green()+i*0.25)>255)?255:(c.green()+i*0.25)),(((c.blue()+i*0.25)>255)?255:(c.blue()+i*0.25))));
            }else if(c.red()<c.blue()){
                colorList.append(qRgb((((c.red()+i*0.25)>255)?255:(c.red()+i*0.25)),(((c.green()+i*0.25)>255)?255:(c.green()+i*0.25)),c.blue()));
            }else if(c.red()==c.blue()){
                colorList.append(qRgb(c.red(),(((c.green()+i*0.25)>255)?255:(c.green()+i*0.25)),c.blue()));
            }
        }else if(c.red()<c.green()){
            if(c.green()>c.blue()){
                colorList.append(qRgb((((c.red()+i*0.25)>255)?255:(c.red()+i*0.25)),c.green(),(((c.blue()+i*0.25)>255)?:255,(c.blue()+i*0.25))));
            }else if(c.green()==c.blue()){
                colorList.append(qRgb((((c.red()+i*0.25)>255)?255:(c.red()+i*0.25)),c.green(),c.blue()));
            }else if(c.green()<c.blue()){
                colorList.append(qRgb((((c.red()+i*0.25)>255)?255:(c.red()+i*0.25)),(((c.green()+i*0.25)>255)?255:(c.green()+i*0.25)),c.blue()));
            }
        }else if(c.red()==c.green()){
            colorList.append(qRgb(c.red(),c.green(),(((c.blue()+i*0.25)>255)?255:(c.blue()+i*0.25))));
        }else if(c.red()<c.blue()){
            colorList.append(qRgb(((c.red()+i*0.25)>255)?255:(c.red()+i*0.25),(((c.green()+i*0.25)>255)?255:(c.green()+i*0.25)),c.blue()));
        }else if(c.red()==c.blue()){
            colorList.append(qRgb((c.red()+i*0.25)>255?255:(c.red()+i*0.25),(c.green()+i*0.25)>255?255:(c.green()+i*0.25),(c.blue()+i*0.25)>255?255:(c.blue()+i*0.25)));
        }
    }
}


/**
 * @brief Paint2DForm::generateScene
 * @param ncut
 * @param nt
 * @param originData
 * @param max_abs
 * @param scene
 * @return
 */
QGraphicsScene* Paint2DForm::generateScene()
{
//    int lineType = 0;//0:inline,1:xline,2tline
//    int mapType =0;// 0:波形正极性图, 1:波形负极性图, 2:正极性图，3:负极性图，4:波形图
    int waveNum = 0;//从0开始
    qreal width = 8;//WaveItem的width(注：使用偶数)
    qreal timeInterval = 1;//采样点(像素)间距
    qreal traceInterval= width/2;//道(像素)间距
    qreal ampGain = width/2;//振幅增益

    for(int i=0; i<ncut; i++)
    {
        WaveItem *vItem = new WaveItem(lineType,waveNum,mapType,width,timeInterval,ampGain,originData[i],nt,max_abs);
        vItem->setPos(i*traceInterval+1,0);
//        vItem->setZValue(i);
        scene->addItem(vItem);
    }
    return scene;
}

void Paint2DForm::sceneFinished()
{
    qDebug()<<"sceneFinished";
    ui->graphicsView->resetMatrix();
//    scene = watcher->result();
    ui->graphicsView->setScene(scene);

    //适应QGraphicsView
//    qreal sw = 1;
//    qreal sh = 1;
//    qreal width = ui->graphicsView->scene()->width();
//    qreal height = ui->graphicsView->scene()->height();
//    if(width > imageRect.width())
//    {
//        sw = 1.0*(imageRect.width()-5)/width;
//    }
//    if(height > imageRect.height())
//    {
//        sh = 1.0*(imageRect.height()-5)/height;
//    }
//    ui->graphicsView->scale(0.1,0.1);

}

void Paint2DForm::zoomInOut(float i)
{
    this->k = i;
//    needRepaint = true;
//    update();
    ui->graphicsView->scale(k,k);
}

void Paint2DForm::zoomRect()
{
//    ui->label_image->needPaintRect = true;
}

void Paint2DForm::resore()
{
    this->k = 1;
    setColorList(1);
    needRepaint = true;
    update();
}

void Paint2DForm::presetColorChanged(int i)
{
    swithImage(0);
    setColorList(i);
    needRepaint = true;
    update();
}

void Paint2DForm::colorChanged()
{
    setchangecolorList();
    needRepaint = true;
    update();
}

void Paint2DForm::zoomByRect(QRect rect)
{
    ui->scrollArea->horizontalScrollBar()->setValue(rect.x());
    ui->scrollArea->verticalScrollBar()->setValue(rect.y());
}
