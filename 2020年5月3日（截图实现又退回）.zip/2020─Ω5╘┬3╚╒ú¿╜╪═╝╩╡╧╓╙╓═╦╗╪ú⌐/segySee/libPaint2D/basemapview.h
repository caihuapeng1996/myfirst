#ifndef BASEMAPVIEW_H
#define BASEMAPVIEW_H

#include <QGraphicsView>



class BaseMapView : public QGraphicsView
{
    Q_OBJECT
public:
    explicit BaseMapView(QWidget *parent = nullptr);
    void mousePressEvent(QMouseEvent *event) override;
signals:
    void toggleProfile(int type, int num);
};

#endif // BASEMAPVIEW_H
