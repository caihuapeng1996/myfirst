#include "mapview.h"

#include <QScrollBar>
#include <QWheelEvent>
#include <QtMath>

MapView::MapView(QWidget *parent)
{
    this->setParent(parent);
    setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);
    setRenderHint(QPainter::Antialiasing);

    //滚动条不跟踪
    this->horizontalScrollBar()->setTracking(false);
    this->verticalScrollBar()->setTracking(false);
}

void MapView::wheelEvent(QWheelEvent *event)
{
    if (event->modifiers() & Qt::ControlModifier) {
        qreal factor = qPow(1.2, event->delta() / 240.0);
        scale(factor, factor);
        event->accept();
    } else {
        QGraphicsView::wheelEvent(event);
    }
}
