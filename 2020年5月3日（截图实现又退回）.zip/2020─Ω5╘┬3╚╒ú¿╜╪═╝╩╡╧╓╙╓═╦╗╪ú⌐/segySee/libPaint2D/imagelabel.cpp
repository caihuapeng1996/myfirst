#include "imagelabel.h"

#include <QMouseEvent>
#include <QPainter>
#include <QDebug>
#include <QRgb>
#include <QRgb>

ImageLabel::ImageLabel(QWidget *parent) : QLabel(parent)
{
    needPaintRect = false;
    isPressed = false;
}

void ImageLabel::paintEvent(QPaintEvent *event)
{
    QLabel::paintEvent(event);//调用父类的方法，绘制的setPixmap等图像。

    if(isPressed)
    {
        QPainter painter(this);
        painter.setBrush(QBrush(QColor(0,0,0,100)));
        painter.drawRect(rect);
    }
}

void ImageLabel::mousePressEvent(QMouseEvent *event)
{
    if(!needPaintRect)
        return;
    rect.setLeft(event->x());
    rect.setTop(event->y());
}

void ImageLabel::mouseMoveEvent(QMouseEvent *event)
{
    if(!needPaintRect)
        return;

    if(!this->geometry().contains(event->pos()))//超出图片范围时，重新确定值
    {
        int x,y;

        if(event->x()<0)
        {
            x = 0;
        }
        else {
            x = this->rect.right();
        }
        if(event->y()<0)
        {
            y = 0;
        }
        else {
            y = this->rect.bottom();
        }

        rect.setRight(x);
        rect.setBottom(y);
    }
    else{
        rect.setRight(event->x());
        rect.setBottom(event->y());
    }
    isPressed = true;
    update();
//    qDebug()<<"the rect:"<<rect;
//    qDebug()<<"the rect:"<<rect.right()<<rect.bottom();
}

void ImageLabel::mouseReleaseEvent(QMouseEvent *event)
{
    if(!needPaintRect)
        return;
    isPressed = false;
    needPaintRect = false;
    emit selectRect(rect);
    update();
}
