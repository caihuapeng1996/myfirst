#ifndef IMAGELABEL_H
#define IMAGELABEL_H

#include <QLabel>
#include <QWidget>

///
/// \brief The ImageLabel class
/// 自定义QLabel
/// 重写了一些事件处理函数
///
class ImageLabel : public QLabel
{
    Q_OBJECT
public:
    bool needPaintRect;//标识是否在图像上绘制鼠标拖动产生的矩形框，默认为否，且只绘制一次
    bool isPressed;//标识鼠标左键是否按下,以便当鼠标按下拖动时即时绘制rect
    QRect rect;//鼠标拖动产生的矩形(视口)

public:
    explicit ImageLabel(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event)override;
    void mousePressEvent(QMouseEvent *event)override;
    void mouseMoveEvent(QMouseEvent *event)override;
    void mouseReleaseEvent(QMouseEvent *event)override;

signals:
    void selectRect(QRect rect);

public slots:
};

#endif // IMAGELABEL_H
