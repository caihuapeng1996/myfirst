#include "waveitem.h"

#include <QPainter>
#include <QStyleOptionGraphicsItem>
#include <QDebug>

WaveItem::WaveItem(int lineType, int waveNum, int mapType, qreal width, qreal timeInterval, qreal ampGain, float* data, int sampleCount, float max_abs)
{
    this->lineType = lineType;
    this->waveNum = waveNum;
    this->mapType = mapType;
    this->width = width;
    this->timeInterval = timeInterval;
    this->ampGain = ampGain;
    this->data = data;
    this->sampleCount = sampleCount;
    this->max_abs = max_abs;

    this->height = sampleCount*timeInterval;

    setFlags(QGraphicsItem::ItemIsFocusable | QGraphicsItem::ItemIsSelectable);
    setAcceptHoverEvents(true);

}


QRectF WaveItem::boundingRect() const
{
    return QRectF(0,0,width,height);
}

QPainterPath WaveItem::shape() const
{
    QPainterPath path;
    path.addRect(0, 0, width, height);
    return path;
}

void WaveItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setRenderHint(QPainter::Antialiasing,true);//反锯齿
    painter->setBrush(QBrush(Qt::black,Qt::SolidPattern));
    painter->setPen(QPen(Qt::black,1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin));

    //计算
    //正极性
    QVector<QPolygonF> polygons;
    //负极性
    QVector<QPolygonF> polygons_1;
    //相邻两采样点都为零
    QVector<QLineF> lines;

    //上一个采样点的像素坐标x0,y0 ,初值为道第一个采样点坐标
    double x0 = 1.0*ampGain*data[0]/max_abs;
    double y0 = 0;
    for(int j=1; j<sampleCount; j++)
    {
        double x = 1.0*ampGain*data[j]/max_abs;
        double y = j*timeInterval;
        if(x0>0)
        {
            if(x>=0)
            {
                //正极性
                if(j==1)
                {
                    QPolygonF p;
                    polygons.push_back(p);
                    polygons.last().push_back(QPointF(0,y0));
                    polygons.last().push_back(QPointF(x0,y0));
                }
                polygons.last().push_back(QPointF(x,y));
            }
            else if(x<0){
                //正极性
                if(j==1)
                {
                    QPolygonF p;
                    polygons.push_back(p);
                    polygons.last().push_back(QPointF(0,y0));
                    polygons.last().push_back(QPointF(x0,y0));
                }
                qreal yy = qAbs(x0)*(y-y0)*1.0/(qAbs(x0)+qAbs(x)) + y0;
                polygons.last().push_back(QPointF(0,yy));
                //负极性
                QPolygonF p1;
                polygons_1.push_back(p1);
                polygons_1.last().push_back(QPointF(0,yy));
                polygons_1.last().push_back(QPointF(x,y));
            }
        }
        else if(x0<0)
        {
            if(x<=0)
            {
                //负极性
                if(j==1)
                {
                    QPolygonF p1;
                    polygons_1.push_back(p1);
                    polygons_1.last().push_back(QPointF(0,y0));
                    polygons_1.last().push_back(QPointF(x0,y0));
                }
                polygons_1.last().push_back(QPointF(x,y));
            }
            else if(x>0)
            {
                //负极性
                if(j==1)
                {
                    QPolygonF p1;
                    polygons_1.push_back(p1);
                    polygons_1.last().push_back(QPointF(0,y0));
                    polygons_1.last().push_back(QPointF(x0,y0));
                }
                qreal yy = qAbs(x0)*(y-y0)*1.0/(qAbs(x0)+qAbs(x)) + y0;
                polygons_1.last().push_back(QPointF(0,yy));
                //正极性
                QPolygonF p;
                polygons.push_back(p);
                polygons.last().push_back(QPointF(0,yy));
                polygons.last().push_back(QPointF(x,y));
            }
        }
        else{
            if(x>0)
            {
                //正极性
                QPolygonF p;
                polygons.push_back(p);
                polygons.last().push_back(QPointF(x0,y0));
                polygons.last().push_back(QPointF(x,y));
            }
            else if(x<0)
            {
                //负极性
                QPolygonF p;
                polygons_1.push_back(p);
                polygons_1.last().push_back(QPointF(x0,y0));
                polygons_1.last().push_back(QPointF(x,y));
            }
            else{
                //相邻两点都为零
                if(!lines.isEmpty() && lines.last().p2() == QPointF(x0,y0))
                {
                    lines.last().setP2(QPointF(x,y));
                }
                else {
                    QLineF l(QPointF(x0,y0), QPointF(x,y));
                    lines.push_back(l);
                }
            }
        }
        x0 = x;
        y0 = y;
    }
    //闭合
    if(polygons.last().last().x() != 0)
    {
        polygons.last().push_back(QPointF(0,y0));
    }
    if(polygons_1.last().last().x() != 0)
    {
        polygons_1.last().push_back(QPointF(0,y0));
    }

    //绘制
    QPen p(Qt::black,1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin);
    if(option->state & QStyle::State_Selected)
    {
        painter->setPen(QPen(Qt::red,1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin));
    }
    painter->translate(width/2,0);
    switch (mapType) {
    case 1:{//波形+正极性
        polygons_1.first().pop_front();
        polygons_1.last().pop_back();

        for(QPolygonF p : polygons)
            painter->drawPolygon(p);
        for(QPolygonF p : polygons_1)
        {
            painter->drawPolyline(p);
        }
        painter->drawLines(lines);
    }
        break;
    case 2:{//波形+负极性
//        polygons.first().pop_front();
//        polygons.last().pop_back();
    }
        break;
    case 3:{//正极性
        for(QPolygonF p : polygons)
            painter->drawPolygon(p);
    }
        break;
    case 4:{//负极性
    }
        break;
    case 5:{//波形
//        polygons.first().pop_front();
//        polygons.last().pop_back();
//        polygons_1.first().pop_front();
//        polygons_1.last().pop_back();
    }
        break;
    }
}

void WaveItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsItem::mousePressEvent(event);
//    update();
}

void WaveItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsItem::mouseReleaseEvent(event);
//    update();
}
