#ifndef WAVEITEM_H
#define WAVEITEM_H

#include <QGraphicsItem>
#include <QObject>

class WaveItem : public QGraphicsItem
{
    int lineType;
    int waveNum;
    int mapType;
    qreal width;
    qreal timeInterval;
    qreal ampGain;
    float* data;
    int sampleCount;
    float max_abs;

    qreal height;

public:
    explicit WaveItem(int lineType, int waveNum, int mapType, qreal width, qreal timeInterval, qreal ampGain, float* data, int sampleCount, float max_abs);

protected:
    QRectF boundingRect() const override;
    QPainterPath shape() const override;//用于碰撞检测
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
};

#endif // WAVEITEM_H
