#ifndef BASEMAPWIDGET_H
#define BASEMAPWIDGET_H

#include <QWidget>
#include <QGraphicsScene>
#include "../libSegy/segyreadwrite.h"
#include "basemapview.h"

namespace Ui {
    class BaseMapWidget;
}
class BaseMapWidget : public QWidget
{
    Q_OBJECT
private:
    Ui::BaseMapWidget *ui;

    SegyReadWrite srw;
    QGraphicsScene *scene = nullptr;

    int lineType = 0;//0为inline；1为xline,2为tline
    int inline_d = 50;//inline间隔（inline数目）
    int xline_d = 50;//xline间隔（xline数目）
    int tline_d = 100;//tline间隔
    int lineNum;

public:
    explicit BaseMapWidget(QWidget *parent = nullptr);
    void paintBaseMap(const SegyReadWrite &s);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    void paintMap();
    void paintCoordinate(int width, int height);
    void paintRuler(const SegyReadWrite &s, int width, int height);
    void switchLineType(int lineType);

signals:
    void toggleProfile(int lineType, int num);

public slots:
    void toggleProf(int lineType, int num);
private slots:
    void on_spBox_inline_editingFinished();
    void on_spBox_xline_editingFinished();
    void on_cmbBox_currentIndexChanged(int index);
    void on_pBtn_sub_clicked();
    void on_pBtn_pre_clicked();
    void on_pBtn_next_clicked();
    void on_spBox_tline_editingFinished();
};

#endif // BASEMAPWIDGET_H
