#ifndef PAINT2DFORM_H
#define PAINT2DFORM_H

#include <QBitmap>
#include <QWidget>
#include <QImage>
#include <QPixmap>
#include <QLabel>
#include <QGraphicsScene>
#include <QFutureWatcher>
#include "../libSegy/segy.h"
#include "../libSegy/segyreadwrite.h"

namespace Ui {
class Paint2DForm;
}

/**
 * @brief The Paint2DForm class
 * 自定义的QWidget
 * 用来显示.sgy文件：波形面积图、变密度图
 * 并提供一些操作：如切换剖面图类型、缩放、改变色标等
 * 注意：它依赖另一个定义的继承自QLabel的ImageLabel，用来显示图像。
 */
class Paint2DForm : public QWidget
{
    Q_OBJECT
private:
    Ui::Paint2DForm *ui;
public:
    //segy文件
    SegyReadWrite srw;
    float **originData;
    float seis_data_min;
    float seis_data_max;
    float max_abs;
    int dataType;//数据类型
    int ncut;//道数
    int nt;//采样点数
    int dt;//采样间隔

    //绘图相关
    QGraphicsScene *scene = nullptr;
    QPixmap *m_oscillogram;//波形面积图
    QImage *m_density;//变面积图
//    QPixmap *m_topRuler;//上标尺
//    QPixmap *m_leftRuler;//下标尺
    QRect viewRect;//图像的滚动显示区Rect
    QRect imageRect;//图像的Rect
    QRect initImageRect;//图像初始Rect
    QColor c1,c2,c3;
    float k;
    //标尺
    int beginTime,beginTime_ruler;
    int beginTrace,beginTrace_ruler;
    int endTime,endTime_ruler;
    int endTrace,endTrace_ruler;
    //
    int lineType;
    int mapType;// 0:变密度图，1:波形正极性图, 2:波形负极性图, 3:正极性图，4:负极性图，5:波形图
    bool needRepaint;
    QList<QRgb> colorList;

//    QFutureWatcher<QGraphicsScene*> *watcher;

public:
    explicit Paint2DForm(QWidget *parent = nullptr);
    void colorChanged();

    ~Paint2DForm()override;

private:

    void resizeEvent(QResizeEvent *event)override;
    void paintEvent(QPaintEvent *event)override;
    void paintWave(QPaintEvent *event);
    void paintDensity(QPaintEvent *event);
    void paintRuler(QPaintEvent *event);
    //绘图颜色
    void setColorList(int i);
    QColor changeOurColor(QString s);
    void setchangecolorList();
    void insertColor(QColor c,int number);//填充颜色
    QGraphicsScene* generateScene();

public slots:
    void openSGY(const SegyReadWrite& s, int profileType=0, int mapType=0, int presetColor=1);
    void swithImage(int i);
    void changeColor(int i);
    void zoomInOut(float i);
    void zoomRect();
    void resore();
    void presetColorChanged(int i);//从预设色标中，切换变密度图的色标
    void sceneFinished();


private slots:
    void zoomByRect(QRect rect);

};
#endif // PAINT2DFORM_H
