#include "newproject.h"
#include "ui_newproject.h"

INewProject::INewProject(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::INewProject)
{
    ui->setupUi(this);
    setWindowTitle("新建项目");

    /***************连接信号与槽****************/
    connect(ui->Browse_pushButton,SIGNAL(clicked(bool)),this, SLOT(slot_Browse_PushButton()));//浏览
    connect(ui->OK_pushButton,    SIGNAL(clicked(bool)),this, SLOT(slot_Ok_PushButton()));//确定
    connect(ui->Cancel_pushButton,SIGNAL(clicked(bool)),this, SLOT(slot_Cancel_PushButton()));//取消
}

INewProject::~INewProject()
{
    delete ui;
}
/*
 ***************************************************
 * 函数名：Get_ProjectName()
 * 作用：获取工程名
 * 输入：无
 * 返回：QString类型工程名
 * 编写：vgGwen 18/4/26
 * 修改：
 ****************************************************
 */
QString INewProject::get_ProjectName()
{
    return qsProjectName_gv;
}

/*
 ***************************************************
 * 函数名：Get_ProjectPath()
 * 作用：获取工程路径
 * 输入：无
 * 返回：QString类型工程路径
 * 编写：vgGwen 18/4/26
 * 修改：
 ****************************************************
 */
QString INewProject::get_ProjectPath()
{
    return qsProjectPath_gv;
}

/*
 ***************************************************
 * 函数名：slot_Browse()
 * 作用：浏览按钮槽函数
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/26
 * 修改：
 ****************************************************
 */
void INewProject::slot_Browse_PushButton()
{
    QString qsPath;//用于保存选定的地址
    QFileDialog *qfdBrowse = new QFileDialog(this);//设置文件路径窗口
    qfdBrowse->setOption(QFileDialog::ShowDirsOnly);//设置属性
    qfdBrowse->setFileMode(QFileDialog::Directory);
    qfdBrowse->setViewMode(QFileDialog::List);
    /***************选定*****************/
    if(qfdBrowse->exec() == QFileDialog::Accepted)//选择该路径
    {
        qsPath = qfdBrowse->selectedFiles().at(0);//保存地址
        ui->ProjectPath_lineEdit->setText(qsPath);//显示
    }
    else//取消选择
    {
        return;
    }
    delete qfdBrowse;//内存归还
    qfdBrowse = NULL;
}

/*
 ***************************************************
 * 函数名：slot_Ok_PushButton(
 * 作用：确定按钮槽函数
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/26
 * 修改：
 ****************************************************
 */
void INewProject::slot_Ok_PushButton()
{
    qsProjectName_gv = ui->ProjectName_lineEdit->text().trimmed();//读取工程名并去除空格
    qsProjectPath_gv = ui->ProjectPath_lineEdit->text();//读取工程路径
    //判断名字是否为空
    if( !(qsProjectName_gv.isEmpty() || qsProjectPath_gv.isEmpty()) )//如果信息完整，则退出dialog
    {
        ui->ProjectName_lineEdit->clear();//关闭时清理显示信息，以便下一次打开时显示
        ui->ProjectPath_lineEdit->clear();
        INewProject::accept();//退出dialog
    }
    else
    {
        QMessageBox::information(this,tr("Tips"),tr("表格不完整，新建项目失败"),QMessageBox::tr("好的"));
    }

}

/*
 ***************************************************
 * 函数名：slot_Cancel_PushButton()
 * 作用：取消按钮槽函数
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/26
 * 修改：
 ****************************************************
 */
void INewProject::slot_Cancel_PushButton()
{
    ui->ProjectName_lineEdit->clear();//关闭时清理显示信息，以便下一次打开时显示
    ui->ProjectPath_lineEdit->clear();
    INewProject::accept();//退出dialog
}
