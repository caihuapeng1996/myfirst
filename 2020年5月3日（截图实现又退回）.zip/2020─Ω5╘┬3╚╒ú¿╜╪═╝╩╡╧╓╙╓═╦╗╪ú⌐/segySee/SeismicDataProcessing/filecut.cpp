#include "filecut.h"
#include "ui_filecut.h"
#include <sys/stat.h>
#include <fstream>
#include <vector>
#include <iostream>

#include "json.h"
#include "filecut.h"
#include "ui_filecut.h"
using json = nlohmann::json;

    const string filecut::kSegmentFileNum = "SegmentNum";
    const string filecut::kSourceFileName = "SourceFileName";
    const string filecut::kSegmentFiles = "SegmentFiles";
    const int filecut::kBlockSize = 1024*1024;//1MB

filecut::filecut(QMainWindow *parent) :
//    QMainWindow(parent),
    ui(new Ui::filecut)
{
    ui->setupUi(this);
    connect(ui->pushButton_page1_1,SIGNAL(clicked(bool)),this,SLOT(selectFilesOfSegment()));
    connect(ui->pushButton_page2_1,SIGNAL(clicked(bool)),this,SLOT(selectFilesOfJson()));
    connect(ui->pushButton_page1_4,SIGNAL(clicked()),this,SLOT(toDoSegment()));
    connect(ui->pushButton_page2_3,SIGNAL(clicked()),this,SLOT(toDoMerge()));

}

string qstr2str(const QString qstr)
{
    QByteArray cdata = qstr.toLocal8Bit();
    return string(cdata);
}

void filecut::segment(string file_name, int segment_num, string json_file)
{
    // 检查源文件是否存在
    if (!exist(file_name)) {
        cout << "file [" << file_name << "] doesn't exist!" << endl;
        return;
    }

    // 检查分片数量是否大于0
    if (segment_num <= 0) {
        cout << "segment number should be greater than 0!" << endl;
        return;
    }

    // 分片文件名
    vector<string> segment_files;
    for (int i = 0; i < segment_num; i++) {
        segment_files.push_back(file_name + to_string(i+1) + ".tmp");
        cout << "segment_file --- " << segment_files[i] << endl;
    }

    ifstream src_file_input(file_name,ios::binary);
    // 输入文件大小
    long long src_file_size = file_size(src_file_input);
    // 分片文件大小
    long long segment_size = src_file_size / segment_num;
    //cout<<"segment_num: "<<segment_num<<endl;
    //cout<<src_file_size<<endl;
    //cout<<segment_size<<endl;

    // 分片输出文件
    for (int i = 0; i < segment_num; i++) {
        ofstream segment_file_output(segment_files[i],ios::binary);

        if (i == segment_num-1) {  // 最后一次，要将剩余文件片全部写入
            long long left_size = src_file_size % segment_size;
            //cout<<segment_size + left_size<<endl;
            copy_file(src_file_input, segment_file_output, segment_size + left_size);
        } else {
            copy_file(src_file_input, segment_file_output, segment_size);
        }
        segment_file_output.close();
    }

    src_file_input.close();

    ofstream json_output(json_file);
    json j;
    j[kSegmentFileNum] = segment_num;
    j[kSourceFileName] = file_name;
    j[kSegmentFiles] = segment_files;
    json_output << j;
    json_output.close();
}


void filecut::merge(string json_file)
{
    json j;

    if (!exist(json_file)) {
        cout << "json file [" << json_file << "] doesn't exist!" << endl;
        return;
    }

    ifstream json_input(json_file);
    json_input >> j;

    // 源文件名
    string src_file = j[kSourceFileName];

    // 检查源文件是否已经存在
    if (exist(src_file)) {
        src_file += ".copy";
    }
    ofstream result(src_file,ios::binary);

    // 文件分片数量
    int segment_num = j[kSegmentFileNum];
    // 分片文件名
    vector<string> segment_files = j[kSegmentFiles];

    // 检查文件分片是否齐全
    for (auto it = segment_files.begin(); it != segment_files.end(); ++it) {
        if (!exist(*it)) {
            cout << "segment file [" << *it << "] doesn't exist!" << endl;
            return;
        }
    }

    // 合并文件
    for (auto it = segment_files.begin(); it != segment_files.end(); it++) {
        cout << "copy file [" << *it << "]" << endl;
        ifstream seg_input(*it,ios::binary);
        long long seg_input_size = file_size(seg_input);
        copy_file(seg_input, result, seg_input_size);
        seg_input.close();
    }

    json_input.close();
    result.close();
}

void filecut::copy_file(ifstream &input, ofstream &output, long long input_size)
{
    char* data = new char[kBlockSize];
    cout<<"input_size: "<<input_size<<endl;
    for (int block = 0; block < input_size / kBlockSize; block++) {
        cout<<"kBlockSize:"<<kBlockSize<<endl;
        read_file_in_block(data, input);
        write_file_in_block(data, output);
    }

    int left_size = input_size % kBlockSize;
    cout<<"left_size: "<<left_size<<endl;
    if (left_size != 0) {
        read_file_in_block(data, input, left_size);
        write_file_in_block(data, output, left_size);
    }

    delete [] data;
    data = nullptr;
}

bool filecut::exist(string name)
{
    struct stat buffer;
    return (stat(name.c_str(),&buffer)==0);
}

long long filecut::file_size(ifstream &file)
{
    long long size;
    file.seekg(0,std::ios::end);
    size = file.tellg();
    file.seekg(0,std::ios::beg);

    return size;
}

void filecut::selectFilesOfSegment()
{
    this->filesOfSegment = QFileDialog::getOpenFileNames(this,tr("文件选择"),tr("/home"),tr("任意文件(*)"));
    updateTableWidgetOfPage1();
    return;
}

void filecut::selectFilesOfJson()
{
    this->filesOfJson = QFileDialog::getOpenFileNames(this,tr("文件选择"),tr("/home"),tr("json文件(*.json)"));
    updateTableWidgetOfPage2();
}

QString filecut::splitFileNameFromPath(QString path)
{
    int indexOdDot=path.lastIndexOf("/");
    QString filename=path.mid(indexOdDot+1);
    return filename;
}

void filecut::toDoSegment()
{
    if(this->filesOfSegment.size()==0) return;
    this->sizeOfPerTmp = ui->spinBox_page1_1->value();
    for(int i=0;i<this->filesOfSegment.size();i++){
        ui->pushButton_page1_3->setText("正在处理:"+QString::number(i+1)+"/"+QString::number(this->filesOfSegment.size()));
        qApp->processEvents();
        int segmentNum = (QFile(this->filesOfSegment[i]).size()/(this->sizeOfPerTmp*1024*1024))+1;
        filecut  tmp;
        tmp.segment(qstr2str(splitFileNameFromPath(this->filesOfSegment[i])),segmentNum,qstr2str((splitFileNameFromPath(this->filesOfSegment[i])+".json")));
    }
    qDebug()<<"finish:toSegment"<<endl;
    ui->pushButton_page1_3->setText("分割完成");
    QMessageBox::information(NULL, "通知","分割完成",QMessageBox::Yes | QMessageBox::No,QMessageBox::Yes);
    return;
}

void filecut::toDoMerge()
{
    if(this->filesOfJson.size()==0) return;
    for(int i=0;i<this->filesOfJson.size();i++){
        ui->pushButton_page2_2->setText("正在处理:"+QString::number(i+1)+"/"+QString::number(this->filesOfJson.size()));
        qApp->processEvents();
        filecut tmp;
        qDebug()<<splitFileNameFromPath(this->filesOfJson[i])<<endl;
        tmp.merge(qstr2str(splitFileNameFromPath(this->filesOfJson[i])));
    }
    qDebug()<<"finish:toDoMerge"<<endl;
    ui->pushButton_page2_2->setText("合并完成");
    QMessageBox::information(NULL, "通知","合并完成",QMessageBox::Yes | QMessageBox::No,QMessageBox::Yes);
    return;
}

void filecut::updateTableWidgetOfPage1()
{
    if(this->filesOfSegment.size()==0) return;
    ui->tableWidget_page1_1->clear();
    int lengthOfName = max(500,int(ui->tableWidget_page1_1->width()*0.5));
    int lengthOfSize = ui->tableWidget_page1_1->width() - lengthOfName - 25;
    int num_col=2;
    int num_row=this->filesOfSegment.length()+1;
    ui->tableWidget_page1_1->setColumnCount(num_col);
    ui->tableWidget_page1_1->setRowCount(num_row);
    ui->tableWidget_page1_1->verticalHeader()->setVisible(false);
    ui->tableWidget_page1_1->horizontalHeader()->setVisible(false);
    ui->tableWidget_page1_1->setShowGrid(false);

    for(int i=0;i<num_row;i++){
        ui->tableWidget_page1_1->setRowHeight(i,25);
    }
    ui->tableWidget_page1_1->setColumnWidth(0,lengthOfName);
    ui->tableWidget_page1_1->setColumnWidth(1,lengthOfSize);

    ui->tableWidget_page1_1->setItem(0,0,new QTableWidgetItem("名称"));
    ui->tableWidget_page1_1->setItem(0,1,new QTableWidgetItem("大小"));

    for(int i=0;i<this->filesOfSegment.size();i++){
        ui->tableWidget_page1_1->setItem(i+1,0,new QTableWidgetItem(splitFileNameFromPath(this->filesOfSegment[i])));
        QString tmp = QString::number(QFile(this->filesOfSegment[i]).size()/1024/1024)+"MB";
        ui->tableWidget_page1_1->setItem(i+1,1,new QTableWidgetItem(tmp));
    }
    return;
}

void filecut::updateTableWidgetOfPage2()
{
    if(this->filesOfJson.size()==0) return;
    ui->tableWidget_page2_1->clear();
    int num_col=1;
    int num_row=this->filesOfJson.length()+1;
    ui->tableWidget_page2_1->setColumnCount(num_col);
    ui->tableWidget_page2_1->setRowCount(num_row);
    ui->tableWidget_page2_1->verticalHeader()->setVisible(false);
    ui->tableWidget_page2_1->horizontalHeader()->setVisible(false);
    ui->tableWidget_page2_1->setShowGrid(false);

    for(int i=0;i<num_row;i++){
        ui->tableWidget_page2_1->setRowHeight(i,25);
    }
    ui->tableWidget_page2_1->setColumnWidth(0,ui->tableWidget_page2_1->width()-25);

    ui->tableWidget_page2_1->setItem(0,0,new QTableWidgetItem("名称"));

    for(int i=0;i<this->filesOfJson.size();i++){
        ui->tableWidget_page2_1->setItem(i+1,0,new QTableWidgetItem(splitFileNameFromPath(this->filesOfJson[i])));
    }
    return;
}
filecut::~filecut()
{
    delete ui;
}
