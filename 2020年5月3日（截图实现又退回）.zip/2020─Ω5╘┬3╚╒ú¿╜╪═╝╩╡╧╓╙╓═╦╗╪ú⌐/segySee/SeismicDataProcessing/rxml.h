#ifndef IRXML_H
#define IRXML_H

#include <QXmlStreamReader>
#include <QtWidgets>


class IRXml
{
public:
    IRXml(QTreeWidget *treeWidget);
    ~IRXml();
    bool ReadXml(QString &path);//读

private:
    void readXBEL();
    void readTitle(QTreeWidgetItem *item);

    void readFolder(QTreeWidgetItem *item);

    QTreeWidgetItem *createChildItem(QTreeWidgetItem *item);

    QXmlStreamReader qxsrXml_gv;
    QTreeWidget *pqtwTreeWidget_gv;
};

#endif // IRXML_H
