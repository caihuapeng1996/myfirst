#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

#include "../libUtil/alloc.h"

#include"complex.h"
#include"sgy.h"

void PMfilter2D_Profile(char *filename_input,char *filename_output,float scale,float kappa,int iter);
void PMfilter2D(float **data_input,float **data_output,int nt,int nx,int iter,float kappa,float scale);
void d_space(char *filename_input,char *filename_output,int nx,int ny,int iter,float scale,float kappa,float deltt);
void PM_filter3DL(float ***data_input,float **data_output,int nx,int ny,int nt,float kappa,float delta_t,float scale,int iter);
offset offset_assign(int t,int x,int y);

unsigned short exchangeLowHigh16(unsigned short Data_temp);
unsigned int exchangeLowHigh32(unsigned int Data_temp);
float ibm2pc(unsigned int Data_temp);
unsigned int pc2ibm(float input);
float ieee2pc(unsigned int Data_temp);

void trace_ibm2pc(float *data_output,int *data_input,int nt);
void trace_pc2ibm(float *data_input,int *data_output,int nt);

void seismic_fix(char *filename_input,char *filename_output,int ny);

