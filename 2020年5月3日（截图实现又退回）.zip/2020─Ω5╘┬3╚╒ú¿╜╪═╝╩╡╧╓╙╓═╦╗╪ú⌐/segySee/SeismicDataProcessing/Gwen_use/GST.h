#ifndef GST_H_
#define GST_H_

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

#include "../libUtil/alloc.h"
#include"Gwen_use/sgy.h"

#define PI 3.141592654
//#define N 2


//void boxfilter2D(float** data_input,float** data_output,int nx,int nt,int length_half_t,int length_half_x);
//void guidedfilter2d_profile(char *filename_input,char *filename_output,int length_x,int length_t);
//void guidedfilter2d(float **data_input,float **data_guided,float **data_output,float eps,int length_x,int length_t,int nx,int nt);

unsigned short exchangeLowHigh16(unsigned short Data_temp);
unsigned int exchangeLowHigh32(unsigned int Data_temp);
float ibm2pc(unsigned int Data_temp);
float ieee2pc(unsigned int Data_temp);
unsigned int pc2ibm(float input);
//void seismic_fix(char *filename_input,char *filename_output);
//
void trace_ibm2pc(float *data_output,int *data_input,int nt);
void trace_pc2ibm(float *data_input,int *data_output,int nt);

#endif
