#include"Gwen_use/GST.h"


void trace_ibm2pc(float *data_output,int *data_input,int nt){

	for(unsigned int it=0;it<nt;it++){
		data_output[it]=ibm2pc(data_input[it]);
	}
}

void trace_pc2ibm(float *data_input,int *data_output,int nt){

	for(unsigned int it=0;it<nt;it++){
		data_output[it]=pc2ibm(data_input[it]);
	}
}


