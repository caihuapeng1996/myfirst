#include"GST.h"

unsigned short exchangeLowHigh16(unsigned short Data_temp)//16λ�ߵ�λת������  shortռ2�ֽڣ�2*8
{
        unsigned short result;
        unsigned short temp1=Data_temp>>8;//����λ
        unsigned short temp2=Data_temp<<8;
        result=temp1^temp2;
        return result;//���ظߵ�λת�����
}


unsigned int exchangeLowHigh32(unsigned int Data_temp)//32λ�ߵ�λת������  4*8
{
        signed int *pp=(signed int *)&Data_temp;//��ȡData_temp��ַ
        char *b;
        b=(char *)pp;
        unsigned char temp = b[0]; //8λΪ��λ
        b[0] = b[3];	b[3] = temp;
        temp = b[1];	b[1] = b[2];	b[2] = temp;
        unsigned int result=*pp;
        return result;//���ظߵ�λת�����
}


float ibm2pc(unsigned int Data_temp)//IBMתPC����
{
        signed int *pp=(signed int *)&Data_temp;//�޷������ͷ�ʽ��ȡData_temp��ַ
        char *b;
        b=(char *)pp;
        unsigned char temp = b[0]; //8λΪ��λ
        b[0] = b[3];	b[3] = temp;
        temp = b[1];	b[1] = b[2];	b[2] = temp;
        double sign = (double)( Data_temp >>31) ; //ȡ����λ
        double exp =(double )( ( Data_temp &0x7f000000)  >>24) ;
        exp = exp - 64 ;
        double frac1 = (double )( Data_temp &0x00ffffff  ) ;
        double frac = frac1/ (pow(2.0,24) );
        float result;
        result = (float)(( 1-2*sign)*( pow( 16 ,exp) ) *frac);
        return result;  //����PC��ʽ����
}

unsigned int pc2ibm(float input)//PCתIBM����
{

    if(input==0)
    {
        unsigned int result;
        result=0;
        return result;
    }
    else
    {
        int sign;//����λ
        sign =   ( input<0?1:0 ) ;
        int exp;//
        float input1 ; // attention : cannot use   long input1;
        input   = input * pow(-1.0, sign);//
        exp=0;
        input1 = input;
        if (input >0 )    //
        {
                if( (int)input>0)//	sgyReadWrite();
                {
                        exp++;
                        while   ((int) input1/16 > 0)
                        {
                                exp++;
                                input1= input1/16;
                        }
                }
                else
                {
                        while ( (int)input1*16 ==0)
                        {
                                exp--;
                                input1=input1*16;
                        }
                        exp++;//
                }
        }
        int e;
        e = (   exp + 64 ) ;
        double     fm = input * pow(16.0,-exp);////////////////
        int fmant=(int) (   fm * pow(2.0,24) ) ;//
        unsigned int result ;
        result = ( sign<<31) | (   e <<24   )    |   fmant ;
        char *b;
        //unsigned int *b;
        b=(char*)&result;
        unsigned char temp = b[0];//8λΪ��λ
        b[0] = b[3];	b[3] = temp;
        temp = b[1];	b[1] = b[2];	b[2] = temp;
        return result;//����IBM��ʽ����
    }
}

float ieee2pc(unsigned int Data_temp) //IEEEתΪPC
{
        signed int *pp=(signed int *)&Data_temp;//�޷������ͷ�ʽ��ȡData_temp��ַ
        char *b;
        b=(char *)pp;
        unsigned char temp = b[0]; //8λΪ��λ
        b[0] = b[3];	b[3] = temp;
        temp = b[1];	b[1] = b[2];	b[2] = temp;
        double sign = (double)( Data_temp >>31) ; //ȡ����λ
        int e;//
        e=(int)((Data_temp & 0x7f800000 )>>23)-127;
        unsigned int x ; //
        x = (unsigned int)((Data_temp & 0x007fffff) -sign); //- sign : for value < 0
        float x0 ;
        x0 = x* pow(2.0,-23);
        float result;
        if ( x0 ==0 && e + 127 ==0 ) //
                result = 0;
        else
                result = pow(-1.0,sign)*(1+x0)*pow(2.0,e);
        return result;//����PC��ʽ����
}