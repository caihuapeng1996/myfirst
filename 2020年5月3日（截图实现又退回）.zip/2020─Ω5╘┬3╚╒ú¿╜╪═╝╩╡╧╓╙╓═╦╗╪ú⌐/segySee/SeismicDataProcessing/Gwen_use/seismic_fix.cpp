#include"GST.h"

void seismic_fix(char *filename_input,char *filename_output,int ny){
	FILE *fp_input;
	FILE *fp_output;
	segy traceheader;
    segy *Arry_traceheader;
	bhed fileheader;

	int size_traceheader=sizeof(traceheader);
	int size_fileheader=sizeof(fileheader);
	int nt;
	int index_min;
	int index_max;

    printf("���������ĵ��ţ�");
	scanf("%d",&index_max);
	printf("��������С�ĵ��ţ�");
	scanf("%d",&index_min);



	int nx=index_max-index_min+1;
    
	int fldr_old;
    int fldr_new;
	int tracf;
	int ix;

	float **data;
	float *data1;
	int  *data1_temp;

	fp_input=fopen(filename_input,"rb");
	fp_output=fopen(filename_output,"wb");

	if(fp_input==NULL){
		printf("Cannot open this input file!!!\n");
		system("pause");
		exit(0);
	}

	if(fp_output==NULL){
		printf("Cannot open this output file!!!\n");
		system("pause");
		exit(0);
	}

	fread(&fileheader,size_fileheader,1,fp_input);
    fread(&traceheader,size_traceheader,1,fp_input); 
	nt=exchangeLowHigh16(fileheader.hns);
	fldr_old=exchangeLowHigh32(traceheader.fldr);
	fldr_new=exchangeLowHigh32(traceheader.fldr);

	data=alloc2float(nt,nx);
	Arry_traceheader=(segy*)malloc(nx*size_traceheader);
	data1=(float*)malloc(nt*sizeof(float));
	data1_temp=(int*)malloc(nt*sizeof(float));

	memset(data[0],0,nt*nx*sizeof(float));
	memset(data1_temp,0,nt*sizeof(int));
	memset(data1,0,nt*sizeof(float));
	memset(Arry_traceheader,0,nx*size_traceheader);

	fseek(fp_input,size_fileheader,0);
	fwrite(&fileheader,size_fileheader,1,fp_output);

	for(unsigned int iy=0;iy<ny;iy++){
		while(fldr_new==fldr_old){
		 
          fread(&traceheader,size_traceheader,1,fp_input);
		  fread(data1_temp,nt*sizeof(int),1,fp_input);
		  tracf=exchangeLowHigh32(traceheader.cdp);
		  ix=tracf-index_min;
		  /*for(unsigned int it=0;it<nt;it++){
			  data1[it]=ibm2pc(data1_temp[it]);
		  }
*/
		  trace_ibm2pc(data1,data1_temp,nt);
		  //printf("%d\n",tracf);

		  if((ix>=0)&&(ix<nx)){
			  memcpy(data[ix],data1,nt*sizeof(float));
			  Arry_traceheader[ix]=traceheader;
		  }
		  fread(&traceheader,size_traceheader,1,fp_input);
		 // fseek(fp_input,-size_traceheader,1);
		 _fseeki64(fp_input,(long long)(-size_traceheader),1);
		  fldr_new=exchangeLowHigh32(traceheader.fldr);
		}
		
		fldr_old=fldr_new;
		
		for(ix=0;ix<nx;ix++){
			fwrite(&Arry_traceheader[ix],size_traceheader,1,fp_output);
			/*for(int it=0;it<nt;it++){
				data1_temp[it]=pc2ibm(data[ix][it]);
			}*/
			  trace_pc2ibm(data[ix],data1_temp,nt);
			fwrite(data1_temp,nt*sizeof(int),1,fp_output);

		}
		 printf("�����������ߺ�=%d\n",iy);
		 memset(data[0],0,nt*nx*sizeof(float));
		 memset(Arry_traceheader,0,nx*size_traceheader);
	}




	fclose(fp_input);
	fclose(fp_output);
	free(data1);
	free(data1_temp);
	free2float(data);
	free(Arry_traceheader);
}