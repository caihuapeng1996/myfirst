#include "wxml.h"

IWXml::IWXml()
{
    qxswXml_gv.setAutoFormatting(true);//设置自动结构的模式
}

IWXml::~IWXml()
{

}

/*
 ***************************************************
 * 函数名：WriteXml
 * 作用：将所有节点写入xml文件
 * 输入：xml文件，要保存工程的item，存储路径的map
 * 返回：无
 * 编写：vgGwen 18/5/11
 * 修改：
 ****************************************************
 */
bool IWXml::WriteXml(QString &path, QTreeWidgetItem *pitem)
{
    QFile file(path);
    file.open(QFile::WriteOnly);
    qxswXml_gv.setDevice(&file);//设置文件
    qxswXml_gv.writeStartDocument();//开始写文件
    qxswXml_gv.writeDTD("<!DOCTYPE xbel>");
    qxswXml_gv.writeStartElement("xbel");
    qxswXml_gv.writeAttribute("version","1.0");
    WriteItem(pitem);
    qxswXml_gv.writeEndElement();//写入结束符
    qxswXml_gv.writeEndDocument();//结束文件
    file.close();
    return true;
}

/*
 ***************************************************
 * 函数名：WriteItem
 * 作用：将单个工程节点信息写入xml文件，使用循环写入其所有子节点
 * 输入：QTreeWidgetItem型的节点指针
 * 返回：无
 * 编写：vgGwen 18/5/11
 * 修改：
 ****************************************************
 */
void IWXml::WriteItem(QTreeWidgetItem *item)
{
    QString qsTagName = item->data(0,Qt::UserRole).toString();
    if(qsTagName == "node")//写入节点名字
    {
        /*写入节点信息*/
        bool bFolded = item->isExpanded();
        qxswXml_gv.writeStartElement(qsTagName);
        qxswXml_gv.writeAttribute("folder",bFolded ? "no" : "yes");//属性1：节点状态
        qxswXml_gv.writeAttribute("title",item->text(0));//属性2：节点的text

        for (int i = 0; i < item->childCount();++i)
            WriteItem(item->child(i));//将节点信息递归写入
        qxswXml_gv.writeEndElement();
    }
}
/*
 ***************************************************
 * 函数名：DeleteXml
 * 作用：删除某节点
 * 输入：路径，待删除的节点
 * 返回：无
 * 编写：vgGwen 18/5/23
 * 修改：
 ****************************************************
 */
bool IWXml::DeleteXml(QString &path, QTreeWidgetItem *pitem)
{
    QFile file(path);
    if(!file.open(QFile::ReadOnly))
    {
        return false;
    }
    QDomDocument doc;
    if(!doc.setContent(&file))//设置文件
    {
        file.close();
        return false;
    }
    file.close();//一定要关闭

    /*开始删除节点*/
    QString qsNodeName = pitem->text(0);//获得树形图上的text
    QDomNodeList qdnlList = doc.elementsByTagName("node");
    for (int nCount = 0;nCount<qdnlList.count();++nCount)
    {
        if(qdnlList.at(nCount).isElement())
        {
            QDomElement qdeFindNode = qdnlList.at(nCount).toElement();
            if(qdeFindNode.attribute("title") == qsNodeName)//将树形图上的text与xml文件节点的title属性对比，找到并删除节点
            {
                QDomNode parent = qdeFindNode.parentNode();//用该节点的父亲节点来删除该节点
                parent.removeChild(qdnlList.at(nCount));
            }
        }
    }

    /*写回文件*/
    if(!file.open(QFile::WriteOnly | QFile::Truncate))
        return false;
    QTextStream qtsRewrite(&file);
    doc.save(qtsRewrite,4);//缩进4格
    file.close();
    return true;
}
