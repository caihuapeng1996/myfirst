#ifndef BANDPASS_H
#define BANDPASS_H

#include <QWidget>

namespace Ui {
class BandPass;
}

class BandPass : public QWidget
{
    Q_OBJECT

public:
    explicit BandPass(QWidget *parent = 0);
    ~BandPass();

private:
    Ui::BandPass *ui;
};

#endif // BANDPASS_H
