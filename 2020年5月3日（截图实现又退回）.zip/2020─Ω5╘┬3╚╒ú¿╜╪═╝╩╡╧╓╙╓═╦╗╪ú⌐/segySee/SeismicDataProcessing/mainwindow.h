#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QCoreApplication>
#include <QMainWindow>
#include <QDateTime>
#include <QTreeWidget>
#include <QMap>
#include <QStandardItemModel>
#include <QColor>
#include <QRegExp>
#include <QDebug>
#include <QPainter>
#include <iostream>
#include <fstream>
#include <QDataStream>
#include <QPainter>
#include "newproject.h"
#include "aboutdialog.h"
#include "input2d.h"
#include "input3d.h"
#include "iodisplay.h"
#include "iodisplay3d.h"
#include "ckmessagebox.h"
#include "typeconversion.h"
#include "wxml.h"
#include "rxml.h"
#include "toolkit.h"
#include "structmis.h"
#include "Gwen_use/GST.h"
#include "../libUtil/alloc.h"
#include "Gwen_use/sgy.h"
#include "../libSegy/segyreadwrite.h"
#include "paint2dform.h"
#include "filesplit.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QDir>
#include "json.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <exception>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "bandpass.h"

//工程配置文件
#define defNODEXML_NAME tr("node.xbel")//用于保存节点信息的xml文件
#define defPATHFILE_NAME tr("sgyFile.text")//记录工程中sgy文件的全路径信息

//xml中一些节点命名
#define defSEISMIC_DATA tr("sgy")//xml树中'工程'节点的子节点名， 该节点是组织其他sgy文件的父节点
#define defNAVI_DATA tr("道头信息")//每一个文件节点都有下面两个文件节点
#define defORIG_DATA tr("剖面显示")

//各sgy文件对应的临时文件，保存一些相关信息
#define defNAVI_FILE_NAME defNAVI_DATA + tr(".text")
#define defORIG_FILE_NAME defORIG_DATA + tr(".text")

using namespace std;
using json = nlohmann::json;

namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::MainWindow *ui;
    INewProject *newpro_dialog = nullptr;//对话框_新建工程
    AboutDialog *about_dialog = nullptr;//对话框_关于
    IInput2D *input2d_dialog = nullptr;//对话框_工程加入2d的sgy文件
    IInput3D *input3d_dialog = nullptr;//对话框_工程加入2d的sgy文件
    IODisplay *iodisplay_doalog = nullptr;//对话框_2d的sgy文件的导向滤波
    IODisplay3d *iodisplay3d;//对话框_3d的sgy文件的的处理
    ICkMessageBox *ckmessagebox_dialog = nullptr;//对话框_ckMessageBox
    QTableWidget *BinaryHeadtable = nullptr;//卷头表
    QTableWidget *table = nullptr;//道数据表
    QPlainTextEdit *ptxt = nullptr;//显示概要、文本头信息
    FileSplit *filesplit;//大文件分割的指针
    BandPass *bandpass;//带通滤波器指针

    //xml与树形节点相关
    IWXml *writexml = nullptr;//用于写入xml文件
    IRXml *readxml = nullptr;//用于读xml
    ITypeConversion *mytypecoversion;//工具类_基本数据转换
    IToolkit *toolkit = nullptr;//工具类_文件和树形图处理相关
    //树形节点与xml节点的对应关系
    // key的命名：父节点+子节点名+子节点名+。。。，这样一级一级加长，确保不重合
    QMap<QString,QTreeWidgetItem> qmTreeWidget_item_gv;//key:QTreeWidgetItem。
    QMap<QString,QString> qmTreeWidget_path_gv;//key:abstructPath

    SegyReadWrite srw;//读写segy文件的类
    //绘图状态
    int mapType=0;
    int presetColor=1;

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow()override;

protected:
    void closeEvent(QCloseEvent *event)override;//软件退出事件

private:
    void saveProject(QTreeWidgetItem *item);//保存工程
    QString getFile_path(QString &strFilePath, QString &strNameFilters);//搜索目录下文件的绝对路径
    void write_Path(QFile &file,QString &path,bool toD);
    QString get_key(QTreeWidgetItem *item, QString name);//获取树形图节点的key值
    void deleteNode_xml(QTreeWidgetItem *item);//删除xml中与树形图对应的节点

    //根据sgy文件，显示2D剖面图
    void showProfile(const SegyReadWrite& s, int lineType=0, int mapType=0, int presetColor=1);
    /*绘制底图相关*/
    void paint_BaseMap(const SegyReadWrite& s);//绘制底图


public slots:
    void slot_NewProject();//新建工程槽函数
    void slot_OpenProject();//打开工程槽函数
    void slot_SaveProject();//保存工程槽函数
    void slot_QuitProject();//关闭工程槽函数
    void slot_Input2D();//导入2D数据槽函数
    void slot_Input3D();//导入3D数据槽函数
    void slot_GFCompute2D();//2D引导滤波界面
    void slot_GFCompute3D();//3D引导滤波界面
    void slot_About();//about界面
    //TreeWidget的操作
    void slot_TreeWidget_Right_Clicked(const QPoint pos);//树形图鼠标右键操作
    void slot_FoldOr_not();//树形图折叠展开子节点
    void slot_DoubleClick();//树形图双击操作
    void slot_Delete_file();//删除文件
    //剖面图操作相关私有槽函数
    void on_radioButton_toggled(bool checked);//切换剖面图
    void on_pushButton_2_clicked();//缩放还原
    void on_slider_sliderReleased();//滑动缩放
    void on_pushButton_zoomRect_clicked();//框选矩形缩放
    void on_toggleProfile(int lineType, int num);//3D显示的剖面切换
    //其他
    void on_tabWidget_tabBarClicked(int index);//tabWiget的index切换
    void on_radioButton_overView_clicked();//概述
    void on_radioButton_EBCDIC_clicked();//文本头
    //显示文件基本信息
    void slot_fileData();//文本基本信息
    void on_radioButton_BinaryHead_clicked();//卷头
    //改变波形颜色
    void colorChanged();
    void presetColorChanged(int i);
    void slot_filesplit();//大文件分割
    void slot_bandpass();//带通滤波器的槽函数
//    void onCompleteCature(QPixmap captureImage);//截图


private slots:
    void on_action_jietu_triggered();
};

#endif // MAINWINDOW_H
