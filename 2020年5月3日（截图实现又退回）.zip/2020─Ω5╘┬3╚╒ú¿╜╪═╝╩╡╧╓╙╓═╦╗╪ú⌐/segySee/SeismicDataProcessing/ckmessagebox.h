#ifndef CKMESSAGEBOX_H
#define CKMESSAGEBOX_H

#include <QDialog>
#include <QDebug>

namespace Ui {
class ICkMessageBox;
}

class ICkMessageBox : public QDialog
{
    Q_OBJECT

public:
    explicit ICkMessageBox(QWidget *parent, QString WindowTitle, QString LabelText, QString CheckBoxText);
    ~ICkMessageBox();

    void set_CheckBox_default(bool defa = false);//设置复选框初始状态

    void get_Status(bool &ok,bool &cancel, bool &ck);//返回三个bool量的状态

private slots:
    void slot_Ok_PushButton();

    void slot_Cancel_PushButton();

private:
    Ui::ICkMessageBox *ui;

    bool bCheakBox = false;//复选框状态
    bool bOk = false;//判断按的哪个按钮
    bool bCancel = false;
};

#endif // CKMESSAGEBOX_H
