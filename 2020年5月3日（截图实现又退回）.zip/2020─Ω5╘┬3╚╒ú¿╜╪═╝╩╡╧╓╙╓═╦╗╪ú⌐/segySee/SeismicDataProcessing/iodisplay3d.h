#ifndef IODISPLAY3D_H
#define IODISPLAY3D_H
#pragma once

#include <QMainWindow>
#include <QFileDialog>
#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QTextStream>
#include <Qstring>
#include <QTextCodec>//中文支持

#include <QWidget>
#include <QCloseEvent>
#include <QMessageBox>
#include <QDateTime>
#include <QTimer>
#include <stdio.h>
#include <string>

#include "mythread3d.h"
#include "tempfiledialog.h"
#include "mydialog.h"

#define TEMP_FILE_NAME  "/tempfile.txt"

class TempFileDialog;

extern QString Temp_File_Name;//存储临时文件路径

namespace Ui {
class IODisplay3d;
}

class IODisplay3d : public QMainWindow
{
    Q_OBJECT

public:
    explicit IODisplay3d(QWidget *parent = 0);
    ~IODisplay3d();

    void setOutputFileName(QString input, QString &input_name, QString &output,QString &output_temp, QString &output_name, QString &output_path, QString &output_suffix);//设置输出文件的文件名

    void clearex();//清除上一次文件残留下的显示信息

    void sleep(unsigned int msec);//延时函数 毫秒

    void readproperty(QString filename, int &nt, int &nx, int &ddt, float &dt, QString &filetype, int &first_trace_FFID, int &last_trace_FFID, int &first_trace_CDP, int &last_trace_CDP,int &start_time,int &end_time);//读取输入文件中的数据属性

    void createFile(QString filePath,QString fileName);

    void fillInform(QString input, bool &flag);//填充面板信息

    void ComputeOperation();//计算操作

    void closeEvent(QCloseEvent * event);//关闭程序事件

    bool isDirExist(QString fullPath);//判断路径是否存在

    QString getTempDir();//获取临时文件路径


signals:
    void signal_mainSendPara(QString input, QString output,QString output_temp, int nxx, int nyy,int iter_max,float scale,float kappa,float delatt,int index);//向子程序传参数
    void signal_mainSendComplement(int flag, int first_CDP, int last_CDP, int nyy, QString inputCom);//向子线程传递补全标志
    void signal_mainSendTracePar(QStringList fileList);

private slots:

    void slot_mainGetString(QString tep);//接受子线程信号的槽函数

    void slot_mainGetNum(int num);//接受子线程信号的槽函数

//    void slot_mainGetOver();//接受子线程的计算结束信号

    void on_OpenFile_pushButton_clicked();//用于显示已存在文件

    void on_StartCompute_pushButton_clicked();//start键

    void slot_clearOutput();//clear键

  //  void on_About_pushButton_clicked();//about

    void slot_CancelCompute();//Cancel

    void on_fillAll_clicked();

    // void on_LengthX_SpainBox_valueChanged(int arg1);

  //  void on_LengthT_SpainBox_valueChanged(int arg1);

    void slot_CheckTempFile();//查看临时文件

    void on_scan_clicked();

    void on_checkFile_RadioButton_clicked();

private:
    Ui::IODisplay3d *ui;
    TempFileDialog *tempfiledialog;//打开临时文件
    Mythread3d *mythread;//线程
    ITypeConversion *mytypeconversion;//数据转换
    MyDialog *mydialog;//文件显示的对话框

    QString Input_File;//输入文件
    QString Input_Name_qstr;//输入文件名
    QString Output_FileSuffix_qstr;//输出名后缀
    QString Input_FileName_qstr;//记录输入文件的绝对路径+文件名
    QString Output_FileName_qstr;//记录输出文件的绝对路径+文件名

    QStringList Input_FileList;//输入文件列表
    QString Output_FilePath_qstr;//记录绝对路径
    std::string Input_FileName_cstr;//c++类型的string，用于打开文件
    int FileList_count_i = 0 ;//文件列表长度
    int File_count_i = 0;//记录计算到第几个文件
    bool first_read = true;//判断是不是第一次读取
    int nxx;//每一个测线的地震道数
    int nyy;//测线数
    int mainIndex;//进行2d/3d计算的指标
    QString output_temp;         //文件绝对路径+文件名
    int start_time;//记录的起始时间
    int end_time;//记录的终止时间
    int first_CDP;
    int last_CDP;

};

#endif // IODISPLAY3D_H
