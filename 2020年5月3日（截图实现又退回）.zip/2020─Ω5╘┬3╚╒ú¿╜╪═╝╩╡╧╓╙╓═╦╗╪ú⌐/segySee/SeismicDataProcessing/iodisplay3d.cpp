#include "iodisplay3d.h"
#include "ui_iodisplay3d.h"

IODisplay3d::IODisplay3d(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::IODisplay3d)
{
    ui->setupUi(this);
    setFixedSize(this->width(),this->height());

    mythread = new Mythread3d;
    mytypeconversion = new ITypeConversion;
    mydialog = new MyDialog;

    ui->Output_textEdit->append(tr("1.打开文件:点击打开文件，导入需要处理的文件"));
    ui->Output_textEdit->append(tr("2.查看文件:点击查看文件，查看文件重要信息，可扫描指定道数，点击修改，可通过输入表头字母覆盖或者填入bias进行偏置"));
    ui->Output_textEdit->append(tr("3.扫描:点击扫描，扫描重要信息到主界面"));
    ui->Output_textEdit->append(tr("4.补全:点击补全，补全缺少的数据"));
    ui->Output_textEdit->append(tr("5.开始计算:点击开始计算，开始文件中的数据计算"));

    connect(this,
            SIGNAL(signal_mainSendTracePar(QStringList)),
            mydialog,
            SLOT(slot_childGetTracePar(QStringList)));//向对话框传递参数

    connect(this,
            SIGNAL(signal_mainSendPara(QString, QString,QString , int, int, int, float, float, float,int)),
            mythread,
            SLOT(slot_compute_childGetPara(QString, QString , QString,int , int, int, float, float, float, int))
            );//主线程向子线程传参

    connect(this,
           SIGNAL(signal_mainSendComplement(int, int, int, int, QString)),
           mythread,
           SLOT(slot_childGetComplement(int, int, int, int, QString))
           );//向子线程传参数用于补全

    connect(mythread,
            SIGNAL(signal_compute_childSendString(QString)),
            this,
            SLOT(slot_mainGetString(QString)));//子线程向主线程传递string

    connect(mythread,
            SIGNAL(signal_compute_childSendNum(int)),
            this,
            SLOT(slot_mainGetNum(int)));//子线程向主线程传递数字

    connect(mythread,
            SIGNAL(signal_compute_childSendOver()),
            this,
            SLOT(on_StartCompute_pushButton_clicked()));//一次计算结束信号

    connect(ui->OpenFile_pushButton,
            SIGNAL(toggled(bool)),//打开输入文件并显示文件中的信息
            this,
            SLOT(on_OpenFile_pushButton_clicked()));

   connect(ui->StartCompute_pushButton,//确定按钮
           SIGNAL(toggled(bool)),
           this,
           SLOT(on_StartCompute_pushButton_clicked()));

    connect(ui->CancelCompute_pushButton,//取消
            SIGNAL(clicked(bool)),
            this,
            SLOT(slot_CancelCompute()));

   connect(ui->ClearOutput_pushButton,//输出清屏
           SIGNAL(clicked(bool)),
           this,
           SLOT(slot_clearOutput()));

   connect(ui->CheckTempFile_pushButton,//查看临时文件
           SIGNAL(clicked(bool)),
           this,
           SLOT(slot_CheckTempFile()));

   setWindowTitle("segy P-M Filter");
   setWindowIcon(QIcon("gf.ico"));
}

IODisplay3d::~IODisplay3d()
{
    delete ui;
    delete mythread;
    delete mytypeconversion;
    delete mydialog;

}
/*
 **************************************************
 **************************************************
 * 获取输入文件名并保存在全局参数;
 * 设置自动保存文件的文件名;
 * 读取需要信息并显示在输出框;
 **************************************************
 **************************************************
 */
void IODisplay3d::on_OpenFile_pushButton_clicked()
{   ui->Output_textEdit->clear();
    QStringList filelist = QFileDialog::getOpenFileNames(this, tr("open input file"),NULL, "*.sgy");//获取输入文件列表
    if(!filelist.isEmpty())
    {
        Input_FileList.append(filelist);
        FileList_count_i = FileList_count_i+filelist.count();//计算输入文件个数
        File_count_i = 0;

        /****************取每次读的第一个文件来显示提示信息************/

        QFileInfo list_info;
        list_info = QFileInfo(filelist.at(0));
        QString file_path = list_info.path();//获取输入文件的绝对路径
        ui->Output_textEdit->append(tr("---读取文件成功---"));//如果多次读取，每一次读取的文件路径追加在后面
        ui->Output_textEdit->append(file_path);

        /**********************创建临时文件:用总的文件列表的第一个文件来设置记录文件**********************/
        QFile filelist_txt;
        if(first_read)//打开软件第一次读文件时创建临时文件
        {
            QFileInfo file_list_info;
            file_list_info = QFileInfo(Input_FileList.at(0));
            QString file_list_path = file_list_info.path();//获取输入文件的绝对路径
            Temp_File_Name = file_list_path+TEMP_FILE_NAME;
            first_read = false;
        }
        if(!isDirExist(Temp_File_Name))//如果临时文件不存在，则创建
        {
            filelist_txt.setFileName(Temp_File_Name);
        }

        /******************将文件列表写入临时文件********************/

        if (filelist_txt.open(QIODevice::Text |QFile::WriteOnly | QIODevice::Append))
        {
            QDateTime date = QDateTime::currentDateTime();//获取系统时间分钟
            QString strDateBuffer = date.toString(" yyyy-MM-dd:hh:mm:ss");//将时间转为QString
            QTextStream out(&filelist_txt);
            out <<strDateBuffer<< endl;
            filelist_txt.close();
        }
        else
        {
            QMessageBox::warning(this, tr("Path"),tr("创建临时文件出错，请重新打开文件"));
        }

        int nt;
        int nx;
        int ddt;
        float dt;
        int first_trace_FFID;
        int last_trace_FFID;
        int first_trace_CDP;
        int last_trace_CDP;
        QString input_filename;
        QString filetype;

        for (int num = 0; num<filelist.count(); num++)//在文件末尾追加
        {
           input_filename = filelist.at(num);
           readproperty(input_filename, nt, nx, ddt, dt, filetype, first_trace_FFID, last_trace_FFID, first_trace_CDP, last_trace_CDP,start_time,end_time);
           //写入文件路径及属性
           if (filelist_txt.open(QIODevice::Text |QFile::WriteOnly | QIODevice::Append))
           {
               QTextStream out(&filelist_txt);
               out << input_filename <<"\t"<< tr("道数:") << nx
                       <<"\t"<<tr("采样点数:") << nt
                       <<"\t"<<tr("采样率:") << dt
                       <<"\t"<<tr("文件类型:") << filetype
                       <<"\t"<<tr("inline:")<<first_trace_FFID<<" - "<<last_trace_FFID
                       <<"\t"<<tr("xline:")<<first_trace_CDP<<" - "<<last_trace_CDP
                       <<"\t"<<tr("time:")<<start_time<<" - "<<end_time
                       << endl;
               filelist_txt.close();
           }
           else//打开临时文件失败
           {
               QMessageBox::information(this, QString::fromLocal8Bit("tips"), tr("写入临时文件出错"));
           }
        }
        emit signal_mainSendTracePar(Input_FileList);
    }
    else
    {
        QMessageBox::information(this, QString::fromLocal8Bit("tips"), tr("打开文件失败"));
    }
}
/*
 ***************************************************
 ***************************************************
 * 读取面板上的参数;
 * 参数发送给子线程;
 * 子线程开始计算;
 * 计算完成清空文件list
 * **************************************************
 ****************************************************
 */
void IODisplay3d::on_StartCompute_pushButton_clicked()
{
    /**************************读取文件列表*************************/
    if(FileList_count_i == 0)//判断list长度，为0则未打开文件
    {
        QMessageBox::information(this, QString::fromLocal8Bit("tips"), tr("请先打开文件"));
        return ;
    }
    if(File_count_i < FileList_count_i)
    {
        ui->Compute_progressBar->setValue(0);//每次计算开始时先把进度条的值设为0
        QString input = Input_FileList.at(File_count_i);
        Input_File = input;
        bool flag = false;
        while(!flag)//等待面板数据填充完成
        {
            fillInform(input,flag);
            sleep(100);
        }
        File_count_i++;
        ComputeOperation();//调用计算操作函数

    }
    else
    {
        ui->Output_textEdit->append("....................complete.................");
        Input_FileList.clear();//清空文件列表
        FileList_count_i = 0 ;
        File_count_i = 0;
    }
}
/*
 ***************************************************
 ***************************************************
 * 检测到时窗数据改变时修改输出文件名
 * **************************************************
 ****************************************************
 */
/*
void IODisplay::on_LengthX_SpainBox_valueChanged(int arg1)
{
    if(Input_Name_qstr != NULL)
    {
       QString x_str = mytypeconversion->int2qstring(arg1);
       QString t_str = mytypeconversion->int2qstring(ui->LengthT_SpainBox->value());
       QString output_name_str = Input_Name_qstr +"_"+ x_str + "-" + t_str + "_filter." +Output_FileSuffix_qstr;
       ui->SaveName_LineEdit->setText(output_name_str);
    }
}
*/

/*
void IODisplay::on_LengthT_SpainBox_valueChanged(int arg1)
{
    if(Input_Name_qstr != NULL)
    {
        QString x_str = mytypeconversion->int2qstring(ui->LengthX_SpainBox->value());
        QString t_str = mytypeconversion->int2qstring(arg1);
        QString output_name_str = Input_Name_qstr +"_"+ x_str + "-" + t_str + "_filter." +Output_FileSuffix_qstr;
        ui->SaveName_LineEdit->setText(output_name_str);
    }
}
*/
/*
 ***************************************************
 ***************************************************
 * 打开临时文件
 * **************************************************
 ****************************************************
 */
void IODisplay3d::slot_CheckTempFile()
{
    QFile file(Temp_File_Name);
    //--打开文件成功
    if (file.open(QIODevice ::ReadOnly | QIODevice ::Text))
    {
        tempfiledialog = new TempFileDialog(this);//创建子窗口
        tempfiledialog->setModal(true);
        tempfiledialog->show();
        file.close();//关闭文件
    }
    else    //---打开文件失败
    {
       QMessageBox::information(this, QString::fromLocal8Bit("tips"), tr("暂未打开任何文件，请先打开文件"));
    }
}
/*
 ***************************************************
 ***************************************************
 * 清除计算信息框
 * **************************************************
 ****************************************************
 */
void IODisplay3d::slot_clearOutput()
{
    ui->Output_textEdit->clear();
}
/*
 ***************************************************
 ***************************************************
 * 设置about dialog
 * **************************************************
 ****************************************************
 */

/*
 ***************************************************
 ***************************************************
 * 取消功能：退出子线程，并清空待计算文件列表
 * **************************************************
 ****************************************************
 */
void IODisplay3d::slot_CancelCompute()
{
    //mythread->quit();//结束线程
    mythread-> terminate();//直接结束，有风险：共享数据未存储，锁未打开等
    ui->Output_textEdit->append("---------------Cancel Compute------------------");

    Input_FileList.clear();//清空文件列表
    FileList_count_i = 0 ;
    File_count_i = 0;
}

/*
 ***************************************************
 ***************************************************
 * 从子线程获取字符串并显示在计算信息栏
 * **************************************************
 ****************************************************
 */
void IODisplay3d::slot_mainGetString(QString tep)
{
    ui->Output_textEdit->append(tep);
}

void IODisplay3d::slot_mainGetNum(int num)
{
    ui->Compute_progressBar->setValue(num);
}
/*
 ***************************************************
 ***************************************************
 * 计算操作函数
 * **************************************************
 ****************************************************
 */
void IODisplay3d::ComputeOperation()
{
    /*********************准备计算***********************/
    //读取参数
    //int length_x_i = ui->LengthX_SpainBox->value();
   // int length_t_i = ui->LengthT_SpainBox->value();
    int iter_max = ui->iter_number->text().toInt();//迭代次数
    float scale = ui->AMP_control->text().toFloat();//振幅因子
    float kappa = ui->PM_factor->text().toFloat();//扩散因子
    float delatt = ui->time_factor->text().toFloat();//时间因子

    QString rename_qstr = ui->SaveName_LineEdit->text();
    QString output_qstr = Output_FilePath_qstr + rename_qstr;

    mainIndex = 2;

    emit signal_mainSendPara(Input_File,output_qstr,output_temp,nxx,nyy,iter_max,scale,kappa,delatt,mainIndex);//向子线程传参
    mythread->start();


}
/*
 ***************************************************
 ***************************************************
 * 关闭程序
 * 检查是否需要保存打开文件的记录文件
 * **************************************************
 ****************************************************
 */

void IODisplay3d::closeEvent(QCloseEvent *event)
{
    int User = QMessageBox::question(this,NULL,tr("是否关闭程序？"),QMessageBox::Yes|QMessageBox::Default,QMessageBox::No|QMessageBox::Escape);
    if (User == QMessageBox::Yes)
    {
        //是否删除文件
        if(!ui->SaveTempFile_radioButton->isChecked())//默认删除
        {
            QFile tempfile;
            if(tempfile.exists(Temp_File_Name))//如果文件存在
               tempfile.remove(Temp_File_Name);//删除文件
        }

        //退出程序
        event->accept();
    }
    else
    {
        event->ignore();
    }

}
/*
 ***************************************************
 ***************************************************
 * 获取输入文件的属性，用于设置输出文件名
 * output:文件绝对路径+文件名
 * output_name：文件名
 * output_path：文件绝对路径
 * input_name:输入文件名
 * output_suffix：输出文件后缀
 ****************************************************
 ****************************************************
 */
void IODisplay3d::setOutputFileName(QString input,QString &input_name, QString &output,QString &output_temp, QString &output_name,QString &output_path,QString &output_suffix)
{
    QFileInfo inputfile_info;
    inputfile_info = QFileInfo(input);
    /*获取输入文件的文件名*/
    QString inputfile_name = inputfile_info.baseName();
    /*获取输入文件的文件后缀*/
    QString inputfile_suffix = inputfile_info.suffix();
    /*获取输入文件的绝对路径*/
    QString inputfile_path = inputfile_info.path();
    /*使用时窗数据作后缀*/
    //QString x = mytypeconversion->int2qstring(ui->LengthX_SpainBox->value());
    //QString t = mytypeconversion->int2qstring(ui->LengthT_SpainBox->value());
    /*输出文件名*/
    input_name = inputfile_name;
    output_path = inputfile_path + "/" ;
    output_suffix = inputfile_suffix;
    output_name = inputfile_name +"_"+ QString::number(start_time) + "-" + QString::number(end_time) + "_filter." +inputfile_suffix;
    output =inputfile_path + "/" + inputfile_name + "_filter." +inputfile_suffix;
    output_temp =inputfile_path + "/" + inputfile_name + "_filter_temp." +inputfile_suffix;
}

/*
 ***************************************************
 ***************************************************
 * 清理上一次打开文件时面板输出的信息;
 * 道数，点数，采样率，数据类型;
 ****************************************************
 ****************************************************
 */
void IODisplay3d::clearex()
{
    ui->NumSamp_lineEdit->clear();//清除采样点数

    ui->Numtrace_lineEdit->clear();//清除道数

    ui->SampFreque_lineEdit->clear();//清除采样频率

    ui->DataType_lineEdit->clear();//清除数据类型

    ui->SaveName_LineEdit->clear();//清除保存文件名
}

/*
 ***************************************************
 ***************************************************
 * 输入文件名
 * 返回文件中包含的属性
 ****************************************************
 ****************************************************
 */
void IODisplay3d::readproperty(QString filename, int &nt, int &nx, int &ddt, float &dt, QString &filetype,int &first_trace_FFID, int &last_trace_FFID, int &first_trace_CDP, int &last_trace_CDP,int &start_time, int &end_time)
{
/******************输入文件名处理*****************/

    //将QString转换为char*
    const char *filename_input = NULL;
    std::string tmp = mytypeconversion->qstring2cstring(filename);//先把qstring转为c++的string
    filename_input = tmp.data();//再将string转为char*类型

    FILE *fp_input = NULL;
    fp_input = fopen(filename_input,"rb");//打开文件

/*****************属性信息读取*******************/
    segy th;//数据道头
    bhed fh;//数据卷头
    int size_fh_i;//卷头数据大小
    int size_th_i;//道头数据大小
    float *data;

    size_fh_i = sizeof(fh);
    size_th_i = sizeof(th);

    fread(&fh, size_fh_i,1,fp_input);//读取文件

    fread(&th,size_th_i,1,fp_input);
    //fread(&data,sizeof(float)*1601,1,fp_input);
    //fread(&th,size_th_i,1,fp_input);
    nt = exchangeLowHigh16(fh.hns);
    ddt = exchangeLowHigh16(fh.hdt);
    nxx = exchangeLowHigh16(fh.ntrpr);//每一个剖面的道数
    start_time = exchangeLowHigh16(th.muts);
    end_time = start_time + (nt-1) * ddt/1000;

    first_trace_CDP = exchangeLowHigh32(th.cdp);
    last_trace_CDP = first_trace_CDP + nxx - 1;
    first_trace_FFID = exchangeLowHigh32(th.fldr);

    fseek(fp_input,3600+240+sizeof(float)*nt,0);
    fread(&th,size_th_i,1,fp_input);
    int a = exchangeLowHigh32(th.cdp);
    qDebug()<<"采样点数"<<nt;

    dt = (float)ddt/1000000.0;

    fseek(fp_input,0,2);//指针重置
    int size_sgy = ftell(fp_input);
    nx=(size_sgy-size_fh_i)/(size_th_i+nt*sizeof(float));
    nyy = nx / nxx;
    last_trace_FFID = first_trace_FFID + nyy - 1;
    /*
     *nt;//采样点数int
     *nx;//道数int
     *ddt;//采样间隔
     *dt;//采样率float
     */
    /*判断数据类型*/

    if (fh.format == 5 || exchangeLowHigh16(fh.format) == 5)//IEEE
    {
        filetype = tr("IEEE(32 bits)");
    }
    else if(fh.format == 1 || exchangeLowHigh16(fh.format) == 1)//IBM
    {
       filetype = tr("IBM(32 bits)");
    }

    fclose(fp_input);
}
/*
 ***************************************************
 ***************************************************
 * 输入文件名
 * 填充面板信息
 ****************************************************
 ****************************************************
 */
void IODisplay3d::fillInform(QString input, bool &flag )
{
    QString input_name;     //输入文件名
    QString output;         //文件绝对路径+文件名
    QString output_name;    //文件名
    QString output_path;    //文件绝对路径
    QString output_suffix;  //输出文件后缀

    int nt;
    int nx;
    int ddt;
    float dt ;
    int first_trace_FFID;//第一个剖面好
    int last_trace_FFID;//最后一个剖面号
    int first_trace_CDP;//每个剖面的第一个道号
    int last_trace_CDP;//每个剖面的最后一个道号
    QString filetype;
    clearex();//清空面板上上一次文件的显示内容

    /******************填充面板信息*********************/
    ui->Output_textEdit->append("Compute File:"+input+"");
    readproperty(input, nt, nx, ddt, dt, filetype, first_trace_FFID, last_trace_FFID, first_trace_CDP, last_trace_CDP,start_time,end_time);//读取文件里的数据属性
    ui->NumSamp_lineEdit->insert(mytypeconversion->int2qstring(nt));//采样点数
    ui->Numtrace_lineEdit->insert(mytypeconversion->int2qstring(nx));//道数
    ui->SampFreque_lineEdit->insert(mytypeconversion->float2qstring(dt));//采样率
    ui->DataType_lineEdit->insert(filetype);

    first_trace_FFID = ui->inline_first->text().toInt();
    last_trace_FFID = ui->inline_last->text().toInt();
    first_trace_CDP = ui->xline_first->text().toInt();
    last_trace_CDP = ui->xline_last->text().toInt();


    ui->inline_first->setText(QString::number(first_trace_FFID));
    ui->inline_last->setText(QString::number(last_trace_FFID));
    ui->xline_first->setText(QString::number(first_trace_CDP));
    ui->xline_last->setText(QString::number(last_trace_CDP));

    setOutputFileName(input,input_name, output,output_temp,output_name,output_path,output_suffix);//拆分输入路径，并合成输出文件路径
    Input_FileName_qstr = input;
    Output_FileName_qstr = output;
    Output_FileSuffix_qstr = output_suffix;
    Input_Name_qstr = input_name;//保存输入文件名
    Output_FilePath_qstr = output_path;//保存输出文件绝对路径，用于生成输出文件名
    ui->SaveName_LineEdit->setText(output_name);//显示

    flag = true;
}
/*
 ***************************************************
 ***************************************************
 * 等待
 * 单位：毫秒
 ****************************************************
 ****************************************************
 */
void IODisplay3d::sleep(unsigned int msec)
{

    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);

}
/*
 ***************************************************
 ***************************************************
 * 判断路径是否存在
 * 输入：需要判断的绝对路径
 ****************************************************
 ****************************************************
 */
bool IODisplay3d::isDirExist(QString fullPath)
{
    QDir dir(fullPath);
    if(dir.exists())
    {
      return true;
    }
    return false;
}

QString IODisplay3d::getTempDir()
{
    return Temp_File_Name;
}

/*
 ***************************************************
 * 函数：on_scan_clicked()
 * 作用：扫描重要信息
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */
void IODisplay3d::on_scan_clicked()
{
    ui->AMP_control->setText(QString::number(1000));//显示振幅控制因子
    ui->iter_number->setText(QString::number(10));//显示迭代次数
    ui->PM_factor->setText(QString::number(30.0));//显示扩散因子
    ui->time_factor->setText(QString::number(0.086));//显示时间因子
    QString inputfile = Input_FileList[0];//扫描显示第一个文件的信息

    int nt;
    int nx;
    int ddt;
    float dt;
    int first_trace_FFID;//第一个剖面好
    int last_trace_FFID;//最后一个剖面号
    int first_trace_CDP;//每个剖面的第一个道号
    int last_trace_CDP;//每个剖面的最后一个道号

    QString filetype;
    readproperty(inputfile, nt, nx, ddt, dt, filetype, first_trace_FFID, last_trace_FFID, first_trace_CDP, last_trace_CDP, start_time, end_time);
    ui->inline_first->setText(QString::number(first_trace_FFID));
    ui->inline_last->setText(QString::number(last_trace_FFID));
    ui->xline_first->setText(QString::number(first_trace_CDP));
    ui->xline_last->setText(QString::number(last_trace_CDP));
    ui->start_time->setText(QString::number(start_time));
    ui->end_time->setText(QString::number(end_time));

    first_CDP = first_trace_CDP;
    last_CDP = last_trace_CDP;


    ui->inline_first->setEnabled(true);
    ui->inline_last->setEnabled(true);
    ui->xline_first->setEnabled(true);
    ui->xline_last->setEnabled(true);
}

void IODisplay3d::on_fillAll_clicked()
{
    int flag = 1;
    QString inputCom = Input_FileList[0];
    emit signal_mainSendComplement(flag,first_CDP,last_CDP,nyy,inputCom);
}

void IODisplay3d::on_checkFile_RadioButton_clicked()
{
    if(Input_FileList.isEmpty())
    {
        QMessageBox::information(this,tr("提示"),"请打开文件");
    }
    else
    {
        mydialog->show();
        mydialog->setModal(true);
    }
}
