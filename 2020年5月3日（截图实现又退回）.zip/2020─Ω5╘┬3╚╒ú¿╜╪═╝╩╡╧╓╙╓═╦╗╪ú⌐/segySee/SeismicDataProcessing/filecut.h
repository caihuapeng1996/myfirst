#ifndef FILECUT_H
#define FILECUT_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QDebug>
#include <QDir>

#include "json.h"
#include "filecut.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <exception>
using namespace std;
namespace Ui {
class filecut;
}

class filecut : public QMainWindow
{
    Q_OBJECT

public:
    explicit filecut(QMainWindow *parent = 0);
    ~filecut();

    void segment(string file_name, int segment_num, string json_file="config.json");
    void merge(string json_file="config.json");
public Q_SLOTS:
    void selectFilesOfSegment();
    void selectFilesOfJson();
    QString splitFileNameFromPath(QString path);
    void toDoSegment();
    void toDoMerge();
private:
    void updateTableWidgetOfPage1();
    void updateTableWidgetOfPage2();
private:
    QStringList filesOfSegment;
    QStringList filesOfJson;
    int sizeOfPerTmp;
private:
    bool exist(string name);
    long long file_size(ifstream &file);
    void copy_file(ifstream &input, ofstream &output, long long input_size);

    inline void read_file_in_block(char* data, ifstream &input, int size=kBlockSize) {
        //cout<<"read: "<<size<<endl;
        input.read(data, size);
    }
    inline void write_file_in_block(char* data, ofstream &output, int size=kBlockSize) {
        //cout<<"write: "<<size<<endl;
        output.write(data, size);
    }
private:
    // json key
    static const string kSegmentFileNum;
    static const string kSourceFileName;
    static const string kSegmentFiles;

    static const int kBlockSize;
private:
    Ui::filecut *ui;
};

#endif // FILECUT_H
