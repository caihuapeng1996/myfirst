#include "rxml.h"

IRXml::IRXml(QTreeWidget *treeWidget):pqtwTreeWidget_gv(treeWidget)
{
}
/*
 ***************************************************
 * 函数名：ReadXml
 * 作用：返回错误信息
 * 输入：路径
 * 返回：QString类型的错误信息
 * 编写：vgGwen 18/5/17
 * 修改：
 ****************************************************
 */
bool IRXml::ReadXml(QString &path)
{
    QFile file(path);
    file.open(QFile::ReadOnly | QFile::Text);
    qxsrXml_gv.setDevice(&file);

    if (qxsrXml_gv.readNextStartElement())
    {
        if (qxsrXml_gv.name() == "xbel" && qxsrXml_gv.attributes().value("version") == "1.0")
            readXBEL();
        else
            qxsrXml_gv.raiseError(QObject::tr("The file is not an XBEL version 1.0 file."));
    }
    file.close();
    return !qxsrXml_gv.error();
}

/*
 ***************************************************
 * 函数名：errorString
 * 作用：返回错误信息
 * 输入：无
 * 返回：QString类型的错误信息
 * 编写：vgGwen 18/5/17
 * 修改：
 ****************************************************
 */
void IRXml::readXBEL()
{
    while(qxsrXml_gv.readNextStartElement())
    {
        if(qxsrXml_gv.name()== "node")
            readFolder(0);
        else
            qxsrXml_gv.skipCurrentElement();
    }
}

/*
 ***************************************************
 * 函数名：readFolder
 * 作用：递归查找节点结构
 * 输入：查找开始时的节点
 * 返回：
 * 编写：vgGwen 18/5/17
 * 修改：
 ****************************************************
 */
void IRXml::readFolder(QTreeWidgetItem *item)
{

    QTreeWidgetItem *folder = createChildItem(item);//创一个节点
    bool folded = (qxsrXml_gv.attributes().value("folder") != "no");
    pqtwTreeWidget_gv->setItemExpanded(folder, !folded);//判定折叠
    readTitle(folder);//填写节点text

    while (qxsrXml_gv.readNextStartElement())//读取下一个节点
    {
       if (qxsrXml_gv.name() == "node")
            readFolder(folder);//递归
        else
            qxsrXml_gv.skipCurrentElement();
    }
}

/*
 ***************************************************
 * 函数名：readTitle
 * 作用：读取节点名并赋给节点
 * 输入：需要命名的节点
 * 返回：（因为每次title后面都是path，所以在读title的时候把相应的key值设置好，以便map存储时使用）
 * 编写：vgGwen 18/5/17
 * 修改：
 ****************************************************
 */
void IRXml::readTitle(QTreeWidgetItem *item)
{
    QString title = qxsrXml_gv.attributes().value("title").toString();
    item->setText(0, title);
}

/*
 ***************************************************
 * 函数名：createChildItem
 * 作用：创建子节点
 * 输入：父节点
 * 返回：子节点
 * 编写：vgGwen 18/5/17
 * 修改：
 ****************************************************
 */
QTreeWidgetItem *IRXml::createChildItem(QTreeWidgetItem *item)
{
    QTreeWidgetItem *childItem;
    if (item) {
        childItem = new QTreeWidgetItem(item);
    } else {
        childItem = new QTreeWidgetItem(pqtwTreeWidget_gv);
    }
    childItem->setData(0, Qt::UserRole, qxsrXml_gv.name().toString());
    return childItem;
}

