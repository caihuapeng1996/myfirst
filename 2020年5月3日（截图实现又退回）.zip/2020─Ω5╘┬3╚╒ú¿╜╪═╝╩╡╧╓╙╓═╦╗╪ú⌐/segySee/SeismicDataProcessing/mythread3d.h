#ifndef MYTHREAD3D_H
#define MYTHREAD3D_H

#include <QObject>
#include<QThread>
#include<QtCore>
#include <QDebug>
#include <QString>
#include <QTimer>
#include <stdio.h>
#include "typeconversion.h"

class Mythread3d:public QThread
{
    Q_OBJECT

public:
    explicit Mythread3d();
     ~Mythread3d();
    void sleep(unsigned int msec);
    //void guidedfilter2d_profile(char *filename_input, char *filename_output, int length_x, int length_t);
    //void guidedfilter2d(float **data_input,float **data_guided,float **data_output,float eps,int length_x,int length_t,int nx,int nt);
    //void boxfilter2D(float** data_input,float** data_output,int nx,int nt,int length_half_t,int length_half_x);

    void PMfilter2D(float **data_input,float **data_output,int nt,int nx,int iter,float kappa,float scale);
    void PMfilter2D_Profile(char *filename_input,char *filename_output,float scale,double kappa,int iter_max);
    void seismic_fix(const char *filename_input,const char *filename_output,int ny);
    void d_space(const char *filename_input,const char *filename_output,int nx,int ny,int iter,float scale,float kappa,float deltt);
    void PM_filter3DL(float ***data_input,float **data_output,int nx,int ny,int nt,float kappa,float delta_t,float scale,int iter);
signals:
    void signal_compute_childSendString(QString tep);
    void signal_compute_childSendNum(int num);
    void signal_compute_childSendOver();
public slots:
    void slot_compute_childGetPara(QString inputfile_, QString outputfile_,QString output_temp_, int nxx_, int nyy_,int iter_max_,float scale_,float kappa_,float delatt_,int index_);//接收主线程的参数
    void slot_childGetComplement(int flag_, int first_CDP_, int last_CDP_, int nyy_, QString input_com_);
protected:
    void run();

public:
        ITypeConversion *threadtypeconversion;
        QString input_qstr;
        QString output_qstr;

        const char* input_chp = NULL;
        const char* output_chp = NULL;
        const char* output_chp_temp = NULL;

        std::string str_input;
        std::string str_output;
        std::string str_output_temp;

        int nxx;
        int nyy;
        int iter_max;
        float scale;
        float kappa;
        float delatt;
        int index;
        QString output_temp;
        int complement = 0;//补全标志
        int first_CDP;
        int last_CDP;
        char filename_input[320];


};

#endif // MYTHREAD3D_H
