#include "typeconversion.h"

ITypeConversion::ITypeConversion()
{

}
QString ITypeConversion::int2qstring(int num)
{
    return QString::number(num,10);
}

int ITypeConversion::qstring2int(QString string)
{
    return string.toInt();
}

QString ITypeConversion::float2qstring(float num)
{
    return QString("%1").arg(num);
}

float ITypeConversion::qstring2float(QString string)
{
    return string.toFloat();
}

QString ITypeConversion::char2qstring(char *ch)
{
    QString str = QString(QLatin1String(ch));
    return str;
}

char* ITypeConversion::qstring2char(QString string)
{
    /*QByteArray tmp = string.toLocal8Bit();
    char *ch = tmp.data();
    return ch;*/
    QByteArray tmp = string.toLatin1();
    char *ch = tmp.data();
    return ch;
}

std::string ITypeConversion::qstring2cstring(QString string)
{
    QTextCodec *code = QTextCodec::codecForName("GB2312");//解决中文路径问题
    std::string name = code->fromUnicode(string).data();
    return name;
}

std::string ITypeConversion::codec(QString s)
{
    QTextCodec *code = QTextCodec::codecForName("gb2312");
    return code->fromUnicode(s).toStdString();
}
