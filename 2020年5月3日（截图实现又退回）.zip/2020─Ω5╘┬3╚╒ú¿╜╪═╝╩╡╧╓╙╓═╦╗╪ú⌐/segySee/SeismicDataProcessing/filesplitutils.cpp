
#include "filesplitutils.h"
#include <QFileInfo>
#include <QDebug>

FileSplitUtils::FileSplitUtils(){

}

FileSplitUtils::~FileSplitUtils(){

}

bool FileSplitUtils::islegalFilePath(const QString& path){
    if(path.isEmpty()){
        return false;
    }
    QFileInfo fileInfo(path);
    if(!fileInfo.exists()||!fileInfo.isFile()){
        return false;
    }
    return true;
}
bool FileSplitUtils::islegalDirPath(const QString& path){
    if(path.isEmpty()){
        return false;
    }
    QFileInfo dirInfo(path);
    if(!dirInfo.exists()||!dirInfo.isDir()){
        return false;
    }
    return true;
}

bool FileSplitUtils::islegalSplitSize(const QString& path,const qint64 splitSize){
    if(splitSize<1){
        return false;
    }
    QFileInfo fileInfo(path);
    if(splitSize>fileInfo.size()){
        return false;
    }
    return true;
}

//返回设置的分割文件大小，以字节为单位
qint64 FileSplitUtils::calculateFileSize(const QString& size,const int unit){

    if(!size.isEmpty()){
       qint64 s=size.toLongLong();
       switch (unit) {
       case 0:
           return s;
       case 1:
           return s * 1024;
       case 2:
           return s* 1024* 1024;
       case 3:
           return s* 1024* 1024* 1024;
       default:
           break;
       }
    }
    return 0;
}



QString FileSplitUtils::getFileName(const QString& filePath){
    QFileInfo fileInfo(filePath);
    if(fileInfo.exists()){
        return fileInfo.fileName();
    }
    return QString("");
}

