#include "amenddialog.h"
#include "ui_amenddialog.h"

#include <QDebug>

AmendDialog::AmendDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AmendDialog)
{
    ui->setupUi(this);
    mytypeconversion = new ITypeConversion();
    setFixedSize(this->width(),this->height());
}

AmendDialog::~AmendDialog()
{
    delete ui;
}

void AmendDialog::slot_getTraces(int traces,QString inputFile,int flag_)
{   ui->verticalLayout->removeWidget(wholeTableWidget);
    inputfile = inputFile;
    traceNum = traces;
    flag = flag_;//用于确定修改某个信息的标志

    wholeTableWidget = new QTableWidget(this);
    wholeTableWidget->setRowCount(traceNum);//设置行数
    wholeTableWidget->setColumnCount(71);//设置列数

    QStringList header;//定义表头
    header<<"SEQWL(1-4)"<<"SEQWR(5-8)"<<"FFID(9-12)"<<"TRCFLD(13-16)"<<"SP(17-20)"<<"CDP(21-24)"<<\
            "TRCNUM(25-28)"<<"TRCID(29-30)"<<"NVST(31-32)"<<"NHST(33-34)"<<"DU(35-36)"<<"DSREG(37-40)"<<\
            "RGE(41-44)"<<"SES(45-48)"<<"SDBS(49-52)"<<"DERG(53-56)"<<"DES(57-60)"<<"WDS(61-64)"<<\
            "WGD(65-68)"<<"SAED(69-70)"<<"SAC(71-72)"<<"SRCX(73-76)"<<"SRCY(77-80)"<<"GRPX(81-84)"<<\
            "GRPY(85-88)"<<"UNITS(89-90)"<<"WVEL(91-92)"<<"SVEL(93-94)"<<"UTSRC(95-96)"<<"UTGRP(97-98)"<<\
            "SECSCOR(99-100)"<<"GRPSCOR(101-102)"<<"TSA(103-104)"<<"LAGTA(105-106)"<<"LAGTB(107-108)"<<\
            "DELRECT(109-110)"<<"MTSTART(111-112)"<<"MTEND(113-114)"<<"NSMP(115-116)"<<"SI(117-118)"<<\
            "GTFI(119-120)"<<"IG(121-122)"<<"IGC(123-124)"<<"CORREL(125-126)"<<"SFSTART(127-128)"<<\
            "SFEND(129-130)"<<"SLEN(131-132)"<<"STYP(133-134)"<<"SSTRLS(135-136)"<<"SSTLE(137-138)"<<\
            "TTYP(139-140)"<<"AFF(141-142)"<<"AFS(143-144)"<<"NOFILF(145-146)"<<"NOFILS(147-148)"<<"LOCF(149-150)"<<"HOCF(151-152)"<<\
            "LOCS(153-154)"<<"HICS(155-156)"<<"YEAR(157-158)"<<"DAY(159-160)"<<"HOUR(161-162)"<<\
            "MINUTE(163-164)"<<"SCE(165-166)"<<"TMBS(167-168)"<<"TWF(169-170)"<<"GGNSW(171-172)"<<\
            "GGN1ST(173-174)"<<"GGNLST(175-176)"<<"GAPSZ(177-178)"<<"OAWT(179-180)"<<"CDP-X(181-184)"<<\
            "CDP-Y(185-188)"<<"INLINE#(189-192)"<<"XLINE#(193-196)"<<"SP#(197-200)"<<"SPS(201-202)"<<"TVMU(203-204)";//设置表头内容

    wholeTableWidget->setHorizontalHeaderLabels(header);//将表头加入到表格中
    ui->verticalLayout->addWidget(wholeTableWidget);

    showTrace();
}

/*
 ***************************************************
 * 函数：showTrace()
 * 作用：显示一道的信息
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */
void AmendDialog::showTrace()
{   QString input = inputfile;
    const char *filename_input = NULL;
    std::string tmp = mytypeconversion->qstring2cstring(input);//先把qstring转为c++的string
    filename_input = tmp.data();//再将string转为char*类型

    FILE *fp_input = NULL;
    fp_input = fopen(filename_input,"rb");//打开文件
    /*****************属性信息读取*******************/
        segy th;//数据道头
        bhed fh;//数据卷头
        int size_fh_i;//卷头数据大小
        int size_th_i;//道头数据大小
        int nt;//采样点数

        size_fh_i = sizeof(fh);
        size_th_i = sizeof(th);

        fread(&fh, size_fh_i,1,fp_input);//读取文件
        nt = exchangeLowHigh16(fh.hns);
        for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&th,size_th_i,1,fp_input);
            int SEQWL = exchangeLowHigh32(th.tracl);//读取线号
            int SEQWR = exchangeLowHigh32(th.tracr);//读取道号
            int FFID = exchangeLowHigh32(th.fldr);//读取X坐标
            int TRCFLD = exchangeLowHigh32(th.tracf);//读取Y坐标
            int SP = exchangeLowHigh32(th.ep);
            int CDP = exchangeLowHigh32(th.cdp);
            int TRCNUM = exchangeLowHigh32(th.cdpt);
            short TRCID = exchangeLowHigh16(th.trid);//29-30
            short NVST = exchangeLowHigh16(th.nvs);//31-32
            short NHST = exchangeLowHigh16(th.nhs);//33-34
            short DU = exchangeLowHigh16(th.duse);//35-36
            int DSREG = exchangeLowHigh32(th.offset);//37-40
            int RGE = exchangeLowHigh32(th.gelev);//41-44
            int SES = exchangeLowHigh32(th.selev);//45-48
            int SDBS = exchangeLowHigh32(th.sdepth);//49-52
            int DERG = exchangeLowHigh32(th.gdel);//53-56
            int DES = exchangeLowHigh32(th.sdel);//57-60
            int WDS = exchangeLowHigh32(th.swdep);//61-64
            int WGD = exchangeLowHigh32(th.gwdep);//65-68
            short SAED = exchangeLowHigh16(th.scalel);//69-70
            short SAC = exchangeLowHigh16(th.scalco);//71-72
            int SRCX = exchangeLowHigh32(th.sx);//73-76
            int SRCY = exchangeLowHigh32(th.sy);//77-80
            int GRPX = exchangeLowHigh32(th.gx);//81-84
            int GRPY = exchangeLowHigh32(th.gy);//85-88
            short UNITS = exchangeLowHigh16(th.counit);//89-90
            short WVEL = exchangeLowHigh16(th.wevel);//91-92
            short SVEL = exchangeLowHigh16(th.swevel);//93-94
            short UTSRC = exchangeLowHigh16(th.sut);//95-96
            short UTGRP = exchangeLowHigh16(th.gut);//97-98
            short SECSCOR = exchangeLowHigh16(th.sstat);//99-100
            short GRPSCOR = exchangeLowHigh16(th.gstat);//101-102
            short TSA = exchangeLowHigh16(th.tstat);//103-104
            short LAGTA = exchangeLowHigh16(th.laga);//105-106
            short LAGTB = exchangeLowHigh16(th.lagb);//107-108
            short DELRECT = exchangeLowHigh16(th.delrt);//109-110
            short MTSTART = exchangeLowHigh16(th.muts);//111-112
            short MTEND = exchangeLowHigh16(th.mute);//113-114
            short NSMP = exchangeLowHigh16(th.ns);//115-116
            short SI = exchangeLowHigh16(th.dt);//117-118
            short GTFI = exchangeLowHigh16(th.gain);//119-120
            short IG = exchangeLowHigh16(th.igc);//121-122
            short IGC = exchangeLowHigh16(th.igi);//123-124
            short CORREL = exchangeLowHigh16(th.corr);//125-126
            short SFSTART = exchangeLowHigh16(th.sfs);//127-128
            short SFEND = exchangeLowHigh16(th.sfe);//129-130
            short SLEN = exchangeLowHigh16(th.slen);//131-132
            short STYP = exchangeLowHigh16(th.styp);//133-134
            short SSTRLS = exchangeLowHigh16(th.stas);//135-136
            short SSTLE = exchangeLowHigh16(th.stae);//137-138
            short TTYP = exchangeLowHigh16(th.tatyp);//139-140
            short AFF = exchangeLowHigh16(th.afilf);//141-142
            short AFS = exchangeLowHigh16(th.afils);//143-144
            short NOFILF = exchangeLowHigh16(th.nofilf);//145-146
            short NOFILS = exchangeLowHigh16(th.nofils);//147-148
            short LOCF = exchangeLowHigh16(th.lcf);//149-150
            short HOCF = exchangeLowHigh16(th.hcf);//151-152
            short LOCS = exchangeLowHigh16(th.lcs);//153-154
            short HICS = exchangeLowHigh16(th.hcs);//155-156
            short YEAR = exchangeLowHigh16(th.year);//157-158
            short DAY = exchangeLowHigh16(th.day);//159-160
            short HOUR = exchangeLowHigh16(th.hour);//161-162
            short MINUTE = exchangeLowHigh16(th.minute);//163-164
            short SCE = exchangeLowHigh16(th.sec);//165-166
            short TMBS = exchangeLowHigh16(th.timbas);//167-168
            short TWF = exchangeLowHigh16(th.trwf);//169-170
            short GGNSW = exchangeLowHigh16(th.grnors);//171-172
            short GGN1ST = exchangeLowHigh16(th.grnors);//173-174
            short GGNLST = exchangeLowHigh16(th.grnlof);//175-176
            short GAPSZ = exchangeLowHigh16(th.gaps);//177-178
            short OAWT = exchangeLowHigh16(th.otrav);//179-180

            wholeTableWidget->setItem(i,0,new QTableWidgetItem(QString::number(SEQWL)));
            wholeTableWidget->setItem(i,1,new QTableWidgetItem(QString::number(SEQWR)));
            wholeTableWidget->setItem(i,2,new QTableWidgetItem(QString::number(FFID)));
            wholeTableWidget->setItem(i,3,new QTableWidgetItem(QString::number(TRCFLD)));
            wholeTableWidget->setItem(i,4,new QTableWidgetItem(QString::number(SP)));
            wholeTableWidget->setItem(i,5,new QTableWidgetItem(QString::number(CDP)));
            wholeTableWidget->setItem(i,6,new QTableWidgetItem(QString::number(TRCNUM)));
            wholeTableWidget->setItem(i,7,new QTableWidgetItem(QString::number(TRCID)));
            wholeTableWidget->setItem(i,8,new QTableWidgetItem(QString::number(NVST)));
            wholeTableWidget->setItem(i,9,new QTableWidgetItem(QString::number(NHST)));
            wholeTableWidget->setItem(i,10,new QTableWidgetItem(QString::number(DU)));
            wholeTableWidget->setItem(i,11,new QTableWidgetItem(QString::number(DSREG)));
            wholeTableWidget->setItem(i,12,new QTableWidgetItem(QString::number(RGE)));
            wholeTableWidget->setItem(i,13,new QTableWidgetItem(QString::number(SES)));
            wholeTableWidget->setItem(i,14,new QTableWidgetItem(QString::number(SDBS)));
            wholeTableWidget->setItem(i,15,new QTableWidgetItem(QString::number(DERG)));
            wholeTableWidget->setItem(i,16,new QTableWidgetItem(QString::number(DES)));
            wholeTableWidget->setItem(i,17,new QTableWidgetItem(QString::number(WDS)));
            wholeTableWidget->setItem(i,18,new QTableWidgetItem(QString::number(WGD)));
            wholeTableWidget->setItem(i,19,new QTableWidgetItem(QString::number(SAED)));
            wholeTableWidget->setItem(i,20,new QTableWidgetItem(QString::number(SAC)));
            wholeTableWidget->setItem(i,21,new QTableWidgetItem(QString::number(SRCX)));
            wholeTableWidget->setItem(i,22,new QTableWidgetItem(QString::number(SRCY)));
            wholeTableWidget->setItem(i,23,new QTableWidgetItem(QString::number(GRPX)));
            wholeTableWidget->setItem(i,24,new QTableWidgetItem(QString::number(GRPY)));
            wholeTableWidget->setItem(i,25,new QTableWidgetItem(QString::number(UNITS)));
            wholeTableWidget->setItem(i,26,new QTableWidgetItem(QString::number(WVEL)));
            wholeTableWidget->setItem(i,27,new QTableWidgetItem(QString::number(SVEL)));
            wholeTableWidget->setItem(i,28,new QTableWidgetItem(QString::number(UTSRC)));
            wholeTableWidget->setItem(i,29,new QTableWidgetItem(QString::number(UTGRP)));
            wholeTableWidget->setItem(i,30,new QTableWidgetItem(QString::number(SECSCOR)));
            wholeTableWidget->setItem(i,31,new QTableWidgetItem(QString::number(GRPSCOR)));
            wholeTableWidget->setItem(i,32,new QTableWidgetItem(QString::number(TSA)));
            wholeTableWidget->setItem(i,33,new QTableWidgetItem(QString::number(LAGTA)));
            wholeTableWidget->setItem(i,34,new QTableWidgetItem(QString::number(LAGTB)));
            wholeTableWidget->setItem(i,35,new QTableWidgetItem(QString::number(DELRECT)));
            wholeTableWidget->setItem(i,36,new QTableWidgetItem(QString::number(MTSTART)));
            wholeTableWidget->setItem(i,37,new QTableWidgetItem(QString::number(MTEND)));
            wholeTableWidget->setItem(i,38,new QTableWidgetItem(QString::number(NSMP)));
            wholeTableWidget->setItem(i,39,new QTableWidgetItem(QString::number(SI)));
            wholeTableWidget->setItem(i,40,new QTableWidgetItem(QString::number(GTFI)));
            wholeTableWidget->setItem(i,41,new QTableWidgetItem(QString::number(IG)));
            wholeTableWidget->setItem(i,42,new QTableWidgetItem(QString::number(IGC)));
            wholeTableWidget->setItem(i,43,new QTableWidgetItem(QString::number(CORREL)));
            wholeTableWidget->setItem(i,44,new QTableWidgetItem(QString::number(SFSTART)));
            wholeTableWidget->setItem(i,45,new QTableWidgetItem(QString::number(SFEND)));
            wholeTableWidget->setItem(i,46,new QTableWidgetItem(QString::number(SLEN)));
            wholeTableWidget->setItem(i,47,new QTableWidgetItem(QString::number(STYP)));
            wholeTableWidget->setItem(i,48,new QTableWidgetItem(QString::number(SSTRLS)));
            wholeTableWidget->setItem(i,49,new QTableWidgetItem(QString::number(SSTLE)));
            wholeTableWidget->setItem(i,50,new QTableWidgetItem(QString::number(TTYP)));
            wholeTableWidget->setItem(i,51,new QTableWidgetItem(QString::number(AFF)));
            wholeTableWidget->setItem(i,52,new QTableWidgetItem(QString::number(AFS)));
            wholeTableWidget->setItem(i,53,new QTableWidgetItem(QString::number(NOFILF)));
            wholeTableWidget->setItem(i,54,new QTableWidgetItem(QString::number(NOFILS)));
            wholeTableWidget->setItem(i,55,new QTableWidgetItem(QString::number(LOCF)));
            wholeTableWidget->setItem(i,56,new QTableWidgetItem(QString::number(HOCF)));
            wholeTableWidget->setItem(i,57,new QTableWidgetItem(QString::number(LOCS)));
            wholeTableWidget->setItem(i,58,new QTableWidgetItem(QString::number(HICS)));
            wholeTableWidget->setItem(i,59,new QTableWidgetItem(QString::number(YEAR)));
            wholeTableWidget->setItem(i,60,new QTableWidgetItem(QString::number(DAY)));
            wholeTableWidget->setItem(i,61,new QTableWidgetItem(QString::number(HOUR)));
            wholeTableWidget->setItem(i,62,new QTableWidgetItem(QString::number(MINUTE)));
            wholeTableWidget->setItem(i,63,new QTableWidgetItem(QString::number(SCE)));
            wholeTableWidget->setItem(i,64,new QTableWidgetItem(QString::number(TMBS)));
            wholeTableWidget->setItem(i,65,new QTableWidgetItem(QString::number(TWF)));
            wholeTableWidget->setItem(i,66,new QTableWidgetItem(QString::number(GGNSW)));
            wholeTableWidget->setItem(i,67,new QTableWidgetItem(QString::number(GGN1ST)));
            wholeTableWidget->setItem(i,68,new QTableWidgetItem(QString::number(GGNLST)));
            wholeTableWidget->setItem(i,69,new QTableWidgetItem(QString::number(GAPSZ)));
            wholeTableWidget->setItem(i,70,new QTableWidgetItem(QString::number(OAWT)));
        }

        fclose(fp_input);
}

/*
 ***************************************************
 * 函数：on_pushButton_clicked()
 * 作用：修改某个道头的信息
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */
/*
void AmendDialog::on_pushButton_clicked()
{   float *data;
    segy *Arry_traceheader;
    QString input = inputfile;
    const char *filename_input = NULL;
    std::string tmp = mytypeconversion->qstring2cstring(input);//先把qstring转为c++的string
    filename_input = tmp.data();//再将string转为char*类型

    FILE *fp_input = NULL,*fp_output;
    fp_input = fopen(filename_input,"rb");//打开文件


        segy th;//数据道头
        bhed fh;//数据卷头
        int size_fh_i;//卷头数据大小
        int size_th_i;//道头数据大小

        size_fh_i = sizeof(fh);
        size_th_i = sizeof(th);

        Arry_traceheader=(segy*)malloc(traceNum*size_th_i);
        memset(Arry_traceheader,0,traceNum*size_th_i);

        fread(&fh, size_fh_i,1,fp_input);//读取文件
        int nt = exchangeLowHigh16(fh.hns);

        data=(float*)malloc(nt*sizeof(float));
        memset(data,0,nt*sizeof(float));


    QString replace = ui->lineEdit->text().toUpper();
    //*****1-4字节*****
    if(replace == "SEQWL")
    {   for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&Arry_traceheader[i],size_th_i,1,fp_input);
            if(flag==1){Arry_traceheader[i].fldr = Arry_traceheader[i].tracl;}
            if(flag==2){Arry_traceheader[i].cdp = Arry_traceheader[i].tracl;}
            if(flag==3){Arry_traceheader[i].sx = Arry_traceheader[i].tracl;}
            if(flag==4){Arry_traceheader[i].sy = Arry_traceheader[i].tracl;}
            fread(data,nt*sizeof(float),1,fp_input);
        }

    fclose(fp_input);
    fp_output = fopen(filename_input,"wb");
    fwrite(&fh,size_fh_i,1,fp_output);

    for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                fwrite(data,nt*sizeof(float),1,fp_output);
            }
     QMessageBox::information(this,tr("tips"),tr("succeed!"));
    }
    //*****5-8字节*****
    else if(replace == "SEQWR")
    {   for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&Arry_traceheader[i],size_th_i,1,fp_input);
            if(flag==1){Arry_traceheader[i].fldr = Arry_traceheader[i].tracr;}
            if(flag==2){Arry_traceheader[i].cdp = Arry_traceheader[i].tracr;}
            if(flag==3){Arry_traceheader[i].sx = Arry_traceheader[i].tracr;}
            if(flag==4){Arry_traceheader[i].sy = Arry_traceheader[i].tracr;}
            fread(data,nt*sizeof(float),1,fp_input);
        }

    fclose(fp_input);
    fp_output = fopen(filename_input,"wb");
    fwrite(&fh,size_fh_i,1,fp_output);

    for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                fwrite(data,nt*sizeof(float),1,fp_output);
            }
    QMessageBox::information(this,tr("tips"),tr("succeed!"));
    }
    //*****13-16字节*****
    else if(replace == "TRCFLD")
    {   for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&Arry_traceheader[i],size_th_i,1,fp_input);
            if(flag==1){Arry_traceheader[i].fldr = Arry_traceheader[i].tracf;}
            if(flag==2){Arry_traceheader[i].cdp = Arry_traceheader[i].tracf;}
            if(flag==3){Arry_traceheader[i].sx = Arry_traceheader[i].tracf;}
            if(flag==4){Arry_traceheader[i].sy = Arry_traceheader[i].tracf;}
            fread(data,nt*sizeof(float),1,fp_input);
        }

    fclose(fp_input);
    fp_output = fopen(filename_input,"wb");
    fwrite(&fh,size_fh_i,1,fp_output);

    for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                fwrite(data,nt*sizeof(float),1,fp_output);
            }
    QMessageBox::information(this,tr("tips"),tr("succeed!"));
    }
    //*****17-20字节*****
    else if(replace == "SP")
    {   for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&Arry_traceheader[i],size_th_i,1,fp_input);
            if(flag==1){Arry_traceheader[i].fldr = Arry_traceheader[i].ep;}
            if(flag==2){Arry_traceheader[i].cdp = Arry_traceheader[i].ep;}
            if(flag==3){Arry_traceheader[i].sx = Arry_traceheader[i].ep;}
            if(flag==4){Arry_traceheader[i].sy = Arry_traceheader[i].ep;}
            fread(data,nt*sizeof(float),1,fp_input);
        }

    fclose(fp_input);
    fp_output = fopen(filename_input,"wb");
    fwrite(&fh,size_fh_i,1,fp_output);

    for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                fwrite(data,nt*sizeof(float),1,fp_output);
            }
    QMessageBox::information(this,tr("tips"),tr("succeed!"));
    }
    //*****25-28字节*****
    else if(replace == "TRCNUM")
    {   for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&Arry_traceheader[i],size_th_i,1,fp_input);
            if(flag==1){Arry_traceheader[i].fldr = Arry_traceheader[i].cdpt;}
            if(flag==2){Arry_traceheader[i].cdp = Arry_traceheader[i].cdpt;}
            if(flag==3){Arry_traceheader[i].sx = Arry_traceheader[i].cdpt;}
            if(flag==4){Arry_traceheader[i].sy = Arry_traceheader[i].cdpt;}
            fread(data,nt*sizeof(float),1,fp_input);
        }

    fclose(fp_input);
    fp_output = fopen(filename_input,"wb");
    fwrite(&fh,size_fh_i,1,fp_output);

    for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                fwrite(data,nt*sizeof(float),1,fp_output);
            }
    QMessageBox::information(this,tr("tips"),tr("succeed!"));
    }
    //*****29-30字节*****
    else if(replace == "TRCID")
    {   for(int i=0;i<traceNum;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&Arry_traceheader[i],size_th_i,1,fp_input);
            if(flag==1){Arry_traceheader[i].fldr = Arry_traceheader[i].trid;}
            if(flag==2){Arry_traceheader[i].cdp = Arry_traceheader[i].trid;}
            if(flag==3){Arry_traceheader[i].sx = Arry_traceheader[i].trid;}
            if(flag==4){Arry_traceheader[i].sy = Arry_traceheader[i].trid;}
            fread(data,nt*sizeof(float),1,fp_input);
        }

    fclose(fp_input);
    fp_output = fopen(filename_input,"wb");
    fwrite(&fh,size_fh_i,1,fp_output);

    for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                fwrite(data,nt*sizeof(float),1,fp_output);
            }
    QMessageBox::information(this,tr("tips"),tr("succeed!"));
    }
    else
    {   fclose(fp_input);
        QMessageBox::information(this,tr("tips"),tr("input right information"));
    }

    fclose(fp_output);

}

void AmendDialog::on_cancelButton_clicked()
{
   this->close();
}

/*
 ***************************************************
 * 函数：on_bias_pushButton_clicked()
 * 作用：使某个道头数据偏置
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 *
void AmendDialog::on_bias_pushButton_clicked()
{       int bias = ui->bias_lineEdit->text().toInt();
        float *data;
        segy *Arry_traceheader;
        QString input = inputfile;
        const char *filename_input = NULL;
        std::string tmp = mytypeconversion->qstring2cstring(input);//先把qstring转为c++的string
        filename_input = tmp.data();//再将string转为char*类型

        FILE *fp_input = NULL,*fp_output;
        fp_input = fopen(filename_input,"rb");//打开文件

        //*****************属性信息读取*******************
            segy th;//数据道头
            bhed fh;//数据卷头
            int size_fh_i;//卷头数据大小
            int size_th_i;//道头数据大小

            size_fh_i = sizeof(fh);
            size_th_i = sizeof(th);

            Arry_traceheader=(segy*)malloc(traceNum*size_th_i);
            memset(Arry_traceheader,0,traceNum*size_th_i);

            fread(&fh, size_fh_i,1,fp_input);//读取文件
            int nt = exchangeLowHigh16(fh.hns);

            data=(float*)malloc(nt*sizeof(float));
            memset(data,0,nt*sizeof(float));

        /*****线号偏置*****
        if(flag == 1)
        {   for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fread(&Arry_traceheader[i],size_th_i,1,fp_input);
                Arry_traceheader[i].fldr = exchangeLowHigh32(exchangeLowHigh32(Arry_traceheader[i].fldr)+bias);
                fread(data,nt*sizeof(float),1,fp_input);
            }

        fclose(fp_input);
        fp_output = fopen(filename_input,"wb");
        fwrite(&fh,size_fh_i,1,fp_output);

        for(int i=0;i<traceNum;i++)
                {
                    fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                    fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                    fwrite(data,nt*sizeof(float),1,fp_output);
                }
         QMessageBox::information(this,tr("tips"),tr("succeed!"));
        }
        /*****道号偏置*****
        else if(flag == 2)
        {   for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fread(&Arry_traceheader[i],size_th_i,1,fp_input);
                Arry_traceheader[i].cdp = exchangeLowHigh32(exchangeLowHigh32(Arry_traceheader[i].cdp)+bias);
                fread(data,nt*sizeof(float),1,fp_input);
            }

        fclose(fp_input);
        fp_output = fopen(filename_input,"wb");
        fwrite(&fh,size_fh_i,1,fp_output);

        for(int i=0;i<traceNum;i++)
                {
                    fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                    fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                    fwrite(data,nt*sizeof(float),1,fp_output);
                }
        QMessageBox::information(this,tr("tips"),tr("succeed!"));
        }
        /*****x坐标偏置*****
        else if(flag == 3)
        {   for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fread(&Arry_traceheader[i],size_th_i,1,fp_input);
                Arry_traceheader[i].sx = exchangeLowHigh32(exchangeLowHigh32(Arry_traceheader[i].sx)+bias);
                fread(data,nt*sizeof(float),1,fp_input);
            }

        fclose(fp_input);
        fp_output = fopen(filename_input,"wb");
        fwrite(&fh,size_fh_i,1,fp_output);

        for(int i=0;i<traceNum;i++)
                {
                    fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                    fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                    fwrite(data,nt*sizeof(float),1,fp_output);
                }
        QMessageBox::information(this,tr("tips"),tr("succeed!"));
        }
        /*****y坐标偏置*****8
        else if(flag == 4)
        {   for(int i=0;i<traceNum;i++)
            {
                fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                fread(&Arry_traceheader[i],size_th_i,1,fp_input);
                Arry_traceheader[i].sy = exchangeLowHigh32(exchangeLowHigh32(Arry_traceheader[i].sy)+bias);
                fread(data,nt*sizeof(float),1,fp_input);
            }

        fclose(fp_input);
        fp_output = fopen(filename_input,"wb");
        fwrite(&fh,size_fh_i,1,fp_output);

        for(int i=0;i<traceNum;i++)
                {
                    fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
                    fwrite(&Arry_traceheader[i],size_th_i,1,fp_output);
                    fwrite(data,nt*sizeof(float),1,fp_output);
                }
        QMessageBox::information(this,tr("tips"),tr("succeed!"));
        }

        else
        {   fclose(fp_input);
            QMessageBox::information(this,tr("tips"),tr("input right information"));
        }
        fclose(fp_output);
}
*/

