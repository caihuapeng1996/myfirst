#include "mydialog.h"
#include "ui_mydialog.h"
#include <QDebug>
#include <QButtonGroup>

MyDialog::MyDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MyDialog)
{
    ui->setupUi(this);

    mytypeconversion = new ITypeConversion();
    amend = new AmendDialog();
    amend->setModal(true);
    ui->textEdit->setReadOnly(true);
    setFixedSize(this->width(),this->height());
}

MyDialog::~MyDialog()
{
    delete ui;
    delete mytypeconversion;
    delete amend;

}

void MyDialog::slot_childGetTracePar(QStringList fileList)
{   for(int i=0;i<fileList.count();i++)//将多个文件名加入下拉文件框
    {
        ui->comboBox->addItem(fileList.at(i));
    }
    inputList.append(fileList);

    primeInfo();

    ui->nTraces_spinBox->setRange(1,traceNum);//设置范围
    ui->nTraces_spinBox->setValue(scanTraces);//要扫描的道数初始化为总道数

    tableWidget = new QTableWidget(this);
    tableWidget->setRowCount(traceNum);//设置行数
    tableWidget->setColumnCount(4);//设置列数

    QStringList header;//定义表头
    header<<"FFID"<<"CDP"<<"SRCX"<<"SRCY";//设置表头内容
    tableWidget->setHorizontalHeaderLabels(header);
    ui->traceHeaderInfo_verticalLayout->addWidget(tableWidget);
    connect(ui->comboBox,SIGNAL(currentIndexChanged(QString)),SLOT(primeInfo()));
    //connect(ui->comboBox,SIGNAL(currentIndexChanged(QString)),SLOT(showTrace()));
    connect(this,SIGNAL(signal_sendTraces(int,QString,int)),amend,SLOT(slot_getTraces(int,QString,int)));//向修改界面传递参数

}

/*
 ***************************************************
 * 函数：showTrace()
 * 作用：显示一道的信息
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */
/*
void MyDialog::showTrace()
{   //将QString转换为char*

    int i = ui->oneTrace_spinBox->value();
    QString input = ui->comboBox->currentText();
    const char *filename_input = NULL;
    std::string tmp = mytypeconversion->qstring2cstring(input);//先把qstring转为c++的string
    filename_input = tmp.data();//再将string转为char*类型

    FILE *fp_input = NULL;
    fp_input = fopen(filename_input,"rb");//打开文件
    //*****************属性信息读取*******************
        segy th;//数据道头
        bhed fh;//数据卷头
        int size_fh_i;//卷头数据大小
        int size_th_i;//道头数据大小
        int nt;//采样点数

        size_fh_i = sizeof(fh);
        size_th_i = sizeof(th);

        fread(&fh, size_fh_i,1,fp_input);//读取文件
        nt = exchangeLowHigh16(fh.hns);

        fseek(fp_input,3600+(240+sizeof(float)*nt)*(i-1),0);
        fread(&th,size_th_i,1,fp_input);

        int FFID = exchangeLowHigh32(th.fldr);//读取线号
        int CDP = exchangeLowHigh32(th.cdp);//读取道号
        int SX = exchangeLowHigh32(th.sx);//读取X坐标
        int SY = exchangeLowHigh32(th.sy);//读取Y坐标

        ui->inline_lineEdit->setText(QString::number(FFID));//显示线号
        ui->xline_lineEdit->setText(QString::number(CDP));//显示道号
        ui->x_lineEdit->setText(QString::number(SX));//显示X坐标
        ui->y_lineEdit->setText(QString::number(SY));//显示Y坐标

        fclose(fp_input);
}
*/

/*
 ***************************************************
 * 函数：on_scan_button_clicked()
 * 作用：显示道信息
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */
void MyDialog::on_scan_button_clicked()
{   tableWidget->clearContents();
    int currentTrace = ui->nTraces_spinBox->value();
//    qDebug()<<"current:"<<currentTrace;
    QString input = ui->comboBox->currentText();
    const char *filename_input = NULL;
    std::string tmp = mytypeconversion->qstring2cstring(input);//先把qstring转为c++的string
    filename_input = tmp.data();//再将string转为char*类型

    FILE *fp_input = NULL;
    fp_input = fopen(filename_input,"rb");//打开文件
    /*****************属性信息读取*******************/
        segy th;//数据道头
        bhed fh;//数据卷头
        int size_fh_i;//卷头数据大小
        int size_th_i;//道头数据大小
        int nt;//采样点数

        size_fh_i = sizeof(fh);
        size_th_i = sizeof(th);

        fread(&fh, size_fh_i,1,fp_input);//读取文件
        nt = exchangeLowHigh16(fh.hns);
        for(int i=0;i<currentTrace;i++)
        {
            fseek(fp_input,3600+(240+sizeof(float)*nt)*i,0);
            fread(&th,size_th_i,1,fp_input);
            int FFID = exchangeLowHigh32(th.fldr);//读取线号
            int CDP = exchangeLowHigh32(th.cdp);//读取道号
            int SX = exchangeLowHigh32(th.sx);//读取X坐标
            int SY = exchangeLowHigh32(th.sy);//读取Y坐标
            tableWidget->setItem(i,0,new QTableWidgetItem(QString::number(FFID)));
            tableWidget->setItem(i,1,new QTableWidgetItem(QString::number(CDP)));
            tableWidget->setItem(i,2,new QTableWidgetItem(QString::number(SX)));
            tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(SY)));
        }

        fclose(fp_input);
}

/*
 ***************************************************
 * 函数：primeInfo(QString)
 * 作用：显示道信息
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */
void MyDialog::primeInfo()
{   ui->primaryInfo_textEdit->clear();
    int nt;//采样点数
    int nx;//道数
    float dt;//采样率
    int first_trace_FFID;
    int last_trace_FFID;
    int first_trace_CDP;
    int last_trace_CDP; 
    QString inputFile = ui->comboBox->currentText();
    QString filetype;

    readproperty(inputFile, nt, nx, dt, filetype, first_trace_FFID, last_trace_FFID, first_trace_CDP, last_trace_CDP, start_time, end_time);
    traceNum = nx;
    ui->primaryInfo_textEdit->append(tr("Summary information"));
    ui->primaryInfo_textEdit->append("-------------------------");
    ui->primaryInfo_textEdit->append("file:\n"+inputFile);
    ui->primaryInfo_textEdit->append("-------------------------");
    ui->primaryInfo_textEdit->setEnabled(false);
    ui->primaryInfo_textEdit->append("# Traces\t\t:"+QString::number(traceNum));
    ui->primaryInfo_textEdit->append("# Trace Sample\t:"+QString::number(nt));
    ui->primaryInfo_textEdit->append("Sample Interval(ms)\t:"+QString::number(dt));
    ui->primaryInfo_textEdit->append("-------------------------");
    ui->primaryInfo_textEdit->append("First trace CDP\t:"+QString::number(first_trace_CDP));
    ui->primaryInfo_textEdit->append("First trace FFID\t:"+QString::number(first_trace_FFID));
    ui->primaryInfo_textEdit->append("Last trace CDP\t:"+QString::number(last_trace_CDP));
    ui->primaryInfo_textEdit->append("Last trace FFID\t:"+QString::number(last_trace_FFID));
    ui->primaryInfo_textEdit->setReadOnly(true);

}

/*
 ***************************************************
 * 函数：readproperty(QString filename, int &nt, int &nx, float &dt, QString &filetype,int &first_trace_FFID, int &last_trace_FFID, int &first_trace_CDP, int &last_trace_CDP,int &start_time, int &end_time)
 * 作用：显示道信息
 * 输入：文件路径，道数，采样点数等
 * 返回：道数，采样点数等
 * 编写：文青勇
****************************************************
 */
void MyDialog::readproperty(QString filename, int &nt, int &nx, float &dt, QString &filetype,int &first_trace_FFID, int &last_trace_FFID, int &first_trace_CDP, int &last_trace_CDP,int &start_time, int &end_time)
{
/******************输入文件名处理*****************/

    //将QString转换为char*
    const char *filename_input = NULL;
    std::string tmp = mytypeconversion->qstring2cstring(filename);//先把qstring转为c++的string
    filename_input = tmp.data();//再将string转为char*类型

    FILE *fp_input = NULL;
    fp_input = fopen(filename_input,"rb");//打开文件

/*****************属性信息读取*******************/
    segy th;//数据道头
    bhed fh;//数据卷头
    int size_fh_i;//卷头数据大小
    int size_th_i;//道头数据大小

    size_fh_i = sizeof(fh);
    size_th_i = sizeof(th);

    fread(&fh, size_fh_i,1,fp_input);//读取文件

    fread(&th,size_th_i,1,fp_input);

    nt = exchangeLowHigh16(fh.hns);
    dt = (float)exchangeLowHigh16(fh.hdt)/1000.0;//毫秒
    nxx = exchangeLowHigh16(fh.ntrpr);//每一个剖面的道数
    start_time = exchangeLowHigh16(th.muts);
    end_time = start_time + (nt-1) * dt;

    first_trace_CDP = exchangeLowHigh32(th.cdp);
    last_trace_CDP = first_trace_CDP + nxx - 1;
    first_trace_FFID = exchangeLowHigh32(th.fldr);

    fseek(fp_input,0,2);//指针重置
    int size_sgy = ftell(fp_input);
    nx=(size_sgy-size_fh_i)/(size_th_i+nt*sizeof(float));
    nyy = nx / nxx;
    last_trace_FFID = first_trace_FFID + nyy - 1;
    /*
     *nt;//采样点数int
     *nx;//道数int
     *ddt;//采样间隔
     *dt;//采样率float
     */
    /*判断数据类型*/

    if (fh.format == 5 || exchangeLowHigh16(fh.format) == 5)//IEEE
    {
        filetype = tr("IEEE(32 bits)");
    }
    else if(fh.format == 1 || exchangeLowHigh16(fh.format) == 1)//IBM
    {
       filetype = tr("IBM(32 bits)");
    }

    fclose(fp_input);
}

/*
 ***************************************************
 * 函数：on_inline_button_clicked()
 * 作用：显示修改界面，传递所要修改信息的标志
 * 输入：无
 * 返回：无
 * 编写：文青勇
****************************************************
 */


void MyDialog::on_cancel_button_clicked()
{
    this->close();
}

void MyDialog::on_showAllTraces_pushButton_clicked()
{
    emit signal_sendTraces(ui->nTraces_spinBox->value(),ui->comboBox->currentText(),4);
    amend->show();
}
