#include "ckmessagebox.h"
#include "ui_ckmessagebox.h"

ICkMessageBox::ICkMessageBox(QWidget *parent, QString WindowTitle,QString LabelText,QString CheckBoxText):
   QDialog(parent),
   ui(new Ui::ICkMessageBox)
{
    ui->setupUi(this);
    setFixedSize(this->width(),this->height());//让大小不变
    ui->label_Display->setText(LabelText);//显示的提示信息
    setWindowTitle(WindowTitle);//设置窗口标题
    ui->checkBox->setText(CheckBoxText);//设置复选框text
    /******连接信号槽*******/
    connect(ui->pushButton_OK,    SIGNAL(clicked(bool)),this,SLOT(slot_Ok_PushButton()));
    connect(ui->pushButton_Cancel,SIGNAL(clicked(bool)),this,SLOT(slot_Cancel_PushButton()));
}

ICkMessageBox::~ICkMessageBox()
{
    delete ui;
}
/*
 ***************************************************
 * 函数名：set_CheckBox_default()
 * 作用：用于用户设置复选框的初始状态
 * 输入：bool值，false为不选中，true为选中，默认不选中
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void ICkMessageBox::set_CheckBox_default(bool defa)
{
    ui->checkBox->setChecked(defa);
}
/*
 ***************************************************
 * 函数名：get_Status()
 * 作用：返回状态
 * 输入：
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void ICkMessageBox::get_Status(bool &ok, bool &cancel, bool &ck)
{
    ok = bOk;
    cancel = bCancel;
    ck = bCheakBox;
}
/*
 ***************************************************
 * 函数名：slot_Ok_PushButton()
 * 作用：返回复选框状态并退出
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void ICkMessageBox::slot_Ok_PushButton()
{
    ICkMessageBox::accept();//退出
    bOk = true;
    bCancel =false;
    bCheakBox = ui->checkBox->isChecked();
}
/*
 ***************************************************
 * 函数名：slot_Cancel_PushButton()
 * 作用：退出
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void ICkMessageBox::slot_Cancel_PushButton()
{
    ICkMessageBox::accept();//退出
    bOk = false;
    bCancel = true;
    bCheakBox = ui->checkBox->isChecked();
}
