/*
 *用于2D数据的引导滤波处理
 *
 */
#include "mythread.h"
#include "Gwen_use/GST.h"
#include "../libUtil/alloc.h"
#include "Gwen_use/sgy.h"


Mythread::Mythread()
{
        threadtypeconversion = new ITypeConversion;
}

Mythread::~Mythread()
{
    delete threadtypeconversion;

}

void Mythread::slot_compute_childGetPara(QString inputfile, QString outputfile, int x, int t)
{
    input_qstr = inputfile;
    output_qstr = outputfile;
    const char* ccp_input =  threadtypeconversion->qstring2cstring(input_qstr).data();//qstring转const char*
    const char* ccp_output = threadtypeconversion->qstring2cstring(output_qstr).data();
    input_chp=const_cast<char*>(ccp_input);//const char*转char*
    output_chp=const_cast<char*>(ccp_output);
    length_t_i = t;
    length_x_i = x;
}

void Mythread::run()
{
//    emit signal_compute_childSendString("*************************************");
//    emit signal_compute_childSendString("input file:" + input_qstr);
//    emit signal_compute_childSendString("output file:" + output_qstr);
//    if(input_qstr != NULL && output_qstr != NULL)//输入输出都不为空时进行计算
//    {


//        emit signal_compute_childSendString("input file:" + input_qstr);
//        emit signal_compute_childSendString("output file:" + input_qstr);

        guidedfilter2d_profile(input_chp, output_chp, length_x_i, length_t_i);
        emit signal_compute_childSendNum(100);
        emit signal_compute_childSendOver();

//    }
//    else
//    {
//        emit signal_compute_childSendString("..............read file error...........");
//    }
}
void Mythread::sleep(unsigned int msec)
{

    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);

}
void Mythread::guidedfilter2d_profile( char *filename_input,char *filename_output,int length_x,int length_t)
{

    FILE *fp_input = NULL;
    FILE *fp_output = NULL;

    float **data_input = NULL;
    float **data_output = NULL;
    float **data_guided = NULL;
    int size_sgy,nx;
    int *data_temp = NULL;

    segy *Array_traceheader  = NULL;
    segy traceheader;
    bhed fileheader;

//emit signal_compute_childSendString("**read file...");
//emit signal_compute_childSendNum(3);

    fp_input=fopen(filename_input,"rb");
    fp_output=fopen(filename_output,"wb");

    int size_fileheader=sizeof(fileheader);
    int size_traceheader=sizeof(traceheader);

    if(fp_output==NULL){
//        printf("Cannot open this R.sgy!!!\n");
          emit signal_compute_childSendString("****please open output file****");
//        system("pause");
//        exit(0);
        return ;
    }
    if(fp_input==NULL){
//        printf("Cannot open this inputfile!!!\n");
          emit signal_compute_childSendString("****please open input file****");
//        system("pause");
//        exit(0);
        return ;
    }



emit signal_compute_childSendNum(4);
emit signal_compute_childSendString("**read file succeed..");

//emit signal_compute_childSendNum(4);
//emit signal_compute_childSendString("**load parameters...");

    fread(&fileheader,size_fileheader,1,fp_input);
    //int nt=fileheader.hns;
    int nt=exchangeLowHigh16(fileheader.hns);
    int ddt=exchangeLowHigh16(fileheader.hdt);
    float dt=(float)ddt/1000000.0;

    fseek(fp_input,0,2);
    size_sgy=ftell(fp_input);
    nx=(size_sgy-size_fileheader)/(size_traceheader+nt*sizeof(float));
    //printf("nx=%d,nt=%d,dt=%.4f\n",nx,nt,dt);//QT显示时不需要



    fseek(fp_input,size_fileheader,0);
    Array_traceheader=(segy*)malloc(nx*sizeof(traceheader));
    memset(Array_traceheader,0,nx*sizeof(traceheader));

    data_temp=(int*)malloc(nt*sizeof(float));
    memset(data_temp,0,nt*sizeof(int));

emit signal_compute_childSendNum(9);
emit signal_compute_childSendString("**load parameters succeed..");

    data_input=alloc2float(nt,nx);
    memset(data_input[0],0,nt*nx*sizeof(float));
    data_output=alloc2float(nt,nx);
    memset(data_output[0],0,nt*nx*sizeof(float));
    data_guided=alloc2float(nt,nx);
    memset(data_guided[0],0,nt*nx*sizeof(float));

    fwrite(&fileheader,size_fileheader,1,fp_output);


//emit signal_compute_childSendNum(13);
//emit signal_compute_childSendString("**load data...");

    for(int ix=0;ix<nx;ix++){
            fread(&Array_traceheader[ix],size_traceheader,1,fp_input);
            fread(data_temp,nt*sizeof(int),1,fp_input);
            trace_ibm2pc(data_input[ix],data_temp,nt);
        }

emit signal_compute_childSendNum(18);
emit signal_compute_childSendString("**load data succeed...");

emit signal_compute_childSendNum(19);
emit signal_compute_childSendString("**start compute...");

        memcpy(data_guided[0],data_input[0],nt*nx*sizeof(float));

emit signal_compute_childSendNum(24);

        guidedfilter2d(data_input,data_guided,data_output,1, length_x, length_t, nx, nt);

 emit signal_compute_childSendNum(94);
emit signal_compute_childSendString("**compute complete");

emit signal_compute_childSendString("**save data...");

       for(int ix=0;ix<nx;ix++){
            fwrite(&Array_traceheader[ix],size_traceheader,1,fp_output);
            trace_pc2ibm(data_output[ix],data_temp,nt);
            fwrite(data_temp,nt*sizeof(int),1,fp_output);
        }

emit signal_compute_childSendNum(96);
emit signal_compute_childSendString("**save data succeed...");
emit signal_compute_childSendString("**close file...");

    free2float(data_output);
    free2float(data_input);
    free2float(data_guided);
    free(Array_traceheader);
    rewind(fp_input);
    fclose(fp_input);
    rewind(fp_output);
    fclose(fp_output);


}
void Mythread::guidedfilter2d(float **data_input,float **data_guided,float **data_output,float eps,int length_x,int length_t,int nx,int nt)
{
    float **mean_I = NULL;
    float **mean_p = NULL;
    float **mean_Ip = NULL;
    float **mean_II =NULL;
    float **Ip=NULL;
    float **II=NULL;

    float **cov_Ip=NULL;
    float **var_I=NULL;

    float **a=NULL;
    float **b=NULL;
    float **mean_a=NULL;
    float **mean_b=NULL;

    float max_I=0.0;
    float min_I=0.0;

    float max_p=0.0;
    float min_p=0.0;

emit signal_compute_childSendNum(26);//数据转换
emit signal_compute_childSendString("**.");
    mean_I=alloc2float(nt,nx);
    mean_p=alloc2float(nt,nx);
    mean_Ip=alloc2float(nt,nx);
    mean_II=alloc2float(nt,nx);
    Ip=alloc2float(nt,nx);
    II=alloc2float(nt,nx);

    cov_Ip=alloc2float(nt,nx);
    var_I=alloc2float(nt,nx);

    a=alloc2float(nt,nx);
    b=alloc2float(nt,nx);
    mean_a=alloc2float(nt,nx);
    mean_b=alloc2float(nt,nx);

emit signal_compute_childSendNum(28);//开辟内存空间
emit signal_compute_childSendString("**.");
    memset(mean_II[0],0,nt*nx*sizeof(float));
    memset(mean_I[0],0,nt*nx*sizeof(float));
    memset(mean_p[0],0,nt*nx*sizeof(float));
    memset(mean_Ip[0],0,nt*nx*sizeof(float));
    memset(Ip[0],0,nt*nx*sizeof(float));
    memset(II[0],0,nt*nx*sizeof(float));
    memset(cov_Ip[0],0,nt*nx*sizeof(float));
    memset(var_I[0],0,nt*nx*sizeof(float));

    memset(a[0],0,nt*nx*sizeof(float));
    memset(b[0],0,nt*nx*sizeof(float));
    memset(mean_a[0],0,nt*nx*sizeof(float));
    memset(mean_b[0],0,nt*nx*sizeof(float));


    max_I=data_input[0][0];
    min_I=data_input[0][0];
    max_p=data_guided[0][0];
    min_p=data_guided[0][0];
emit signal_compute_childSendNum(31);
emit signal_compute_childSendString("**.");
    for(int ix=0;ix<nx;ix++)
    {
         for(int it=0;it<nt;it++){
            if(max_I<data_input[ix][it]){
                max_I=data_input[ix][it];
            }
            if(min_I>data_input[ix][it]){
                min_I=data_input[ix][it];
            }

            if(max_p<data_guided[ix][it]){
                max_p=data_guided[ix][it];
            }
            if(min_p>data_guided[ix][it]){
                min_p=data_guided[ix][it];
            }
        }
         //一道一道的计算

    }

    //printf("max_I=%.2f,min_I=%.2f,max_p=%.2f,min_p=%.2f\n",max_I,min_I,max_p,min_p);

emit signal_compute_childSendNum(34);
emit signal_compute_childSendString("**..");
    for(int ix=0;ix<nx;ix++)
        {
           for(int it=0;it<nt;it++){
           data_input[ix][it]=(data_input[ix][it]-min_I)/(max_I-min_I);
           data_guided[ix][it]=(data_guided[ix][it]-min_p)/(max_I-min_p);
          }
    }
emit signal_compute_childSendNum(36);
emit signal_compute_childSendString("**...");
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
         Ip[ix][it]=data_input[ix][it]*data_guided[ix][it];
         II[ix][it]=data_input[ix][it]*data_input[ix][it];
        }
    }



emit signal_compute_childSendNum(40);
emit signal_compute_childSendString("**....");
    boxfilter2D(data_input,mean_I,nx,nt,length_t,length_x);
emit signal_compute_childSendNum(47);
emit signal_compute_childSendString("**.....");
    boxfilter2D(data_guided,mean_p,nx,nt,length_t,length_x);
emit signal_compute_childSendNum(54);
emit signal_compute_childSendString("**......");
    boxfilter2D(II,mean_II,nx,nt,length_t,length_x);
emit signal_compute_childSendNum(61);
emit signal_compute_childSendString("**.......");
    boxfilter2D(Ip,mean_Ip,nx,nt,length_t,length_x);

emit signal_compute_childSendNum(68);
emit signal_compute_childSendString("**........");
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
            cov_Ip[ix][it]=mean_Ip[ix][it]-mean_I[ix][it]*mean_p[ix][it];
            var_I[ix][it]=mean_II[ix][it]-mean_I[ix][it]*mean_I[ix][it];
        }
    }
emit signal_compute_childSendNum(70);
emit signal_compute_childSendString("**.........");
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
            a[ix][it]=cov_Ip[ix][it]/(eps+var_I[ix][it]);
            b[ix][it]=mean_p[ix][it]-a[ix][it]*mean_I[ix][it];
        }
    }

emit signal_compute_childSendNum(72);
emit signal_compute_childSendString("**..........");
    boxfilter2D(a,mean_a,nx,nt,length_t,length_x);
emit signal_compute_childSendNum(79);
emit signal_compute_childSendString("**...........");
    boxfilter2D(b,mean_b,nx,nt,length_t,length_x);
emit signal_compute_childSendNum(88);
emit signal_compute_childSendString("**............");
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
          data_output[ix][it]=a[ix][it]*data_input[ix][it]+b[ix][it];
        }
    }

emit signal_compute_childSendNum(90);
emit signal_compute_childSendString("**.............");
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
          data_output[ix][it]=a[ix][it]*data_input[ix][it]+b[ix][it];
        }
    }

emit signal_compute_childSendNum(92);
emit signal_compute_childSendString("**..............");
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
          data_output[ix][it]=(a[ix][it]*data_input[ix][it]+b[ix][it])*(max_I-min_I)+min_I;
        }
    }

    /*for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
          data_output[ix][it]=10*abs(data_input[ix][it]-data_output[ix][it])+data_output[ix][it];
        }
    }*/


emit signal_compute_childSendNum(94);
emit signal_compute_childSendString("**...............");
    free2float(mean_I);
    free2float(mean_p);
    free2float(mean_Ip);
    free2float(mean_II);
    free2float(Ip);
    free2float(II);
    free2float(cov_Ip);
    free2float(var_I);

    free2float(a);
    free2float(b);
    free2float(mean_a);
    free2float(mean_b);
}
void Mythread::boxfilter2D(float** data_input,float** data_output,int nx,int nt,int length_half_t,int length_half_x){

    float sum=0.0;
    int index_x=0;
    int index_t=0;

    int N_w=(2*length_half_t+1)*(2*length_half_x+1);

    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
            sum=0.0;

            for(int iw_x=-length_half_x;iw_x<=length_half_x;iw_x++){
                for(int iw_t=-length_half_t;iw_t<=length_half_t;iw_t++){
                    index_t=it+iw_t;
                    index_x=ix+iw_x;
                    if(index_t<=0){
                        index_t=0;
                    }
                    if(index_x<=0){
                        index_x=0;
                    }
                    if(index_t>=nt-1){
                        index_t=nt-1;
                    }
                    if(index_x>=nx-1){
                        index_x=nx-1;
                    }
                    sum=sum+data_input[index_x][index_t];
                }
            }

            data_output[ix][it]=sum/N_w;
        }
    }
}


