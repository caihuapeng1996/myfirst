#include "filesplit.h"
#include "ui_filesplit.h"
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QGridLayout>
#include <QScrollArea>
#include <QFileDialog>
#include <QString>
#include <QFont>
#include <QPixmap>
#include <QRegExp>
#include <QValidator>
#include <QIODevice>
#include "filesplitutils.h"
#include "filesplitconfig.h"

FileSplit::FileSplit(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FileSplit)
{
    ui->setupUi(this);

    //按钮绑定的函数
    connect(ui->btn_open,SIGNAL(clicked(bool)),this,SLOT(onClickOpen()));
    connect(ui->btn_scan,SIGNAL(clicked(bool)),this,SLOT(onClickScan()));
    connect(ui->mBtnStart,SIGNAL(clicked(bool)),this,SLOT(onClickStart()));
}
FileSplit::~FileSplit()
{
    delete ui;
}

void FileSplit::mousePressEvent(QMouseEvent* e){  // 鼠标的单击事件
    if(e->button()==Qt::LeftButton){
         mPressPos=e->pos();
         mPressed=true;
    }
}
void FileSplit::mouseMoveEvent(QMouseEvent* e){    // 鼠标的移动事件
   if(mPressed){
       move(e->globalPos()-mPressPos);
   }
}
void FileSplit::mouseReleaseEvent(QMouseEvent* e){  // 鼠标的单击释放事件
    mPressed=false;
}


void FileSplit::onClickOpen()
{
    QString filePath = QFileDialog::getOpenFileName(NULL,CONF_FILE_DIALOG_TITLE,".","*.*"); //文件选择对话框
    if(!filePath.isEmpty()){
//        mFilePathEdit->setText(filePath);
          ui->mFilePathEdit->setText(filePath);
    }
}

void FileSplit::onClickScan(){
      QString dirPath = QFileDialog::getExistingDirectory(NULL,CONF_DIR_DIALOG_TITLE,".");
      if(!dirPath.isEmpty()){
//          mDirPathEdit->setText(dirPath);
          ui->mDirPathEdit->setText(dirPath);
      }
}

void FileSplit::onClickStart()
{
    QString filePath = ui->mFilePathEdit->text();
    QString dirPath = ui->mDirPathEdit->text();
    QString fileSize = ui->mFileSizeEdit->text();
    int unitIndex = ui->mSizeUnit->currentIndex();

    if(!FileSplitUtils::islegalFilePath(filePath)){
        ui->mTextEdit->append(QWidget::tr("输入文件为空或者不存在。文件：").append(filePath));
        return;
    }

    if(!FileSplitUtils::islegalDirPath(dirPath)){
        ui->mTextEdit->append(QWidget::tr("输入目录为空或者不存在。目录：").append(dirPath));
        return;
    }

    qint64 splitSize=FileSplitUtils::calculateFileSize(fileSize,unitIndex);
    if(!FileSplitUtils::islegalSplitSize(filePath,splitSize)){
        ui->mTextEdit->append(QWidget::tr("分割的文件大小不合法，请重新输入。大小：").append(QString::number(splitSize,10)));
        return;
    }
    WorkerThread *workerThread = new WorkerThread(this);
    workerThread->setWorkerParams(filePath,dirPath,splitSize);
    connect(workerThread, SIGNAL(signalUpdate(int)), this, SLOT(onHandleUpdate(int)));
    connect(workerThread, SIGNAL(signalAppend(const QString&)), this, SLOT(onHandleAppend(const QString&)));
    // 线程结束后，自动销毁
    connect(workerThread, SIGNAL(finished()), workerThread, SLOT(deleteLater()));
    workerThread->start();

}

void FileSplit::onHandleUpdate(int value)
{
    ui->progressBar->setValue(value);
    if(value==0){
        ui->mBtnStart->setEnabled(false);  //按钮无法点击
    }else if(value==100){
        ui->mBtnStart->setEnabled(true); //按钮恢复可以点击
    }
}

void FileSplit::onHandleAppend(const QString &appendText)
{
    ui->mTextEdit->append(appendText);
}

WorkerThread::WorkerThread(QObject *parent):QThread(parent)
{

}

WorkerThread::~WorkerThread(){

}

void WorkerThread::setWorkerParams(const QString& filePath,const QString& dirPath,const qint64 splitSize){
    this->mFilePath=filePath;
    this->mDirPath=dirPath;
    this->mSplitSize=splitSize;
}

void WorkerThread::run(){
    QFile srcFile(mFilePath);
    if(srcFile.open(QIODevice::ReadOnly)){
        qint64 fileSize=srcFile.size(); //文件的总大小
        int splitFileNum=(fileSize+mSplitSize-1)/mSplitSize; //计算要分割成多少个文件
        signalUpdate(0); //按钮无法点击
        qint64 count=0; //统计总共写了多少
        qint64 buffSize = (mSplitSize>BUFF_SIZE_MB)?BUFF_SIZE_MB:BUFF_SIZE_KB; //如果分割文件大于1M，每次读文件时读 1M，否则读取4k
        char* buff=new char[buffSize];  //申请4k大小的buffer
        QString fileName=FileSplitUtils::getFileName(mFilePath);
        QString splitFilePath;
        for(int i=0;i<splitFileNum;i++){
             splitFilePath.clear();  //需要先清空字符串
             splitFilePath.append(mDirPath); //目录
             splitFilePath.append("/");
             splitFilePath.append(fileName); //拼接上文件名
             splitFilePath.append("_part");
             splitFilePath.append(QString::number(i,10));
             splitFilePath.append(".xtc"); //拼接完成后变成 xxx_partx.xtc
             QFile destFile(splitFilePath);
             qint64 copySize=0;  //要写到文件的大小
             qint64 size = 0; //每次读写的大小，默认是4k
             if(destFile.open(QIODevice::WriteOnly)){
                 signalAppend(QWidget::tr("正在写入文件：").append(splitFilePath));
                 copySize=fileSize-count; //剩余的文件大小
                 copySize=(copySize>mSplitSize)?mSplitSize:copySize;  //考虑最后一个要写的文件大小
                 while(copySize>0){  //
                       size=(copySize>buffSize)?buffSize:copySize;  //考虑最后一次可能小于4k
                       srcFile.read(buff,size);   //读
                       destFile.write(buff,size); //写
                       copySize-=size;  //减到已经copy的大小
                       count+=size;  //加上已经copy的大小
                       signalUpdate(count*100/fileSize);  //更新进度条,乘以100 会不会溢出呢？？
                 }
                 destFile.flush();//强制写出
                 destFile.close(); //关闭文件
                 signalAppend(QWidget::tr("文件写入完成"));
             }else{
                 signalAppend(QWidget::tr("如下文件无法创建和打开。"));
                 signalAppend(splitFilePath);
             }
        }
        delete buff; //释放buffer
        //文件分割完成
        srcFile.close();
        signalUpdate(100);  //进度到100% //按钮恢复可以点击
        signalAppend(QWidget::tr("文件分割完成。"));
    }else{
        signalAppend(QWidget::tr("文件打开失败，请确认如下文件是否可以操作。"));
        signalAppend(mFilePath);
    }

}



