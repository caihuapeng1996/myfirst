#include "mythread3d.h"
#include "Gwen_use/PMfilter.h"

Mythread3d::Mythread3d()
{
    threadtypeconversion = new ITypeConversion;
}

Mythread3d::~Mythread3d()
{
    delete threadtypeconversion;
}

void Mythread3d::slot_compute_childGetPara(QString inputfile, QString outputfile,QString output_temp_, int nxx_, int nyy_,int iter_max_,float  scale_,float kappa_,float delatt_,int index_)
{
    str_input = threadtypeconversion->qstring2cstring(inputfile);
    input_chp = str_input.c_str();

    str_output = threadtypeconversion->qstring2cstring(outputfile);
    output_chp = str_output.c_str();

    str_output_temp = threadtypeconversion->qstring2cstring(output_temp_);
    output_chp_temp = str_output_temp.c_str();

    nxx = nxx_;
    nyy = nyy_;
    iter_max = iter_max_;
    scale = scale_;
    kappa = kappa_;
    delatt = delatt_;
    index = index_;
    output_temp = output_temp_;
}

void Mythread3d::slot_childGetComplement(int flag_, int first_CDP_, int last_CDP_, int nyy_, QString input_com_)
{
    complement = flag_;
    first_CDP = first_CDP_;
    last_CDP = last_CDP_;
    int ny = nyy_;
    std::string str_input;
    const char *input_chp;
    str_input = threadtypeconversion->qstring2cstring(input_com_);
    input_chp = str_input.c_str();

    strcpy(filename_input,input_chp);
    qDebug()<<"input"<<first_CDP;
    if(complement==1){
            seismic_fix(filename_input,"test_fix.sgy",ny);
            strcpy(filename_input,"test_fix.sgy");
    }
}

void Mythread3d::run()
{
    if(index==1)
    {
     int nx;
     int ny;
     float scale;
     float kappa;
     int iter_max;
     char filename_input[320];
     char filename_output[320];

     //PMfilter2D_Profile(filename_input,filename_output,scale,kappa,iter_max);
    }
    else if(index==2)
    {
           int nx = nxx;
           int ny = nyy;
           //int flag=complement;
           char *temp12;
           char *temp13;
           //char temp2[320]="cube_temp.sgy";
           //char temp3[320];
           //char temp1[320];
           //char temp[320];
           char temp2[320];
           char temp3[320];

           char temp[320];
           char temp1[320];
           temp12=temp2;
           temp13=temp3;
           //qDebug()<<"flag:"<<flag;
           if(complement == 0)
           {strcpy(filename_input,input_chp);}
           strcpy(temp2,output_chp);
           strcpy(temp3,output_chp_temp);
           strcpy(temp1,temp3);

          for(int iter=0;iter<iter_max;iter++){
              if(iter==0){
                  sleep(100);
                   d_space(filename_input,temp2,nx,ny,iter,scale,kappa,delatt);
              }

              else{
                  d_space(temp2,temp3,nx,ny,iter,scale,kappa,delatt);
                  sleep(100);
                  strcpy(temp,temp2);
                  strcpy(temp2,temp3);
                  strcpy(temp3,temp);
              }
          }

         emit signal_compute_childSendNum(100);
         if(iter_max%2==1){
            remove(temp3);
            rename(temp2,temp1);
         }else{
           remove(temp3);
           }
    }
    else{
         printf("输入参数错误！！！");
         system("pause");
      }
}
void Mythread3d::sleep(unsigned int msec)
{

    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);

}
/*
void Mythread::PMfilter2D_Profile(char *filename_input,char *filename_output,float scale,double kappa,int iter_max)
{
        FILE *fp_input;
        FILE *fp_output;

        float **data_input;
        float **data_output;
        segy *Array_traceheader;
        int *data_temp;
        int nx;
        int ny=1;
        int size_sgy;
        segy traceheader;
        bhed fileheader;

        int size_fileheader=sizeof(fileheader);
        int size_traceheader=sizeof(traceheader);

        fp_input=fopen(filename_input,"rb");
        fp_output=fopen(filename_output,"wb");


        if(fp_input==NULL){
            printf("Cannot open this inputfile!!!\n");
            system("pause");
            exit(0);
        }

        if(fp_output==NULL){
            printf("Cannot open this R.sgy!!!\n");
            system("pause");
            exit(0);
        }



        fread(&fileheader,size_fileheader,1,fp_input);
        int nt=exchangeLowHigh16(fileheader.hns);
        float dt=(float)exchangeLowHigh16(fileheader.hdt)/1000000.0;

        fseek(fp_input,0,2);
        size_sgy=ftell(fp_input);

        nx=(size_sgy-size_fileheader)/(size_traceheader+nt*sizeof(float));

        fseek(fp_input,size_fileheader,0);
        Array_traceheader=(segy*)malloc(nx*sizeof(traceheader));
        memset(Array_traceheader,0,nx*sizeof(traceheader));

        data_temp=(int*)malloc(nt*sizeof(float));
        memset(data_temp,0,nt*sizeof(int));
        data_input=alloc2float(nt,nx);
        memset(data_input[0],0,nt*nx*sizeof(float));
        data_output=alloc2float(nt,nx);
        memset(data_output[0],0,nt*nx*sizeof(float));

        fwrite(&fileheader,size_fileheader,1,fp_output);
        for(int iy=0;iy<ny;iy++){
            for(int ix=0;ix<nx;ix++){
                fread(&Array_traceheader[ix],size_traceheader,1,fp_input);
                fread(data_temp,nt*sizeof(int),1,fp_input);
                trace_ibm2pc(data_input[ix],data_temp,nt);

            }

            PMfilter2D(data_input,data_output,nt,nx,iter,kappa,scale);

            for(int ix=0;ix<nx;ix++){
                fwrite(&Array_traceheader[ix],size_traceheader,1,fp_output);
                 trace_pc2ibm(data_output[ix],data_temp,nt);
                fwrite(data_temp,nt*sizeof(int),1,fp_output);
            }


        }


        free(data_temp);
        free2float(data_output);
        free2float(data_input);
        free(Array_traceheader);
        fclose(fp_input);
        fclose(fp_output);
}*/

/*
void Mythread::PMfilter2D(float **data_input,float **data_output,int nt,int nx,int iter,float kappa,float scale)




{
    float **data_past;
    float **data_temp;
    float **temp;
    data_past=alloc2float(nt,nx);
    data_temp=alloc2float(nt,nx);
    memset(data_past[0],0,nt*nx*sizeof(float));
    memset(data_temp[0],0,nt*nx*sizeof(float));

    //memcpy(data_past[0],data_input[0],nt*nx*sizeof(float));

    int iUp;
    int iDown;
    int iLeft;
    int iRight;
    float deltaN=0.0;
    float deltaS=0.0;
    float deltaE=0.0;
    float deltaW=0.0;

    float cN=0.0;
    float cS=0.0;
    float cE=0.0;
    float cW=0.0;

    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
            data_past[ix][it]=data_input[ix][it]/scale;
        }
    }

    float lamada=0.15;
    for(int it=0;it<iter;it++){
    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
         iUp=it-1;
         iDown=it+1;
         iRight=ix+1;
         iLeft=ix-1;

         if(it==0){
             iUp=0;
         }
         if(ix==0){
             iLeft=0;
         }
         if(it==nt-1){
             iDown=nt-1;
         }
         if(ix==nx-1){
             iRight=nx-1;
         }

        deltaN=data_past[ix][iUp]-data_past[ix][it];
        deltaS=data_past[ix][iDown]-data_past[ix][it];
        deltaE=data_past[iRight][it]-data_past[ix][it];
        deltaW=data_past[iLeft][it]-data_past[ix][it];

        cN=exp(-deltaN*deltaN/(kappa*kappa));
        cS=exp(-deltaS*deltaS/(kappa*kappa));
        cE=exp(-deltaE*deltaE/(kappa*kappa));
        cW=exp(-deltaW*deltaW/(kappa*kappa));

        data_temp[ix][it]=data_past[ix][it]+lamada*(cN*deltaN+cS*deltaS+cE*deltaE+cW*deltaW);

        }
     }
        temp=data_past;
        data_past=data_temp;
        data_temp=temp;
    }

    for(int ix=0;ix<nx;ix++){
        for(int it=0;it<nt;it++){
            data_output[ix][it]=data_output[ix][it]*scale;
        }

    }

    memcpy(data_output[0],data_past[0],nx*nt*sizeof(float));




    free2float(data_past);
    free2float(data_temp);
}
*/

void Mythread3d::seismic_fix(const char *filename_input,const char *filename_output,int ny)
{
    FILE *fp_input;
    FILE *fp_output;
    segy traceheader;
    segy *Arry_traceheader;
    bhed fileheader;

    int size_traceheader=sizeof(traceheader);
    int size_fileheader=sizeof(fileheader);
    int nt;
    int index_min = first_CDP;
    int index_max = last_CDP;


    //printf("请输入最小的道号：");
    //scanf("%d",&index_min);
    //printf("请输入最大的道号：");
    //scanf("%d",&index_max);


    int nx=index_max-index_min+1;

    int fldr_old;
    int fldr_new;
    int tracf,flag=0;
    int ix,i1,i2,i3,i4;

    float **data;
    float *data1;
    int  *data1_temp;

    fp_input=fopen(filename_input,"rb");
    fp_output=fopen(filename_output,"wb");

    if(fp_input==NULL){
        //printf("Cannot open this input file!!!\n");
        //system("pause");
        //exit(0);
        return ;
    }

    if(fp_output==NULL){
        //printf("Cannot open this output file!!!\n");
        //system("pause");
        //exit(0);
        return ;
    }

    fread(&fileheader,size_fileheader,1,fp_input);
    fread(&traceheader,size_traceheader,1,fp_input);
    nt=exchangeLowHigh16(fileheader.hns);
    printf("NT=%d\n",nt);
    fldr_old=exchangeLowHigh32(traceheader.fldr);
    fldr_new=exchangeLowHigh32(traceheader.fldr);

    data=alloc2float(nt,nx);
    Arry_traceheader=(segy*)malloc(nx*size_traceheader);
    data1=(float*)malloc(nt*sizeof(float));
    data1_temp=(int*)malloc(nt*sizeof(float));

    memset(data[0],0,nt*nx*sizeof(float));
    memset(data1_temp,0,nt*sizeof(int));
    memset(data1,0,nt*sizeof(float));
    memset(Arry_traceheader,0,nx*size_traceheader);

    fseek(fp_input,size_fileheader,0);
    fread(&traceheader,size_traceheader,1,fp_input);
    i1=exchangeLowHigh32(traceheader.tracf);
    i2=exchangeLowHigh32(traceheader.cdp);
    fread(data1_temp,nt*sizeof(int),1,fp_input);
    fread(&traceheader,size_traceheader,1,fp_input);
    i3=exchangeLowHigh32(traceheader.tracf);
    i4=exchangeLowHigh32(traceheader.cdp);
   // printf("I1=%d,I2=%d,I3=%d,I4=%d\n",i1,i2,i3,i4);
    if((i1==i3)&&(i4=i2+1))flag=1; //cdp
    if((i2==0)&&(i3=i1+1))flag=0;//tracf


    fseek(fp_input,0,0);
    fseek(fp_input,size_fileheader,0);
    fwrite(&fileheader,size_fileheader,1,fp_output);

    for(unsigned int iy=0;iy<ny;iy++){
        while(fldr_new==fldr_old){

          fread(&traceheader,size_traceheader,1,fp_input);
          fread(data1_temp,nt*sizeof(int),1,fp_input);
          if(flag==1)tracf=exchangeLowHigh32(traceheader.cdp);
          if(flag==0) tracf=exchangeLowHigh32(traceheader.tracf);
         // printf("%d\n",tracf);
          ix=tracf-index_min;
          /*for(unsigned int it=0;it<nt;it++){
              data1[it]=ibm2pc(data1_temp[it]);
          }
*/
          trace_ibm2pc(data1,data1_temp,nt);


          if((ix>=0)&&(ix<nx)){
              memcpy(data[ix],data1,nt*sizeof(float));
              Arry_traceheader[ix]=traceheader;
          }
          fread(&traceheader,size_traceheader,1,fp_input);
         // fseek(fp_input,-size_traceheader,1);
         _fseeki64(fp_input,(long long)(-size_traceheader),1);
          fldr_new=exchangeLowHigh32(traceheader.fldr);
        }

        fldr_old=fldr_new;

        for(ix=0;ix<nx;ix++){
            fwrite(&Arry_traceheader[ix],size_traceheader,1,fp_output);
            /*for(int it=0;it<nt;it++){
                data1_temp[it]=pc2ibm(data[ix][it]);
            }*/
            trace_pc2ibm(data[ix],data1_temp,nt);
            fwrite(data1_temp,nt*sizeof(int),1,fp_output);

        }
         //printf("正在修正测线号=%d\n",iy);
         memset(data[0],0,nt*nx*sizeof(float));
         memset(Arry_traceheader,0,nx*size_traceheader);
    }

emit signal_compute_childSendString("补全完成");


    fclose(fp_input);
    fclose(fp_output);
    free(data1);
    free(data1_temp);
    free2float(data);
    free(Arry_traceheader);
}

void Mythread3d:: d_space(const char *filename_input,const char *filename_output,int nx,int ny,int iter,float scale,float kappa,float deltt){
    /******************************************************************


    ******************************************************************/

      FILE *fp_input;
      FILE *fp_output;
      segy traceheader;
      bhed fileheader;
      long long size_traceheader=sizeof(traceheader);
      long long size_fileheader=sizeof(fileheader);
      long long nt;
      long long index_s;
      segy *Arry_traceheader;
      long long size_trace;
      float ***data;
      float **data_output;
      short flag;
      int *data_temp;

      fp_input=fopen(filename_input,"rb");
      fp_output=fopen(filename_output,"wb");

      qDebug()<<"input:"<<filename_input;
      qDebug()<<"output:"<<filename_output;

      //emit signal_compute_childSendString("——————开始迭代一次——————");
      emit signal_compute_childSendNum(iter*10+1);
      if(fp_input==NULL){
         // printf("Cannot open input file!!!");
          //system("pause");
          //exit(0);
          return ;
      }
      if(fp_output==NULL){
          // printf("Cannot open input file!!!");
         // system("pause");
          //exit(0);
          return ;
      }

      Arry_traceheader=(segy*)malloc(nx*ny*size_traceheader);
      memset(Arry_traceheader,0,nx*ny*size_traceheader);
      fread(&fileheader,size_fileheader,1,fp_input);

      nt=exchangeLowHigh16(fileheader.hns);

      size_trace=nt*sizeof(float);
      size_trace=nt*sizeof(float)+size_traceheader;
      //printf("%d",nt);

     for(int iy=0;iy<ny;iy++){
          for(int ix=0;ix<nx;ix++){
              fread(&Arry_traceheader[iy*nx+ix],size_traceheader,1,fp_input);
             _fseeki64(fp_input,nt*sizeof(float),1);
              //printf("%d\n",Arry_traceheader[(iy)*nx+ix].dt);
          }
      }


      data=alloc3float(nt,nx,3);
      memset(data[0][0],0,nx*nt*3*sizeof(float));
      data_output=alloc2float(nt,nx);
      memset(data_output[0],0,nt*nx*sizeof(float));
      data_temp=(int*)malloc(nt*sizeof(int));
      memset(data_temp,0,nt*sizeof(int));


      _fseeki64(fp_input,size_fileheader,0);
      fwrite(&fileheader,size_fileheader,1,fp_output);
      for(int iy=0;iy<ny;iy++){
          index_s=size_fileheader+(iy-1)*nx*size_trace;
         if(iy==0){
              index_s=size_fileheader;
          }

          if(iy==ny-1){
              index_s=size_fileheader+(ny-3)*nx*size_trace;
          }

          _fseeki64(fp_input,index_s,0);
          for(int iw=0;iw<3;iw++){
              for(int ix=0;ix<nx;ix++){
                  _fseeki64(fp_input,size_traceheader,1);
                  fread(data_temp,nt*sizeof(int),1,fp_input);
                  trace_ibm2pc(data[iw][ix],data_temp,nt);
              }
          }

          PM_filter3DL(data,data_output,nx,3,nt,kappa,deltt,scale,iter);
        /*  for(int ix=0;ix<nx;ix++){
              for(int it=0;it<nt;it++){
                  data_output[ix][it]=data[1][ix][it];
              }
          }*/

          for(int ix=0;ix<nx;ix++){
                //flag = exchangeLowHigh16(Arry_traceheader[iy*nx + ix].trid);
                //if (flag == 1) {
                 fwrite(&Arry_traceheader[iy*nx+ix],size_traceheader,1,fp_output);
                 trace_pc2ibm(data_output[ix],data_temp,nt);
                 fwrite(data_temp,nt*sizeof(int),1,fp_output);
               // }
          }

          // printf("迭代次数=%d,计算测线号=%d\n",iter,iy);
      }
      emit signal_compute_childSendNum(iter*10+10);
      free(data_temp);
      free(Arry_traceheader);
      free3float(data);
      free2float(data_output);
      fclose(fp_input);
      fclose(fp_output);
}

void Mythread3d::PM_filter3DL(float ***data_input,float **data_output,int nx,int ny,int nt,float kappa,float delta_t,float scale,int iter){
    float temp1;
    float temp2;
    float temp3;

    float h1=sqrt(3.0);
    float h2=sqrt(2.0);
    float h3=1.0;

    offset i11;
    offset i12;
    offset i13;
    offset i14;
    offset i15;
    offset i16;
    offset i17;
    offset i18;
    offset i19;
    offset i21;
    offset i22;
    offset i23;
    offset i24;
    offset i25;
    offset i26;
    offset i27;
    offset i28;
    offset i29;
    offset i31;
    offset i32;
    offset i33;
    offset i34;
    offset i35;
    offset i36;
    offset i37;
    offset i38;
    offset i39;

    float c11=0.0;
    float c12=0.0;
    float c13=0.0;
    float c14=0.0;
    float c15=0.0;
    float c16=0.0;
    float c17=0.0;
    float c18=0.0;
    float c19=0.0;
    float c21=0.0;
    float c22=0.0;
    float c23=0.0;
    float c24=0.0;
    float c25=0.0;
    float c26=0.0;
    float c27=0.0;
    float c28=0.0;
    float c29=0.0;
    float c31=0.0;
    float c32=0.0;
    float c33=0.0;
    float c34=0.0;
    float c35=0.0;
    float c36=0.0;
    float c37=0.0;
    float c38=0.0;
    float c39=0.0;

    float p11=0.0;
    float p12=0.0;
    float p13=0.0;
    float p14=0.0;
    float p15=0.0;
    float p16=0.0;
    float p17=0.0;
    float p18=0.0;
    float p19=0.0;
    float p21=0.0;
    float p22=0.0;
    float p23=0.0;
    float p24=0.0;
    float p25=0.0;
    float p26=0.0;
    float p27=0.0;
    float p28=0.0;
    float p29=0.0;
    float p31=0.0;
    float p32=0.0;
    float p33=0.0;
    float p34=0.0;
    float p35=0.0;
    float p36=0.0;
    float p37=0.0;
    float p38=0.0;
    float p39=0.0;

    float ***data_past=alloc3float(nt,nx,ny);
    memset(data_past[0][0],0,nt*nx*ny*sizeof(float));

    if(iter==0){
    for(int iy=0;iy<ny;iy++){
        for(int ix=0;ix<nx;ix++){
            for(int it=0;it<nt;it++){
                data_past[iy][ix][it]=data_input[iy][ix][it]/scale;
            }
        }
    }
    }else{
        for(int iy=0;iy<ny;iy++){
        for(int ix=0;ix<nx;ix++){
            for(int it=0;it<nt;it++){
                data_past[iy][ix][it]=data_input[iy][ix][it];
            }
        }
    }
    }
    float ***data_temp=alloc3float(nt,nx,ny);
    memset(data_temp[0][0],0,nt*nx*ny*sizeof(float));

        for(int iy=0;iy<ny;iy++){
            if(iy==1){
            for(int ix=0;ix<nx;ix++){
                for(int it=0;it<nt;it++){
                    i11=offset_assign(it-1,ix-1,iy-1);
                    i12=offset_assign(it-1,ix,iy-1);
                    i13=offset_assign(it-1,ix+1,iy-1);
                    i14=offset_assign(it-1,ix-1,iy);
                    i15=offset_assign(it-1,ix,iy);
                    i16=offset_assign(it-1,ix+1,iy);
                    i17=offset_assign(it-1,ix-1,iy+1);
                    i18=offset_assign(it-1,ix,iy+1);
                    i19=offset_assign(it-1,ix+1,iy+1);

                    i21=offset_assign(it,ix-1,iy-1);
                    i22=offset_assign(it,ix,iy-1);
                    i23=offset_assign(it,ix+1,iy-1);
                    i24=offset_assign(it,ix-1,iy);
                    i25=offset_assign(it,ix,iy);
                    i26=offset_assign(it,ix+1,iy);
                    i27=offset_assign(it,ix-1,iy+1);
                    i28=offset_assign(it,ix,iy+1);
                    i29=offset_assign(it,ix+1,iy+1);

                    i31=offset_assign(it+1,ix-1,iy-1);
                    i32=offset_assign(it+1,ix,iy-1);
                    i33=offset_assign(it+1,ix+1,iy-1);
                    i34=offset_assign(it+1,ix-1,iy);
                    i35=offset_assign(it+1,ix,iy);
                    i36=offset_assign(it+1,ix+1,iy);
                    i37=offset_assign(it+1,ix-1,iy+1);
                    i38=offset_assign(it+1,ix,iy+1);
                    i39=offset_assign(it+1,ix+1,iy+1);


                    if(it==0){
                    i11=offset_assign(it,ix,iy);
                    i12=offset_assign(it,ix,iy);
                    i13=offset_assign(it,ix,iy);
                    i14=offset_assign(it,ix,iy);
                    i15=offset_assign(it,ix,iy);
                    i16=offset_assign(it,ix,iy);
                    i17=offset_assign(it,ix,iy);
                    i18=offset_assign(it,ix,iy);
                    i19=offset_assign(it,ix,iy);
                    }


                    if(it==nt-1){
                    i31=offset_assign(it,ix,iy);
                    i32=offset_assign(it,ix,iy);
                    i33=offset_assign(it,ix,iy);
                    i34=offset_assign(it,ix,iy);
                    i35=offset_assign(it,ix,iy);
                    i36=offset_assign(it,ix,iy);
                    i37=offset_assign(it,ix,iy);
                    i38=offset_assign(it,ix,iy);
                    i39=offset_assign(it,ix,iy);
                    }

                    if(ix==0){
                    i11=offset_assign(it,ix,iy);
                    i14=offset_assign(it,ix,iy);
                    i17=offset_assign(it,ix,iy);
                    i21=offset_assign(it,ix,iy);
                    i24=offset_assign(it,ix,iy);
                    i27=offset_assign(it,ix,iy);
                    i31=offset_assign(it,ix,iy);
                    i34=offset_assign(it,ix,iy);
                    i37=offset_assign(it,ix,iy);
                    }

                    if(ix==nx-1){
                    i13=offset_assign(it,ix,iy);
                    i16=offset_assign(it,ix,iy);
                    i19=offset_assign(it,ix,iy);
                    i23=offset_assign(it,ix,iy);
                    i26=offset_assign(it,ix,iy);
                    i29=offset_assign(it,ix,iy);
                    i33=offset_assign(it,ix,iy);
                    i36=offset_assign(it,ix,iy);
                    i39=offset_assign(it,ix,iy);
                    }

                    if(iy==0){
                    i11=offset_assign(it,ix,iy);
                    i12=offset_assign(it,ix,iy);
                    i13=offset_assign(it,ix,iy);
                    i21=offset_assign(it,ix,iy);
                    i22=offset_assign(it,ix,iy);
                    i23=offset_assign(it,ix,iy);
                    i31=offset_assign(it,ix,iy);
                    i32=offset_assign(it,ix,iy);
                    i33=offset_assign(it,ix,iy);
                    }

                    if(iy==ny-1){
                    i17=offset_assign(it,ix,iy);
                    i18=offset_assign(it,ix,iy);
                    i19=offset_assign(it,ix,iy);
                    i27=offset_assign(it,ix,iy);
                    i28=offset_assign(it,ix,iy);
                    i29=offset_assign(it,ix,iy);
                    i37=offset_assign(it,ix,iy);
                    i38=offset_assign(it,ix,iy);
                    i39=offset_assign(it,ix,iy);
                    }


                    c11=(data_past[i11.y][i11.x][i11.t]-data_past[iy][ix][it]);
                    c12=(data_past[i12.y][i12.x][i12.t]-data_past[iy][ix][it]);
                    c13=(data_past[i13.y][i13.x][i13.t]-data_past[iy][ix][it]);
                    c14=(data_past[i14.y][i14.x][i14.t]-data_past[iy][ix][it]);
                    c15=(data_past[i15.y][i15.x][i15.t]-data_past[iy][ix][it]);
                    c16=(data_past[i16.y][i16.x][i16.t]-data_past[iy][ix][it]);
                    c17=(data_past[i17.y][i17.x][i17.t]-data_past[iy][ix][it]);
                    c18=(data_past[i18.y][i18.x][i18.t]-data_past[iy][ix][it]);
                    c19=(data_past[i19.y][i19.x][i19.t]-data_past[iy][ix][it]);


                    c21=(data_past[i21.y][i21.x][i21.t]-data_past[iy][ix][it]);
                    c22=(data_past[i22.y][i22.x][i22.t]-data_past[iy][ix][it]);
                    c23=(data_past[i23.y][i23.x][i23.t]-data_past[iy][ix][it]);
                    c24=(data_past[i24.y][i24.x][i24.t]-data_past[iy][ix][it]);
                    c25=(data_past[i25.y][i25.x][i25.t]-data_past[iy][ix][it]);
                    c26=(data_past[i26.y][i26.x][i26.t]-data_past[iy][ix][it]);
                    c27=(data_past[i27.y][i27.x][i27.t]-data_past[iy][ix][it]);
                    c28=(data_past[i28.y][i28.x][i28.t]-data_past[iy][ix][it]);
                    c29=(data_past[i29.y][i29.x][i29.t]-data_past[iy][ix][it]);

                    c31=(data_past[i31.y][i31.x][i31.t]-data_past[iy][ix][it]);
                    c32=(data_past[i32.y][i32.x][i32.t]-data_past[iy][ix][it]);
                    c33=(data_past[i33.y][i33.x][i33.t]-data_past[iy][ix][it]);
                    c34=(data_past[i34.y][i34.x][i34.t]-data_past[iy][ix][it]);
                    c35=(data_past[i35.y][i35.x][i35.t]-data_past[iy][ix][it]);
                    c36=(data_past[i36.y][i36.x][i36.t]-data_past[iy][ix][it]);
                    c37=(data_past[i37.y][i37.x][i37.t]-data_past[iy][ix][it]);
                    c38=(data_past[i38.y][i38.x][i38.t]-data_past[iy][ix][it]);
                    c39=(data_past[i39.y][i39.x][i39.t]-data_past[iy][ix][it]);

                    p11=exp(-1.0*c11*c11/(kappa*kappa));
                    p12=exp(-1.0*c12*c12/(kappa*kappa));
                    p13=exp(-1.0*c13*c13/(kappa*kappa));
                    p14=exp(-1.0*c14*c14/(kappa*kappa));
                    p15=exp(-1.0*c15*c15/(kappa*kappa));
                    p16=exp(-1.0*c16*c16/(kappa*kappa));
                    p17=exp(-1.0*c17*c17/(kappa*kappa));
                    p18=exp(-1.0*c18*c18/(kappa*kappa));
                    p19=exp(-1.0*c19*c19/(kappa*kappa));

                    p21=exp(-1.0*c21*c21/(kappa*kappa));
                    p22=exp(-1.0*c22*c22/(kappa*kappa));
                    p23=exp(-1.0*c23*c23/(kappa*kappa));
                    p24=exp(-1.0*c24*c24/(kappa*kappa));
                    p25=exp(-1.0*c25*c25/(kappa*kappa));
                    p26=exp(-1.0*c26*c26/(kappa*kappa));
                    p27=exp(-1.0*c27*c27/(kappa*kappa));
                    p28=exp(-1.0*c28*c28/(kappa*kappa));
                    p29=exp(-1.0*c29*c29/(kappa*kappa));

                    p31=exp(-1.0*c31*c31/(kappa*kappa));
                    p32=exp(-1.0*c32*c32/(kappa*kappa));
                    p33=exp(-1.0*c33*c33/(kappa*kappa));
                    p34=exp(-1.0*c34*c34/(kappa*kappa));
                    p35=exp(-1.0*c35*c35/(kappa*kappa));
                    p36=exp(-1.0*c36*c36/(kappa*kappa));
                    p37=exp(-1.0*c37*c37/(kappa*kappa));
                    p38=exp(-1.0*c38*c38/(kappa*kappa));
                    p39=exp(-1.0*c39*c39/(kappa*kappa));

                    temp1=p11*c11/(h1*h1)+p12*c12/(h2*h2)+p13*c13/(h1*h1)+p14*c14/(h2*h2)+p15*c15/(h3*h3)+p16*c16/(h2*h2)+p17*c17/(h1*h1)+p18*c18/(h2*h2)+p19*c19/(h1*h1);
                    temp2=p21*c21/(h2*h2)+p22*c22/(h3*h3)+p23*c23/(h2*h2)+p24*c24/(h3*h3)+p25*c25/(h3*h3)+p26*c26/(h3*h3)+p27*c27/(h2*h2)+p28*c28/(h3*h3)+p29*c29/(h2*h2);
                    temp3=p31*c31/(h1*h1)+p32*c32/(h2*h2)+p33*c33/(h1*h1)+p34*c34/(h2*h2)+p35*c35/(h3*h3)+p36*c36/(h2*h2)+p37*c37/(h1*h1)+p38*c38/(h2*h2)+p39*c39/(h1*h1);

                    data_temp[iy][ix][it]=data_past[iy][ix][it]+delta_t*(temp1+temp2+temp3);
                }
            }
            }
        }




        for(int ix=0;ix<nx;ix++){
            for(int it=0;it<nt;it++){
                data_output[ix][it]=data_temp[1][ix][it];
            }
        }


    free3float(data_past);
    free3float(data_temp);
    emit signal_compute_childSendString("*********一个剖面完成*********");
}


    offset offset_assign(int t,int x,int y){
        offset a;
        a.t=t;
        a.x=x;
        a.y=y;
        return a;
    }


