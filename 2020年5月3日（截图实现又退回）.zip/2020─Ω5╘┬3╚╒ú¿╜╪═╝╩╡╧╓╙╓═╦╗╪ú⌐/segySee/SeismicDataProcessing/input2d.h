#ifndef IINPUT2D_H
#define IINPUT2D_H

#include <QDialog>
#include <QString>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QTreeWidget>
#include <QMenu>
#include <QDebug>

#include "typeconversion.h"
#include "Gwen_use/GST.h"
#include "../libUtil/alloc.h"
#include "Gwen_use/sgy.h"

namespace Ui {
class IInput2D;
}

class IInput2D : public QDialog
{
    Q_OBJECT

public:
    explicit IInput2D(QWidget *parent = 0);
    ~IInput2D();

    QStringList get_Inputfile_list();


private slots:
    void slot_OpenFile();//打开文件

    void slot_Ok_PushButton();//确定按钮

    void slot_Cancel_PushButton();//取消按钮

    void slot_Left_Clicked();//鼠标左键在树形图上的单机动作的槽函数

    void slot_Right_Clicked(const QPoint &);//鼠标右键单击出现菜单

    void slot_DeleteItem();//删除选中项

private:
    Ui::IInput2D *ui;
    ITypeConversion *mytypeconversion;//数据转换

    QStringList qslInputFile_list_gv;//输入文件列表


    int nNumOf_file = 0;//记录list中读取到第几个文件了，多次输入的时候，不从头读，从上一次读取的位置开始
};

#endif // IINPUT2D_H
