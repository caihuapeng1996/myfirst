/*
 *用于2D数据的引导滤波处理
 *
 */
#include "tempfiledialog.h"
#include "ui_tempfiledialog.h"

QString Temp_File_Name;//全局变量，记录中间位置的路径

TempFileDialog::TempFileDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TempFileDialog)
{
    ui->setupUi(this);


    connect(ui->Save_pushButton,//保存
            SIGNAL(clicked(bool)),
            this,
            SLOT(slot_Save()));

    connect(ui->Quit_pushButton,//退出
            SIGNAL(clicked(bool)),
            this,
            SLOT(slot_Quit()));
    display();

    setWindowTitle(tr("已读入文件"));
}

TempFileDialog::~TempFileDialog()
{
    delete ui;
}
/*
 ***************************************************
 ***************************************************
 * 显示
 ***************************************************
 ***************************************************
 */
void TempFileDialog::display()
{
    QFile file(Temp_File_Name);
    //--打开文件成功
    if (file.open(QIODevice ::ReadOnly | QIODevice ::Text))
    {
        QTextStream textStream(&file);
        while (!textStream.atEnd())
        {
            //---QtextEdit按行显示文件内容
            ui->Display_textBrowser->append(textStream.readLine());
        }
        file.close();//关闭文件
    }
    else    //---打开文件失败
    {
       QMessageBox::information(this, QString::fromLocal8Bit("tips"), tr("打开文件失败"));
    }

}
/*
 ***************************************************
 ***************************************************
 * 保存
 ***************************************************
 ***************************************************
 */
void TempFileDialog::slot_Save()
{
    QString save_file_name = QFileDialog::getSaveFileName(this,tr("保存至"),QDir::currentPath(),tr("*.txt"));
    if(!save_file_name.isEmpty())
    {
         //检查文件有无后缀，没有则默认添加.txt
         if( QFileInfo(save_file_name).suffix().isEmpty())//后缀为空
         {
             save_file_name.append(".txt");
         }
         QFile file(save_file_name);
         if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
         {
             QMessageBox::warning(this, tr("Write File"),tr("打开保存文件出错，请确保文件存在。"));
             return;
         }
         QTextStream out(&file);
         out << ui->Display_textBrowser->toPlainText();
         out.flush();
         file.close();
         QMessageBox::information(this, QString::fromLocal8Bit("tips"), tr("保存成功"));
     }
    else
    {
         QMessageBox::warning(this, tr("Path"),tr("数据未保存！！"));
     }
}
/*
 ***************************************************
 ***************************************************
 * 退出
 ***************************************************
 ***************************************************
 */
void TempFileDialog::slot_Quit()
{
    TempFileDialog::accept();
}
