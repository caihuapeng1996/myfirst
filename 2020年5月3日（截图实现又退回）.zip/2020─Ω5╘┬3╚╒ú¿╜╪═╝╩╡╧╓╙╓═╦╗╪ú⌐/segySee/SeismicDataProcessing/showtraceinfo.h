#ifndef SHOWTRACEINFO_H
#define SHOWTRACEINFO_H

#include <QWidget>
#include "../libSegy/segyreadwrite.h"


namespace Ui {
class showTraceInfo;
}

class showTraceInfo : public QWidget
{
    Q_OBJECT

public:
    explicit showTraceInfo(QWidget *parent = nullptr);
    ~showTraceInfo();
    SegyReadWrite srw;


public slots:
    void showTraceHead(SegyReadWrite s);
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();
    void slot_traceInfo();

    void slot_onlineEditChanged();
    void slot_onlineEdit_2Changed();

private:
    Ui::showTraceInfo *ui;
};

#endif // SHOWTRACEINFO_H
