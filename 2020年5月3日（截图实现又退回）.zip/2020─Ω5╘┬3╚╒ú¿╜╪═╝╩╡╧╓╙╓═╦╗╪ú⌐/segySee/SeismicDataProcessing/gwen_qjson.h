#ifndef QJSON_H
#define QJSON_H

#include <QtCore>

class IQJson
{
public:
    IQJson();//构造函数
    void json_write();//写json文件
    void json_read();//读json文件
};

#endif // QJSON_WRITE

