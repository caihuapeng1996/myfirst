#ifndef WXML_H
#define WXML_H

#include <QtWidgets>
#include <QXmlStreamReader>
#include <QDomDocument>
#include <QDebug>


class IWXml
{
public:
    IWXml();//构造函数
    ~IWXml();
    bool WriteXml(QString &path, QTreeWidgetItem *pitem);//写
    bool DeleteXml(QString &path, QTreeWidgetItem *pitem);//删
private:
    void WriteItem(QTreeWidgetItem *item);
private:
    QXmlStreamWriter qxswXml_gv;


};
#endif // WRXML

