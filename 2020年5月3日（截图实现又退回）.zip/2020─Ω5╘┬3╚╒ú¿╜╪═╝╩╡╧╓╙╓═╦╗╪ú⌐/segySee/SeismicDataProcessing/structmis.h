#ifndef STRUCTMIS_H_
#define STRUCTMIS_H_

typedef struct
{
    int trace;//记录道号

    int x_coor;//记录x坐标

    int y_coor;//记录y坐标
}SCoor;

#endif // STRUCTMIS

