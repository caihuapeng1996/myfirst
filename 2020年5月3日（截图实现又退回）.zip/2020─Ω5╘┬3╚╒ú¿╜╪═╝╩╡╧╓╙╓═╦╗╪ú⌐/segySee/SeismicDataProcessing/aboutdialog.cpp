#include "aboutdialog.h"
#include "ui_aboutdialog.h"

AboutDialog::AboutDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AboutDialog)
{
    ui->setupUi(this);
    //setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);
    setFixedSize(this->width(),this->height());
    connect(ui->pushButton,
            SIGNAL(clicked(bool)),
            this,
            SLOT(slot_OK_pushButton()));
    setWindowTitle("Copyright");
}

AboutDialog::~AboutDialog()
{
    delete ui;
}
/*
 ***************************************************
 ***************************************************
 * 退出
 ***************************************************
 ***************************************************
 */
void AboutDialog::slot_OK_pushButton()
{
    AboutDialog::accept();
}
