#include "showtraceinfo.h"
#include "ui_showtraceinfo.h"
#include <QDebug>
#include "mainwindow.h"

showTraceInfo::showTraceInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::showTraceInfo)
{
     ui->setupUi(this);

     connect(ui->tableWidget, SIGNAL(itemSelectionChanged()),this,SLOT(slot_traceInfo()));
     connect(ui->lineEdit,SIGNAL(returnPressed()), this, SLOT(slot_onlineEditChanged()));
     connect(ui->lineEdit_2,SIGNAL(returnPressed()), this, SLOT(slot_onlineEdit_2Changed()));

}

showTraceInfo::~showTraceInfo()
{
    delete ui;
}

void showTraceInfo::showTraceHead(SegyReadWrite s)
{
    //显示第一个线表格
    this->srw = s;
    ui->lineEdit->setText(QString("%1").arg(srw.getInlineBegin()));
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setRowCount(srw.getTracePerLine());


    ui->tableWidget->setHorizontalHeaderLabels(QStringList() <<"trace number"<<"inline"<<"xline"<<"sx"<<"sy"<<"fan wei");
    ui->tableWidget->verticalHeader()->setVisible(false); // 隐藏水平header
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
   // ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectItems);
  //  ui->tableWidget->verticalHeader()->setDefaultSectionSize(50);//

    for(int i=0;i<ui->tableWidget->rowCount();i++)
    {
        QString a1 = QString("%1").arg(i+1);
        ui->tableWidget->setItem(i,0, new QTableWidgetItem(a1));
        QString a2 = QString("%1").arg(srw.getInlineBegin());
        ui->tableWidget->setItem(i,1, new QTableWidgetItem(a2));
        QString a3 = QString("%1").arg(srw.getXlineBegin()+i);
        ui->tableWidget->setItem(i,2, new QTableWidgetItem(a3));
        QString a4 = QString("%1").arg((srw.getTraceHead())[i]->sx);
        ui->tableWidget->setItem(i,3, new QTableWidgetItem(a4));
        QString a5 = QString("%1").arg((srw.getTraceHead())[i]->sy);
        ui->tableWidget->setItem(i,4, new QTableWidgetItem(a5));
         QString a6=QString::fromStdString("13-16");
        ui->tableWidget->setItem(i,5, new QTableWidgetItem(a6));
    }
    //第二个道数据表格
    ui->tableWidget_2->setColumnCount(3);
    QStringList header;  //QString类型的List容器
    header<<"Index"<<"Times(ms)"<<"Sample";
    ui->tableWidget_2->setHorizontalHeaderLabels(header);
    ui->tableWidget_2->resizeColumnsToContents();
    ui->tableWidget_2->resizeRowsToContents();
    ui->tableWidget_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget_2->setRowCount(srw.getSamplePerTrace());
    ui->tableWidget_2->verticalHeader()->hide();//隐藏标号
    ui->tableWidget_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//适应表格大小
//
    ui->tableWidget_2->hide();
    ui->lineEdit_2->hide();
    ui->pushButton_3->hide();
    ui->pushButton_4->hide();

}
//选线，上一条线
void showTraceInfo::on_pushButton_clicked()
{
//    qDebug()<<"上一线";
    if(ui->lineEdit->text().toInt()<=srw.getInlineBegin())
    {
        QMessageBox::critical(NULL, "critical", "这是初始线，没有上一条线", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
    }
    else
    {
        ui->lineEdit->setText(QString("%1").arg(ui->lineEdit->text().toInt()-1));

       // int a1=ui->lineEdit->text().toInt()-1;

        int num=ui->lineEdit->text().toInt();
         int n=num-srw.getInlineBegin();
         for(int i=0;i<srw.getTracePerLine();i++)
        {
             QString a1 = QString("%1").arg((n*srw.getTracePerLine()+i+1));
             QString a2 = QString("%1").arg(num);
             QString a4 = QString("%1").arg((srw.getTraceHead())[i+n*srw.getTracePerLine()]->sx);
             QString a5 = QString("%1").arg((srw.getTraceHead())[i+n*srw.getTracePerLine()]->sy);


               ui->tableWidget->setItem(i,0, new QTableWidgetItem(a1));
                ui->tableWidget->setItem(i,1, new QTableWidgetItem(a2));
                ui->tableWidget->setItem(i,3, new QTableWidgetItem(a4));
                ui->tableWidget->setItem(i,4, new QTableWidgetItem(a5));
         }

    }



}
//下一条线
void showTraceInfo::on_pushButton_2_clicked()
{
//     qDebug()<<"下一线";
     if(ui->lineEdit->text().toInt()>=srw.getInlineEnd())
     {
         QMessageBox::critical(NULL, "critical", "这是中止线，没有下一条线", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
     }
     else
     {
    ui->lineEdit->setText(QString("%1").arg(ui->lineEdit->text().toInt()+1));

  int num=ui->lineEdit->text().toInt();
   int n=num-srw.getInlineBegin();
   for(int i=0;i<srw.getTracePerLine();i++)
  {
       QString a1 = QString("%1").arg((n*srw.getTracePerLine()+i+1));
       QString a2 = QString("%1").arg(num);
       QString a4 = QString("%1").arg((srw.getTraceHead())[i+n*srw.getTracePerLine()]->sx);
       QString a5 = QString("%1").arg((srw.getTraceHead())[i+n*srw.getTracePerLine()]->sy);
       ui->tableWidget->setItem(i,0, new QTableWidgetItem(a1));
          ui->tableWidget->setItem(i,1, new QTableWidgetItem(a2));
          ui->tableWidget->setItem(i,3, new QTableWidgetItem(a4));
          ui->tableWidget->setItem(i,4, new QTableWidgetItem(a5));
   }
   }
}

//选道，上一道
void showTraceInfo::on_pushButton_3_clicked()
{

    if(ui->lineEdit_2->text().toInt()<=1)
    {
          QMessageBox::critical(NULL, "critical", "没有上一道", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
    }
    else
    {
        ui->lineEdit_2->setText(QString("%1").arg(ui->lineEdit_2->text().toInt()-1));
       int num = ui->lineEdit_2->text().toInt();
       //int num=ui->;
       for(int i=0;i<srw.getSamplePerTrace();i++){
           QString a1 = QString("%1").arg(srw.getTimeBegin()+srw.getInterval()*i/1000);
           QString a2 =QString::number((srw.getData())[num-1][i], 'f', 3);
           ui->tableWidget_2->setItem(i,0,new QTableWidgetItem(QString::number(i)));
          ui->tableWidget_2->setItem(i,1,new QTableWidgetItem(a1));
           ui->tableWidget_2->setItem(i,2,new QTableWidgetItem(a2));

     }
    //   num-n*srw.getTracePerLine();
        ui->tableWidget->selectRow(num%srw.getTracePerLine()-1);

    }



}



//下一道
void showTraceInfo::on_pushButton_4_clicked()
{
//    qDebug()<<"daohao"<<ui->lineEdit_2->text();
    if(ui->lineEdit_2->text().toInt()>=srw.getTraceCount())
    {
         QMessageBox::critical(NULL, "critical", "没有下一道", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
    }
    else
    {
        ui->lineEdit_2->setText(QString("%1").arg(ui->lineEdit_2->text().toInt()+1));
        int num = ui->lineEdit_2->text().toInt();
       // qDebug()<<"这是下一dao"<<ui->lineEdit->text().toInt()+1;
        for(int i=0;i<srw.getSamplePerTrace();i++){
            QString a1 = QString("%1").arg(srw.getTimeBegin()/1000+srw.getInterval()*i/1000);
            QString a2 =QString::number((srw.getData())[num-1][i], 'f', 3);
            ui->tableWidget_2->setItem(i,0,new QTableWidgetItem(QString::number(i)));
            ui->tableWidget_2->setItem(i,1,new QTableWidgetItem(a1));
            ui->tableWidget_2->setItem(i,2,new QTableWidgetItem(a2));
      }
         ui->tableWidget->selectRow(num%srw.getTracePerLine()-1);
    }


}

//选中表格数据，刷新道数据
void showTraceInfo::slot_traceInfo()
{
    int num = ui->lineEdit->text().toInt();
    int n=num-srw.getInlineBegin();

//    qDebug()<<"xuanzhong"<<ui->tableWidget->currentRow();
//      qDebug()<<"n"<<n;
      QString str =QString("%1").arg(ui->tableWidget->currentRow()+1+n*srw.getTracePerLine());
     ui->lineEdit_2->setText(str);
//     qDebug()<<str;

//     qDebug()<<num;
     for(int i=0;i<srw.getSamplePerTrace();i++)
     {
         QString a1 = QString("%1").arg(srw.getTimeBegin()+srw.getInterval()*i/1000);
         QString a2 =QString::number(srw.getData()[str.toInt()-1][i], 'f', 3);
         ui->tableWidget_2->setItem(i,0,new QTableWidgetItem(QString::number(i)));
         ui->tableWidget_2->setItem(i,1,new QTableWidgetItem(a1));
         ui->tableWidget_2->setItem(i,2,new QTableWidgetItem(a2));

     }
     ui->tableWidget_2->show();
     ui->lineEdit_2->show();
     ui->pushButton_3->show();
     ui->pushButton_4->show();
}


   //回车切换线
void showTraceInfo::slot_onlineEditChanged()
{
//   qDebug()<<"hhahhhah"<<ui->lineEdit->text();
   int num = ui->lineEdit->text().toInt();
   int n=num-srw.getInlineBegin();
   for(int i=0;i<srw.getTracePerLine();i++)
  {
       QString a1 = QString("%1").arg((n*srw.getTracePerLine()+i+1));
       QString a2 = QString("%1").arg(num);
       QString a4 = QString("%1").arg((srw.getTraceHead())[i+n*srw.getTracePerLine()]->sx);
       QString a5 = QString("%1").arg((srw.getTraceHead())[i+n*srw.getTracePerLine()]->sy);
       ui->tableWidget->setItem(i,0, new QTableWidgetItem(a1));
          ui->tableWidget->setItem(i,1, new QTableWidgetItem(a2));
          ui->tableWidget->setItem(i,3, new QTableWidgetItem(a4));
          ui->tableWidget->setItem(i,4, new QTableWidgetItem(a5));
   }
}
 //回车切换道
void showTraceInfo::slot_onlineEdit_2Changed()
{
//     qDebug()<<"9199199191"<<ui->lineEdit_2->text();
     int num = ui->lineEdit_2->text().toInt();
     for(int i=0;i<srw.getSamplePerTrace();i++)
     {
         QString a1 = QString("%1").arg(srw.getTimeBegin()/1000+srw.getInterval()*i/1000);
         QString a2 =QString::number((srw.getData())[num-1][i], 'f', 3);
         ui->tableWidget_2->setItem(i,0,new QTableWidgetItem(QString::number(i)));
         ui->tableWidget_2->setItem(i,1,new QTableWidgetItem(a1));
         ui->tableWidget_2->setItem(i,2,new QTableWidgetItem(a2));
   }
   ui->tableWidget->selectRow(num%srw.getTracePerLine()-1);
}

