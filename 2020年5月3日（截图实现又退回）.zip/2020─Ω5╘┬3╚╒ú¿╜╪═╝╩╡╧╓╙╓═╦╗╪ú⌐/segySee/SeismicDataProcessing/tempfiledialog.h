/*
 *用于2D数据的引导滤波处理
 *
 */
#ifndef TEMPFILEDIALOG_H
#define TEMPFILEDIALOG_H
#pragma once

#include <QDialog>
#include <QFile>
#include <QString>
#include <QTextStream>
#include <QMessageBox>
#include <QFileDialog>
#include "iodisplay.h"

#define TEMP_FILE_NAME  "tempfile.txt"
class IODisplay;

namespace Ui {
class TempFileDialog;
}

class TempFileDialog : public QDialog
{
    Q_OBJECT

public:
    explicit TempFileDialog(QWidget *parent = 0);
    ~TempFileDialog();
    void display();//显示
private slots:
    void slot_Save();//保存
    void slot_Quit();//退出

private:
    Ui::TempFileDialog *ui;

};

#endif // TEMPFILEDIALOG_H
