#ifndef NEWPROJECT_H
#define NEWPROJECT_H

#include <QDialog>
#include <QString>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class INewProject;
}

class INewProject : public QDialog
{
    Q_OBJECT

public:
    explicit INewProject(QWidget *parent = 0);
    ~INewProject();
    QString get_ProjectName();//获取工程名

    QString get_ProjectPath();//获取工程路径

private slots:
    void slot_Browse_PushButton();//浏览按键

    void slot_Ok_PushButton();//确定按钮

    void slot_Cancel_PushButton();//取消按钮

private:
    Ui::INewProject *ui;

    QString qsProjectName_gv;//工程名
    QString qsProjectPath_gv;//工程路径
};

#endif // NEWPROJECT_H
