#include "toolkit.h"

IToolkit::IToolkit()
{
    mytypecoversion = new ITypeConversion();
}


/*
 ***************************************************
 * 函数名：DeleteOneline
 * 作用：删除一行字符
 * 输入：行数和字符
 * 返回：
 * 编写：vgGwen 18/6/26
 * 修改：
 ****************************************************
 */
//如果是5行，nNum最大为4
void IToolkit::DeleteOneline(int nNum, QString &strall)
{
    int nLine=0;
    int Index=0;
    //算出行数nLine
    while(Index!=-1)
    {
        Index=strall.indexOf('\n',Index+1);
        nLine++;
    }

    //如果是直接从位置0开始删除\n算一个字符"abc\nme\ndo" \n的index是3要删除3+1个字符，即index+1个
    if(nNum==0)
    {
        int nIndex=strall.indexOf('\n');
        strall.remove(0,nIndex+1);
    }
    else
    {
        int nTemp=nNum;
        int nIndex=0,nIndex2=0;
        while(nTemp--)
        {
            //
            nIndex=strall.indexOf('\n',nIndex+1);//这里会更新nIndex
            if(nIndex!=-1)//说明是有效的
            {
                nIndex2=strall.indexOf('\n',nIndex+1);
            }
        }
        //删除的行不是最后一行（从nIndex+1这个位置起nIndex2-nIndex个字符全部抹去）
        if(nNum<nLine-1)
        {
            strall.remove(nIndex+1, nIndex2-nIndex);//不用减一
        }
        //删除的是最后一行（从nIndex起始len-nIndex个字符全抹去）
        //不能从nIndex+1处开始，
        else if(nNum==nLine-1)
        {
            int len=strall.length();
            strall.remove(nIndex,len-nIndex);
        }
        else
        {

        }

    }
}
/*
 ***************************************************
 * 函数名：deleteOnelineInFile
 * 作用：删除文件中的一行
 * 输入：行数和文件路径
 * 返回：
 * 编写：vgGwen 18/6/26
 * 备注：行数从0开始
 * 修改：
 ****************************************************
 */
void IToolkit::deleteOnelineInFile(int nNumLine, QString &filename)
{
    QString strall;
    QFile readfile(filename);
    if(readfile.open(QIODevice::ReadOnly))
    {
        QTextStream stream(&readfile);
        strall=stream.readAll();
    }
    readfile.close();
    DeleteOneline(nNumLine, strall);

    QFile writefile(filename);
    if(writefile.open(QIODevice::WriteOnly))
    {
        QTextStream wrtstream(&writefile);
        wrtstream<<strall;
    }
    writefile.close();
}
/*
 ***************************************************
 * 函数名：DeleteOneline
 * 作用：删除一行字符
 * 输入：行数和字符
 * 返回：
 * 编写：vgGwen 18/6/26
 * 备注：缺陷（不是好用，str为了是找到路径中的basename，是匹配一行中的一部分，不是匹配整行，以后有需要的时候需要改写）
 * 修改：
 ****************************************************
 */
void IToolkit::deleteOnelineInFile(QString str, QString &filename)
{
    QFile qfPathFile(filename);//打开文件
    qfPathFile.open(QFile::ReadOnly);
    QTextStream qtsStream(&qfPathFile);
    QString qsTmp_str;//存临时数据
    int nNumLine = 0;//定位要删除的行数
    while(!qtsStream.atEnd())
    {
        qsTmp_str = qtsStream.readLine();//一行一行的读取
        QFileInfo qfiPATH(qsTmp_str);
        QString qsBaseName = qfiPATH.baseName();
        if(qsBaseName == str)//找到当前文件的路径，退出
        {
            break;
        }
        nNumLine ++;
    }

    qfPathFile.close();
    deleteOnelineInFile(nNumLine,filename);
}
/*
 ***************************************************
 * 函数名：DeleteDirectory
 * 作用：递归删除一个非空文件夹
 * 输入：要删除文件夹的路径
 * 返回：是否成功的bool量
 * 编写：vgGwen 18/5/18
 * 修改：
 ****************************************************
 */
bool IToolkit::DeleteDirectory(const QString &path)
{
    if (path.isEmpty())
    {
        return false;
    }

    QDir dir(path);
    if(!dir.exists())
    {
        return true;
    }

    dir.setFilter(QDir::AllEntries | QDir::NoDotAndDotDot);
    QFileInfoList fileList = dir.entryInfoList();
    foreach (QFileInfo fi, fileList)
    {
        if (fi.isFile())
        {
            fi.dir().remove(fi.fileName());
        }
        else
        {
            DeleteDirectory(fi.absoluteFilePath());
        }
    }
    return dir.rmpath(dir.absolutePath());
}
//*
// ***************************************************
// * 函数名：getTopParent()
// * 作用：获得可见顶层，即父节点
// * 输入：QStandardItem 类型节点
// * 返回：QStandardItem*型父节点
// * 编写：vgGwen 18/5/1
// * 修改：
// ****************************************************
// */
//QStandardItem* IToolkit::getTopParent(QStandardItem* item)
//{
//    QStandardItem* secondItem = item;
//    while(item->parent()!= 0)
//    {
//        secondItem = item->parent();
//        item = secondItem;
//    }
//    if(secondItem->index().column() != 0)
//    {
//         QStandardItemModel* model = static_cast<QStandardItemModel*>(ui->treeWidget->model());
//         secondItem = model->itemFromIndex(secondItem->index().sibling(secondItem->index().row(),0));
//    }
//    return secondItem;
//}
/*
 ***************************************************
 * 函数名：getTopParent()
 * 作用：获得可见顶层，即父节点
 * 输入：QTreeWidgetItem*型节点
 * 返回：QTreeWidgetItem*型父节点
 * 编写：vgGwen 18/5/4
 * 修改：
 ****************************************************
 */
QTreeWidgetItem* IToolkit::getTopParent(QTreeWidgetItem *item)
{
    QTreeWidgetItem *secondItem = item;
    while(item->parent() != 0)
    {
        secondItem = item->parent();
        item = secondItem;
    }
    return secondItem;
}
/*
 ***************************************************
 * 函数名：getTopParent()
 * 作用：获得可见顶层，即父节点
 * 输入：QModelIndex型节点的index
 * 返回：QModelIndex型父节点的index
 * 编写：vgGwen 18/5/1
 * 修改：
 ****************************************************
 */
QModelIndex IToolkit::getTopParent(QModelIndex itemIndex)
{
    QModelIndex secondItem = itemIndex;
    while(itemIndex.parent().isValid())
    {
        secondItem = itemIndex.parent();
        itemIndex = secondItem;
    }
    if(secondItem.column() != 0)
    {
         secondItem = secondItem.sibling(secondItem.row(),0);
    }
    return secondItem;
}

/*
 ***************************************************
 * 函数名：getNumberOf_layers
 * 作用：获得节点级数
 * 输入：QTreeWidgetItem*型节点,工程节点的数字标记（即起始数字）
 * 返回：int型级数
 * 编写：vgGwen 18/5/1
 * 修改：2018/5/22 vgGwen 遍历-循环换成递归;适应性更好，代码更简单;代价：效率低一些
 ****************************************************
 */
int IToolkit::getNumberOf_layers(QTreeWidgetItem *item, int layer)
{
    int nLayers = layer;
    QTreeWidgetItem *qtwiItem_parent = NULL;
    if(item->parent() == NULL)
    {
        return nLayers;
    }
    else
    {
        qtwiItem_parent = item->parent();
        nLayers++;
        nLayers = getNumberOf_layers(qtwiItem_parent,nLayers);
    }
}

/*
 ***************************************************
 * 函数名：getNumberOf_layers
 * 作用：获得节点级数
 * 输入：QModelIndex型节点的index,工程节点的数字标记（即起始数字）
 * 返回：int型级数
 * 编写：vgGwen 18/5/1
 * 备注：
 * 修改：2018/5/22 vgGwen 遍历-循环换成递归
 ****************************************************
 */
int IToolkit::getNumberOf_layers(QModelIndex &itemIndex, int layer)
{
    int nLayers = layer;
    QModelIndex qmiItem_parent;
    if(!itemIndex.parent().isValid())
    {
        return nLayers;
    }
    else
    {
        qmiItem_parent = itemIndex.parent();
        nLayers++;
        nLayers = getNumberOf_layers(qmiItem_parent,nLayers);
    }
}

