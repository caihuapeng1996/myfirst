#ifndef AMENDDIALOG_H
#define AMENDDIALOG_H

#include <QDialog>
#include <QTableWidget>
#include <QMessageBox>

#include "compute.h"
#include "typeconversion.h"

namespace Ui {
class AmendDialog;
}

class AmendDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AmendDialog(QWidget *parent = 0);
    ~AmendDialog();

private:
    Ui::AmendDialog *ui;
    QTableWidget *wholeTableWidget;//实例一个表格
    int traceNum;//道数变量
    QString inputfile;//接收文件名
    ITypeConversion *mytypeconversion;
    int flag;

    void showTrace();

private slots:
    void slot_getTraces(int traces,QString inputFile,int flag_);//接收道数的槽函数
};

#endif // AMENDDIALOG_H
