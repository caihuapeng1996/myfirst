/*
 *用于2D数据的引导滤波处理
 *
 */
#ifndef MYTHREAD_H
#define MYTHREAD_H

//#include <QObject>
#include <QThread>
#include <QtCore>
#include <QDebug>
#include <QString>
#include <QTimer>
#include <stdio.h>
#include "typeconversion.h"

class Mythread:public QThread
{
    Q_OBJECT

public:
    explicit Mythread();
     ~Mythread();
    void sleep(unsigned int msec);
    void guidedfilter2d_profile(char *filename_input, char *filename_output, int length_x, int length_t);
    void guidedfilter2d(float **data_input,float **data_guided,float **data_output,float eps,int length_x,int length_t,int nx,int nt);
    void boxfilter2D(float** data_input,float** data_output,int nx,int nt,int length_half_t,int length_half_x);
signals:
    void signal_compute_childSendString(QString tep);
    void signal_compute_childSendNum(int num);
    void signal_compute_childSendOver();
public slots:
    void slot_compute_childGetPara(QString inputfile, QString outputfile, int x, int t);//接收主线程的参数

protected:
    void run();

public:
        ITypeConversion *threadtypeconversion;
        QString input_qstr;
        QString output_qstr;
        char* input_chp = NULL;
        char* output_chp = NULL;
        int length_x_i ;
        int length_t_i ;


};

#endif // MYTHREAD_H
