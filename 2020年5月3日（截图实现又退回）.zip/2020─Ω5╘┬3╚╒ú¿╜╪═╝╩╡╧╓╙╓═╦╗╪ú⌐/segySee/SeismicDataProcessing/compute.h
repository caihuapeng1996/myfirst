#ifndef COMPUTE_H
#define COMPUTE_H
//#include "GuidedFilter_3d/complex.h"
#include "Gwen_use/PMfilter.h"
//#include "GuidedFilter_3d/segy.h"
//#include "GuidedFilter_3d/resource.h"

class Compute
{
public:
    Compute();
    ~Compute();
    void compute_guidedfilter2d(char *filename_input,char *filename_output,int length_x,int length_t);

private:
};

#endif // COMPUTE_H
