#include "bandpass.h"
#include "ui_bandpass.h"

BandPass::BandPass(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BandPass)
{
    ui->setupUi(this);
    //设置qwtplt-y坐标轴范围
    ui->qwtPlot->setAxisScale(QwtPlot::yLeft,0.0,1.0,1.0);
    ui->qwtPlot->setAxisTitle(QwtPlot::yLeft,"G ain");
    //设置qwt-x坐标轴范围
    ui->qwtPlot->setAxisScale(QwtPlot::xBottom,0,4,1);
    ui->qwtPlot->setAxisTitle(QwtPlot::xBottom,"F(Hz) F1->F4");
    ui->qwtPlot->setAxisTitle(QwtPlot::xTop,"1,2,3,4 分别代表F1,F2,F3,F4");

}

BandPass::~BandPass()
{
    delete ui;
}
