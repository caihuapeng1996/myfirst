#include "input2d.h"
#include "ui_iinput2d.h"

IInput2D::IInput2D(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::IInput2D)
{
    ui->setupUi(this);
    setWindowTitle("导入2D地震数据");
    /******************连接信号与槽*****************/
    connect(ui->OpenFile_pushButton,SIGNAL(clicked(bool)),this,SLOT(slot_OpenFile()));//打开文件
    connect(ui->OK_pushButton,      SIGNAL(clicked(bool)),  this,SLOT(slot_Ok_PushButton()));//确定按钮
    connect(ui->Cancel_pushButton,  SIGNAL(clicked(bool)),  this,SLOT(slot_Cancel_PushButton()));//确定按钮
    connect(ui->OpenFile_treeWidget,SIGNAL(itemClicked(QTreeWidgetItem*,int)), this,SLOT(slot_Left_Clicked()));//鼠标左键单机动作
    connect(ui->OpenFile_treeWidget,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(slot_Right_Clicked(const QPoint&)));//鼠标右键单击动作

    ui->OpenFile_treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);//一定要设置，否则右键无反应
}

IInput2D::~IInput2D()
{
    delete ui;
}

/*
 ***************************************************
 * 函数名：slot_OpenFileget_Inputfile_list()
 * 作用：获得输入文件列表
 * 输入：无
 * 返回：QStringList型输入文件列表
 * 编写：vgGwen 18/4/29
 * 修改：
 ****************************************************
 */
QStringList IInput2D::get_Inputfile_list()
{
    return qslInputFile_list_gv;
}

/*
 ***************************************************
 * 函数名：slot_OpenFile()
 * 作用：打开文件
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/29
 * 修改：
 ****************************************************
 */
void IInput2D::slot_OpenFile()
{
    QStringList qslFile_List = QFileDialog::getOpenFileNames(this, tr("选择打开文件"),NULL, "*.sgy");//获取输入文件列表
    if(!qslFile_List.isEmpty())
    {
        qslInputFile_list_gv.append(qslFile_List);
        QFileInfo qfiFile_info;//用于查找文件的属性
        for(nNumOf_file;nNumOf_file < qslInputFile_list_gv.count();nNumOf_file++ )//显示**本**次读取文件的文件信息（有*表示重要性，而且变量声明也强调了，还看不懂就没办法了）
        {
            qfiFile_info = QFileInfo(qslInputFile_list_gv.at(nNumOf_file));
            QString qsFile_path = qfiFile_info.absoluteFilePath();//获取文件绝对路径
            /*******创建树形条*******///这里可按需求添加其他树形条节点
            QTreeWidgetItem *qtwiProjectTree_widget = new QTreeWidgetItem(ui->OpenFile_treeWidget,QStringList(qsFile_path));//添加工程节点
        }
    }
    else
    {
        QMessageBox::warning(this, tr("Tips"), tr("打开文件失败"),QMessageBox::tr("好的"));
    }
}

/*
 ***************************************************
 * 函数名：slot_Ok_PushButton()
 * 作用：确定,已经输入文件则可以退出，没有则不能退出
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/29
 * 修改：
 ****************************************************
 */
void IInput2D::slot_Ok_PushButton()
{
    if (qslInputFile_list_gv.count() == 0)
    {
        QMessageBox::warning(this, tr("Tips"), tr("未打开任何地震数据文件"),QMessageBox::tr("好的"));
    }
    else
    {
        ui->OpenFile_treeWidget->clear();//清理显示信息
        ui->DataType_lineEdit->clear();
        ui->NumSamp_lineEdit->clear();
        ui->SampFreque_lineEdit->clear();
        ui->Numtrace_lineEdit->clear();
        IInput2D::accept();//退出
    }
}

/*
 ***************************************************
 * 函数名：slot_Cancel_PushButton()
 * 作用：取消，将list清空并退出
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/29
 * 修改：
 ****************************************************
 */
void IInput2D::slot_Cancel_PushButton()
{
    qslInputFile_list_gv.clear();//清空
    ui->OpenFile_treeWidget->clear();//清理显示信息
    ui->DataType_lineEdit->clear();
    ui->NumSamp_lineEdit->clear();
    ui->SampFreque_lineEdit->clear();
    ui->Numtrace_lineEdit->clear();
    ui->lineEdit_BeginTime->clear();
    ui->lineEdit_BeginTrack->clear();
    ui->lineEdit_EndTime->clear();
    ui->lineEdit_EndTrack->clear();
    IInput2D::accept();//退出
}



/*
 ***************************************************
 * 函数名：slot_Clicked()
 * 作用：鼠标左键单击动作，显示数据属性
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/30
 * 修改：
 ****************************************************
 */
void IInput2D::slot_Left_Clicked()
{
    //因为显示的时候是显示的文件绝对路径，而且都没有子节点，所以在使用时可以不在list中去查找，直接使用点击的item名即可
    QModelIndex qmiCurrent_index = ui->OpenFile_treeWidget->currentIndex();//获取当前鼠标选中的选项
    QString qsCurrent_item = qmiCurrent_index.data().toString();//当前选中的item名称

    //这里处理的时候需要先完成中文路径的支持，再读取数据的属性
    /*******************中文支持**********************/
    //将QString转换为char*
    const char *ccpFile_name = NULL;
    std::string sTmp_name = mytypeconversion->qstring2cstring(qsCurrent_item);//先把qstring转为c++的string
    ccpFile_name = sTmp_name.data();//再将string转为char*类型

    FILE *fpInput = NULL;
    fpInput = fopen(ccpFile_name,"rb");//打开文件

    /*****************属性信息读取*******************/
    /*
     *nt://采样点数int
     *nx：//道数int
     *ddt：//采样间隔
     *dt：//采样率float
     * qsFiletype://数据类型
     */
    int nt;//采样点数
    int ncut;//道数
    int ddt;
    float dt;
    QString type;//数据类型
    int beginTime;
    int endTime;
    int beginTrace;
    int endTrace;

    segy traceheader;
    bhed fileheader;
    int size_fileheader=sizeof(fileheader);
    int size_traceheader=sizeof(traceheader);

    //读文件内容
    fread(&fileheader,size_fileheader,1,fpInput);
    fread(&traceheader,size_traceheader,1,fpInput);


    //获得文件内部相关信息
    if (fileheader.format == 1 || exchangeLowHigh16(fileheader.format) == 1){
        nt=exchangeLowHigh16(fileheader.hns);
        ddt=exchangeLowHigh16(fileheader.hdt);

        beginTime = exchangeLowHigh16(traceheader.laga);
        beginTrace = exchangeLowHigh32(traceheader.tracf);

        dt=(float)ddt/1000000.0;
        type = "IBM(32位)";
    }

    if (fileheader.format == 5  || exchangeLowHigh16(fileheader.format) == 5){
        nt=(fileheader.hns);
        ddt=(fileheader.hdt);

        dt=(float)ddt/1000000.0;
        type = "IEEE（32位）";

        beginTime = (traceheader.laga);
        beginTrace = (traceheader.tracf);
    }

    fseek(fpInput,0,2);
    int size_sgy=ftell(fpInput);
    ncut=(size_sgy-size_fileheader)/(size_traceheader+nt*sizeof(float));
    endTime = (nt-1)*ddt/1000+beginTime;
    endTrace = beginTrace+ncut - 1;
    fclose(fpInput);

    ui->NumSamp_lineEdit->setText(mytypeconversion->int2qstring(nt));//采样点数
    ui->Numtrace_lineEdit->setText(mytypeconversion->int2qstring(ncut));//道数
    ui->SampFreque_lineEdit->setText(mytypeconversion->float2qstring(dt));//采样率
    ui->DataType_lineEdit->setText(type);//数据类型
    ui->lineEdit_BeginTime->setText(mytypeconversion->int2qstring(beginTime));//起止时间
    ui->lineEdit_EndTime->setText(mytypeconversion->int2qstring(endTime));
    ui->lineEdit_BeginTrack->setText(mytypeconversion->int2qstring(beginTrace));//起止道数
    ui->lineEdit_EndTrack->setText(mytypeconversion->int2qstring(endTrace));
}

/*
 ***************************************************
 * 函数名：slot_Clicked()
 * 作用：鼠标右键单击动作，显示菜单栏
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/30
 * 修改：
 ****************************************************
 */
void IInput2D::slot_Right_Clicked(const QPoint&)
{
    QTreeWidgetItem* qtwiCurrent_item = ui->OpenFile_treeWidget->currentItem();//返回选中的item
    if(qtwiCurrent_item == NULL) return;//没选中
    //信号
    QAction  qaDelete_action(tr("删除文件"),this);
    //连接信号槽
    connect(&qaDelete_action,SIGNAL(triggered(bool)),this,SLOT(slot_DeleteItem()));

    QMenu qmRight_menu(ui->OpenFile_treeWidget);//菜单栏
    qmRight_menu.addAction(&qaDelete_action);//添加菜单栏
    qmRight_menu.exec(QCursor::pos());//在当前鼠标位置显示
}

/*
 ***************************************************
 * 函数名：slot_DeleteItem()
 * 作用：删除选中项，在slot_Right_Clicked函数中与信号连接
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/30
 * 修改：
 ****************************************************
 */
void IInput2D::slot_DeleteItem()
{
    QModelIndex qmiCurrent_index = ui->OpenFile_treeWidget->currentIndex();//当前选中的index
    QString qsCurrent_item = qmiCurrent_index.data().toString();//获得选中的字符，即路径
    ui->OpenFile_treeWidget->takeTopLevelItem(qmiCurrent_index.row());//删除界面显示
    /**********删除list中对应的路径**********/
    qDebug()<<"num list:"<<qslInputFile_list_gv.count();
//    QStringList::iterator it_list = qslInputFile_list_gv.begin();//设置迭代器
//    for(;it_list != qslInputFile_list_gv.end(),it_list++)
//    {
//        if()
//    }
//    for(int nNum_list = 0; nNum_list < qslInputFile_list_gv.count(); nNum_list++)
//    {
//        if(qslInputFile_list_gv[nNum_list] == qsCurrent_item)//匹配，删除
//        {
            qslInputFile_list_gv.removeOne(qsCurrent_item);
//        }
    qDebug()<<"num list after:"<<qslInputFile_list_gv.count();

}
