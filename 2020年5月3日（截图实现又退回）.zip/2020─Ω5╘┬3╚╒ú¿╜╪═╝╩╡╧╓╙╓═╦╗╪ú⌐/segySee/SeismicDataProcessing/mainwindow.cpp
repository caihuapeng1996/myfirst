#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include "paint2dform.h"
#include <QHBoxLayout>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowTitle("地震数据处理");
    setWindowState(Qt::WindowMaximized);

    toolkit = new IToolkit();

    BinaryHeadtable = new QTableWidget;
    ptxt = new QPlainTextEdit;
    ptxt->setReadOnly(true);

    ui->tabWidget->setEnabled(false);
    ui->tabWidget->setCurrentIndex(0);
    ui->treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);//一定要设置，否则右键无反应

    setDockNestingEnabled(true);//让dock可以自由组合

    /*************初始化按钮状态**************/
    ui->SaveProject_tool_action->setEnabled(false);
    ui->QuitProject_tool_action->setEnabled(false);
    ui->Input2D_tool_action->setEnabled(false);
    ui->Input3D_tool_action->setEnabled(false);

    //色标组
    ui->comboBox->addItem( QIcon(":/new/images/images/red_white_blue.png"),"红白蓝");
    ui->comboBox->addItem( QIcon(":/new/images/images/red_white_black.png"),"红白黑");
    ui->comboBox->addItem( QIcon(":/new/images/images/red_white_yellow.png"),"红白黄");
    ui->comboBox->addItem( QIcon(":/new/images/images/gray_white_black.png"),"灰白黑");
    ui->comboBox->addItem( QIcon(":/new/images/images/iridescence.jpg"),"彩虹色");
    ui->comboBox->addItem( QIcon(":/new/images/images/red_yellow_black.png"),"红黄黑");
    ui->comboBox->setCurrentIndex(1);

    /***********连接信号与槽***********/
    connect(ui->NewProject_tool_action, SIGNAL(triggered(bool)), this, SLOT(slot_NewProject()));
    connect(ui->OpenProject_tool_action,SIGNAL(triggered(bool)), this, SLOT(slot_OpenProject()));
    connect(ui->SaveProject_tool_action,SIGNAL(triggered(bool)), this, SLOT(slot_SaveProject()));
    connect(ui->QuitProject_tool_action,SIGNAL(triggered(bool)), this, SLOT(slot_QuitProject()));
    connect(ui->Input2D_tool_action,    SIGNAL(triggered(bool)), this, SLOT(slot_Input2D()));
    connect(ui->Input3D_tool_action,    SIGNAL(triggered(bool)), this, SLOT(slot_Input3D()));
    connect(ui->GFCompute2D_action_2,     SIGNAL(triggered(bool)), this, SLOT(slot_GFCompute2D()));//2D引导滤波界面
    connect(ui->GFCompute2D_action_3,     SIGNAL(triggered(bool)), this, SLOT(slot_GFCompute3D()));//3D引导滤波界面
    connect(ui->About_action,           SIGNAL(triggered(bool)), this, SLOT(slot_About()));//打开版权页
    connect(ui->treeWidget,             SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)),this,SLOT(slot_DoubleClick()));//树形图双击打开文件
    connect(ui->treeWidget,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(slot_TreeWidget_Right_Clicked(const QPoint&)));//树形图鼠标右键单击动作
    connect(ui->widget_baseMap, SIGNAL(toggleProfile(int,int)), this, SLOT(on_toggleProfile(int,int)));
    connect(ui->radioButton_traceHead,SIGNAL(clicked(bool)),this,SLOT(on_radioButton_BinaryHead_clicked()));//文本基本信息
    connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(presetColorChanged(int)));//预设色标改变
    connect(ui->selectcolorButton,SIGNAL(clicked()),this,SLOT(colorChanged()));//自定义色标

    //大文件切割
   // connect(ui->action_filecut,SIGNAL(triggered(bool)),this,SLOT(slot_filecut()));
    connect(ui->action_filesplit,SIGNAL(triggered(bool)),this,SLOT(slot_filesplit()));
    //带通滤波器
    connect(ui->action_bandpass,SIGNAL(triggered(bool)),this,SLOT(slot_bandpass()));

}

MainWindow::~MainWindow()
{
    delete ui;

}

/*
 ***************************************************
 * 函数名：closeEvent
 * 作用：关闭软件
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void MainWindow::closeEvent(QCloseEvent *event)
{
    //退出软件
    ckmessagebox_dialog = new ICkMessageBox(this,tr("Tips"),tr("是否退出软件？"),tr("保存工程"));
    ckmessagebox_dialog->set_CheckBox_default(true);//默认复选框不选中
    ckmessagebox_dialog->setModal(true);
    ckmessagebox_dialog->show();
    if(ckmessagebox_dialog->exec() == QDialog::Accepted)//dialog已经退出
    {
        bool bOk = false;
        bool bCancel = false;
        bool bCheckBox = false;
        ckmessagebox_dialog->get_Status(bOk,bCancel,bCheckBox);//读取状态的值
        if(bOk == true && bCancel == true)//退出软件并保存工程
        {
            //保存工程
            QTreeWidgetItemIterator it(ui->treeWidget);
            while(*it)
            {
                saveProject(*it);
            }
            //退出程序
            event->accept();
        }
        else if(bOk == true && bCancel == false)//退出不保存
        {
            event->accept();
        }
        else if(bCancel == true)//取消
        {
            event->ignore();
        }
    }
    else
    {
        event->ignore();
    }

}

/*
 ***************************************************
 * 函数名：slot_NewProject()
 * 作用：新建工程，建立文件夹，建立工程配置文件，树形图
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void MainWindow::slot_NewProject()
{
    /***********录入新建的工程信息**********/
    if(newpro_dialog == nullptr)
        newpro_dialog = new INewProject(this);
    newpro_dialog->setModal(true);//模态
    newpro_dialog->setFixedSize(417,157);
    newpro_dialog->show();

    /*******项目的文件夹结构******
        |-qsUnder_Project_Path	//工程目录
            -qsNewPro_name.pro //工程配置文件——记录工程相关信息
            -node.xbel	//工程配置文件-树形图节点信息
            -qsPathFile_name.text	//工程配置文件——记录工程中加入的sgy文件全路径
            |-qsSeismic_Path	//子目录，组织加入的sgy文件
    **/
    if(newpro_dialog->exec() == QDialog::Accepted)
    {
        QString qsNewPro_name = newpro_dialog->get_ProjectName();
        QString qsNewPro_path = newpro_dialog->get_ProjectPath();

        if(qsNewPro_name.isEmpty() || qsNewPro_path.isEmpty())
        {
            return;
        }

        /**新建项目的基本目录结构**/
        QDir qdProject_Path(qsNewPro_path);//工程创建的路径
        qdProject_Path.mkdir(qsNewPro_name);//创建用项目命名的工程文件夹
        QString qsUnder_Project_Path = qdProject_Path.absoluteFilePath(qsNewPro_name);//获取工程文件夹的绝对路径，比工程创建的路径深一级

        QDir qdUnder_Project_Path(qsUnder_Project_Path);//在工程文件夹下创建新的文件夹
        qdUnder_Project_Path.mkdir(defSEISMIC_DATA);//这里可添加其他文件夹，用于存储其他数据
        QString qsSeismic_path = qdUnder_Project_Path.absoluteFilePath(defSEISMIC_DATA);
        //用于创建对应的xml文件节点
        qmTreeWidget_path_gv[qsNewPro_name] = qsUnder_Project_Path;//工程路径(保存的是比工程创建路径深一级的路径，下面的地震数据路径也是一样)//添加其他节点的时候需要在这里进行修改和添加
        qmTreeWidget_path_gv[qsNewPro_name + defSEISMIC_DATA] = qsSeismic_path;//地震数据，文件夹路径//不明白路径到底是什么就debug打印出来看

        /******新建项目配置文件pro*****/
        QString qsProFile_name = qsNewPro_name + ".pro";//给工程文件加后缀
        QString qsProFile_path = qdUnder_Project_Path.filePath(qsProFile_name);//获取工程文件创建路径
        QFile qfProFile(qsProFile_path);//创建工程文件
        qfProFile.open(QFile::WriteOnly | QIODevice::Text);
        QTextStream qtsProFile_stream(&qfProFile);//创建字符流
        QDateTime qstCurrentDate_time = QDateTime::currentDateTime();//获取系统时间
        QString qsCurrentDate_time = qstCurrentDate_time.toString("yyyy-MM-dd hh:mm:ss ddd");//设置时间格式
        qtsProFile_stream<<"####PROJECT WAS CREATED IN "<<qsCurrentDate_time<<"####\n";
        qtsProFile_stream<<"PROJECT NAME="<<qsNewPro_name<<"\n";//添加项目名
        qtsProFile_stream<<"PROJECT DIR="<<qsNewPro_path<<"\n";//添加项目路径
        qtsProFile_stream<<"PROJECT FILE NAME="<<qsProFile_name<<"\n";//添加pro文件名
        qtsProFile_stream<<"PROJECT FILE PATH="<<qsProFile_path<<"\n";//添加pro文件路径
        qfProFile.close();//关闭工程文件

        /********在工程目录下新建一个用于保存数据路径的文件*********//*每次导入文件时需要写入数据的路径，删除文件时需要删除文件中相应的路径*/
        QString qsPathFile_name = defPATHFILE_NAME;
        QString qsPathFile_path = qdUnder_Project_Path.filePath(qsPathFile_name);
        QFile qfPathFile(qsPathFile_path);//创建文件
        qfPathFile.open(QFile::WriteOnly | QIODevice::Text);
        qfPathFile.close();

        /**树形组建**/
        QTreeWidgetItem *qtwiProjectTree_widget = new QTreeWidgetItem(ui->treeWidget,QStringList(qsNewPro_name));//添加工程节点
        QTreeWidgetItem *qtwiSeismicTree_widget = new QTreeWidgetItem(qtwiProjectTree_widget,QStringList(defSEISMIC_DATA));//添加地震数据节点
        qtwiProjectTree_widget->setData(0,Qt::UserRole,"node");
        qtwiSeismicTree_widget->setData(0,Qt::UserRole,"node");
        qmTreeWidget_item_gv[qsNewPro_name] = *qtwiProjectTree_widget;//将新建的树形条存在map里以便查找//添加其他节点的时候需要在这里进行修改和添加
        qmTreeWidget_item_gv[qsNewPro_name + defSEISMIC_DATA] = *qtwiSeismicTree_widget;//这里key加的后缀”地震数据“一定要与节点名字相同，一定，一定，一定，其余后缀也一样，与相应的节点名相同

        /***********设置按钮状态***********/
        ui->SaveProject_tool_action->setEnabled(true);
        ui->QuitProject_tool_action->setEnabled(true);
        ui->Input2D_tool_action->setEnabled(true);
        ui->Input3D_tool_action->setEnabled(true);
    }
}

/*
 ***************************************************
 * 函数名：slot_OpenProject()
 * 作用：打开工程，构建节点，填充两个map
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/5/17
 * 修改：
 ****************************************************
 */
void MainWindow::slot_OpenProject()
{
    QString qsPro_path = QFileDialog::getOpenFileName(this,tr("打开工程"),nullptr,tr("工程文件(*.pro)"));//打开工程文件
    QFileInfo qfiProName_info = QFileInfo(qsPro_path);
    QString qsPro_name = qfiProName_info.baseName();//获取工程名
    QString qsPro_dir = qfiProName_info.absolutePath();
    //检查树形图中有没有相同的工程（即是否重复打开）
    QMap<QString,QString>::iterator it_item = qmTreeWidget_path_gv.find(qsPro_name);
    if(it_item != qmTreeWidget_path_gv.end() && it_item.key() == qsPro_name)//容器中有匹配项，说明树形图中有该工程，重复打开了
    {
       QMessageBox::warning(this,tr("Warning"),tr("工程已存在"),QMessageBox::tr("确定"));
       return;
    }
    /******************读取工程的xml文件********************/
    QString qsXml_path = qfiProName_info.absolutePath() + "/" + defNODEXML_NAME;//找到对应工程xml文件
    /*读取xml文件构建节点，并读出路径到map*/
    readxml = new IRXml(ui->treeWidget);
    readxml->ReadXml(qsXml_path);


    /**************填充item的map*************/
    for(int nCount = 0; nCount < ui->treeWidget->topLevelItemCount(); ++nCount)
    {
        if (ui->treeWidget->topLevelItem(nCount)->text(0) == qsPro_name)//通过遍历查找新建的工程节点
        {
            QString qsPath_pro = qfiProName_info.absolutePath();
            qmTreeWidget_path_gv[qsPro_name] = qsPath_pro;//存工程节点的路径

            QTreeWidgetItem *qtwiNewOpen_Proitem = ui->treeWidget->topLevelItem(nCount);//将找到的工程节点保存下来
            //循环遍历工程树形图，填充item map和path map
            QString qsNameOf_Pro_item = qtwiNewOpen_Proitem->text(0);//项目名
            for(int nRow_layer1 = 0; qtwiNewOpen_Proitem->child(nRow_layer1)!= NULL; nRow_layer1 ++)//第一层，检查数据分类层，即“sgy”层
            {
                QTreeWidgetItem *qtwiLayer1_item = qtwiNewOpen_Proitem->child(nRow_layer1);
                QString qsNameOf_Layer1_item = qtwiLayer1_item->text(0);//eg:”地震数据“
                /********找到路径，填充path的map*/
                QString qsPath_layer1 = getFile_path(qsPath_pro,qsNameOf_Layer1_item);
                qmTreeWidget_path_gv[qsNameOf_Pro_item + qsNameOf_Layer1_item] = qsPath_layer1;

                for(int nRow_layer2 = 0; qtwiLayer1_item->child(nRow_layer2)!= nullptr; nRow_layer2 ++)//检查第二层，sgy具体文件层
                {
                    QTreeWidgetItem *qtwiLayer2_item = qtwiLayer1_item->child(nRow_layer2);
                    QString qsNameOf_Layer2_item = qtwiLayer2_item->text(0);//eg:"HJJ"
                    /********找到路径，填充path的map*/
                    QString qsPath_layer2 = getFile_path(qsPath_layer1,qsNameOf_Layer2_item);
                    qmTreeWidget_path_gv[qsNameOf_Pro_item + qsNameOf_Layer1_item + qsNameOf_Layer2_item] = qsPath_layer2;

                    for(int nRow_layer3 = 0; qtwiLayer2_item->child(nRow_layer3)!= nullptr; nRow_layer3 ++)//检查第三层，即文件层“导航数据”等
                    {
                        QTreeWidgetItem * qtwiLayer3_item = qtwiLayer2_item->child(nRow_layer3);//取出item
                        QString qsNameOf_Layer3_item = qtwiLayer3_item->text(0);//eg:"导航数据"
                        /********找到路径，填充path的map*///文件略有不同，需要添加后缀
                        QString qsNameOf_Layer3_item_ = qsNameOf_Layer3_item + ".text";
                        QString qsPath_layer3 = getFile_path(qsPath_layer2,qsNameOf_Layer3_item_);//文件略有不同
                        qmTreeWidget_path_gv[qsNameOf_Pro_item + qsNameOf_Layer1_item + qsNameOf_Layer2_item +qsNameOf_Layer3_item] = qsPath_layer3;

                        qmTreeWidget_item_gv[qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item+qsNameOf_Layer3_item] = *qtwiLayer3_item;
                    }
                    qmTreeWidget_item_gv[qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item] = *qtwiLayer2_item;
                }
                qmTreeWidget_item_gv[qsNameOf_Pro_item+qsNameOf_Layer1_item] = *qtwiLayer1_item;
            }
            qmTreeWidget_item_gv[qsNameOf_Pro_item] = *qtwiNewOpen_Proitem;
        }
    }

    /*************设置按钮状态***************/
    if(ui->treeWidget->topLevelItemCount() != 0)
    {
        ui->SaveProject_tool_action->setEnabled(true);
        ui->QuitProject_tool_action->setEnabled(true);
        ui->Input2D_tool_action->setEnabled(true);
        ui->Input3D_tool_action->setEnabled(true);
    }
}
/*
 ***************************************************
 * 函数名：getFile_path
 * 作用：获得某路径下文件的绝对路径
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */

QString MainWindow::getFile_path(QString &strFilePath,QString &strNameFilters)
{
     if (strFilePath.isEmpty() || strNameFilters.isEmpty())
     {
      return QString();
     }

    QDir dir;
    QStringList filters;

    filters << strNameFilters;
    dir.setPath(strFilePath);
    dir.setNameFilters(filters);
    QDirIterator iter(dir,QDirIterator::Subdirectories);

    while (iter.hasNext())//遍历
    {
        iter.next();
        QFileInfo info=iter.fileInfo();
        return info.absoluteFilePath();

    }
    return QString();
}

/*
 ***************************************************
 * 函数名：slot_SaveProject()
 * 作用：保存工程
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void MainWindow::slot_SaveProject()
{
    QTreeWidgetItem *qtwiCurrentItem = ui->treeWidget->currentItem();
    if(qtwiCurrentItem == nullptr)
    {
        QMessageBox::warning(this,tr("Tips"),tr("请选择要保存的工程"),QMessageBox::tr("确定"));
    }
    else
    {
        QTreeWidgetItem *qtwiProjectItem = toolkit->getTopParent(qtwiCurrentItem);
        saveProject(qtwiProjectItem);
    }
}

/*
 ***************************************************
 * 函数名：slot_QuitProject()
 * 作用：退出工程,删除对应树形图，设置按钮状态,清除容器信息
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
void MainWindow::slot_QuitProject()
{
    /**************删除map对应的值******************/
    QTreeWidgetItem *qtwiCurrentClick_item = ui->treeWidget->currentItem();//当前选中项
    QModelIndex qmiCurrentClick_index = ui->treeWidget->currentIndex();//获取当前鼠标选中的选项
    if(qtwiCurrentClick_item == NULL || qmiCurrentClick_index.parent().isValid())//未选中任何工程或选中了工程节点以外的子节点
    {
        QMessageBox::warning(this,tr("Warning"),tr("请先选择需要退出的工程"),QMessageBox::tr("确定"));
        return;
    }

    //判断用户是退出工程还是删除工程
    ckmessagebox_dialog = new ICkMessageBox(this,tr("Tips"),tr("是否退出工程？"),tr("删除工程文件"));
    ckmessagebox_dialog->set_CheckBox_default(false);//默认复选框不选中
    ckmessagebox_dialog->setModal(true);
    ckmessagebox_dialog->show();
    if(ckmessagebox_dialog->exec() == QDialog::Accepted)//dialog已经退出
    {
        bool bOk = false;
        bool bCancel = false;
        bool bCheckBox = false;
        ckmessagebox_dialog->get_Status(bOk,bCancel,bCheckBox);//读取状态的值
        if(bOk == true && bCheckBox == false)//只是退出工程
        {
            //先保存文件以及删除map中的值后才删除界面上的节点
            saveProject(qtwiCurrentClick_item);

            QString qsNameOf_Pro_item = qtwiCurrentClick_item->text(0);//项目名
            for(int nRow_layer1 = 0; qtwiCurrentClick_item->child(nRow_layer1)!= NULL; nRow_layer1 ++)//第一层，检查数据分类层，即“地震数据”层
            {
                QTreeWidgetItem *qtwiLayer1_item = qtwiCurrentClick_item->child(nRow_layer1);
                QString qsNameOf_Layer1_item = qtwiLayer1_item->text(0);//eg:”地震数据“
                for(int nRow_layer2 = 0; qtwiLayer1_item->child(nRow_layer2)!= NULL; nRow_layer2 ++)//检查第二层，即打开文件层
                {
                    QTreeWidgetItem *qtwiLayer2_item = qtwiLayer1_item->child(nRow_layer2);
                    QString qsNameOf_Layer2_item = qtwiLayer2_item->text(0);//eg:"HJJ"
                    for(int nRow_layer3 = 0; qtwiLayer2_item->child(nRow_layer3)!= NULL; nRow_layer3 ++)//检查第三层，即文件层“导航数据”等
                    {
                        QTreeWidgetItem * qtwiLayer3_item = qtwiLayer2_item->child(nRow_layer3);//取出item
                        QString qsNameOf_Layer3_item = qtwiLayer3_item->text(0);//eg:"导航数据"
                        qmTreeWidget_item_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item+qsNameOf_Layer3_item);
                        qmTreeWidget_path_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item+qsNameOf_Layer3_item);
                    }
                    qmTreeWidget_item_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item);
                    qmTreeWidget_path_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item);
                }
                qmTreeWidget_item_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item);
                qmTreeWidget_path_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item);
            }
            qmTreeWidget_item_gv.remove(qsNameOf_Pro_item);
            qmTreeWidget_path_gv.remove(qsNameOf_Pro_item);

            /**************删除工程所有节点******************/
            delete ui->treeWidget->takeTopLevelItem(qmiCurrentClick_index.row());
        }
        else if(bOk == true && bCheckBox == true)//删除工程。。多一步删除工程文件所在的文件夹
        {
            QString qsNameOf_Pro_item = qtwiCurrentClick_item->text(0);//项目名
            /**********删除文件夹***********/
            QMap<QString,QString>::iterator it_del = qmTreeWidget_path_gv.find(qsNameOf_Pro_item);
            if(it_del != qmTreeWidget_path_gv.end() && it_del.key() == qsNameOf_Pro_item)//找到
            {
                toolkit->DeleteDirectory(it_del.value());//删除文件夹
            }

            /**********删除map值***********/
            for(int nRow_layer1 = 0; qtwiCurrentClick_item->child(nRow_layer1)!= NULL; nRow_layer1 ++)//第一层，检查数据分类层，即“地震数据”层
            {
                QTreeWidgetItem *qtwiLayer1_item = qtwiCurrentClick_item->child(nRow_layer1);
                QString qsNameOf_Layer1_item = qtwiLayer1_item->text(0);//eg:”地震数据“
                for(int nRow_layer2 = 0; qtwiLayer1_item->child(nRow_layer2)!= NULL; nRow_layer2 ++)//检查第二层，即打开文件层
                {
                    QTreeWidgetItem *qtwiLayer2_item = qtwiLayer1_item->child(nRow_layer2);
                    QString qsNameOf_Layer2_item = qtwiLayer2_item->text(0);//eg:"HJJ"
                    for(int nRow_layer3 = 0; qtwiLayer2_item->child(nRow_layer3)!= NULL; nRow_layer3 ++)//检查第三层，即文件层“导航数据”等
                    {
                        QTreeWidgetItem * qtwiLayer3_item = qtwiLayer2_item->child(nRow_layer3);//取出item
                        QString qsNameOf_Layer3_item = qtwiLayer3_item->text(0);//eg:"导航数据"
                        qmTreeWidget_item_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item+qsNameOf_Layer3_item);
                        qmTreeWidget_path_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item+qsNameOf_Layer3_item);
                    }
                    qmTreeWidget_item_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item);
                    qmTreeWidget_path_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item+qsNameOf_Layer2_item);
                }
                qmTreeWidget_item_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item);
                qmTreeWidget_path_gv.remove(qsNameOf_Pro_item+qsNameOf_Layer1_item);
            }
            qmTreeWidget_item_gv.remove(qsNameOf_Pro_item);
            qmTreeWidget_path_gv.remove(qsNameOf_Pro_item);

            /**************删除工程所有节点******************/
            delete ui->treeWidget->takeTopLevelItem(qmiCurrentClick_index.row());
        }
        else
        {
            return;
        }
    }
    /**************当工程全部关闭时需要设置按钮状态**************/
    if(ui->treeWidget->topLevelItemCount() == 0)
    {
        ui->SaveProject_tool_action->setEnabled(false);
        ui->QuitProject_tool_action->setEnabled(false);
        ui->Input2D_tool_action->setEnabled(false);
        ui->Input3D_tool_action->setEnabled(false);
        qmTreeWidget_item_gv.clear();//清空map
        qmTreeWidget_path_gv.clear();
    }
}

/*
 ***************************************************
 * 函数名：slot_Input2D()
 * 作用：输入2D数据，设置树形图，
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：vgGwen 18/5/25 将两种情况分开处理改为一种处理方式，通过统一获得父节点的方式整合
 * 备注：每次读取需要做的事：添加树形图，map值添加
 ****************************************************
 */
void MainWindow::slot_Input2D()
{
    QTreeWidgetItem *qtwiCurrent_item = ui->treeWidget->currentItem();//获取当前选中item
    QModelIndex qmiCurrent_index = ui->treeWidget->currentIndex();
    if(qtwiCurrent_item == nullptr || qmiCurrent_index.parent().parent().isValid())//没选中任何项目或者选择了底层节点
    {
        QMessageBox::warning(this, tr("Tips"), tr("请先选择要导入数据的工程"),QMessageBox::tr("好的"));
        return;
    }
    input2d_dialog = new IInput2D(this);
    input2d_dialog->setModal(true);//模态
    input2d_dialog->show();
    if(input2d_dialog->exec() == QDialog::Accepted)
    {
        QStringList qslInput_list = input2d_dialog->get_Inputfile_list();//获取输入列表
        if(qslInput_list.count() == 0)
        {
            return;//判断有无文件，无则退出
        }
        /**********添加树形图，新建文件夹（此时仅有地震数据节点）************/
        QTreeWidgetItem *qtwiCurrent_parent_item = qtwiCurrent_item->parent();//当前节点的父节点
        if(qtwiCurrent_parent_item != nullptr)//选中不是父节点
        {
            qtwiCurrent_item = toolkit->getTopParent(qtwiCurrent_item);//获得父节点
            qmiCurrent_index = toolkit->getTopParent(qmiCurrent_index);
        }
        /*****************通过文件名判断是否有已经打开的文件，有则将list中相关项删除，避免再新建节点****************/
        for(int nLayer1 = 0;nLayer1 < qtwiCurrent_item->childCount();++nLayer1)//sgy级
        {
            for(int nLayer2 = 0;nLayer2 < qtwiCurrent_item->child(nLayer1)->childCount();++nLayer2)//文件级
            {
                QString qsNode_name = qtwiCurrent_item->child(nLayer1)->child(nLayer2)->text(0);//节点名称
                for(int nCount = 0;nCount < qslInput_list.count();++nCount)
                {
                    QString qsInputFile = qslInput_list.at(nCount);//找出每一个地址
                    QFileInfo qfiInputFile_info = QFileInfo(qsInputFile);//用于找出地址对应文件名
                    QString qsInputFile_name = qfiInputFile_info.baseName();//找出文件名
                    if(qsNode_name == qsInputFile_name)//文件已经打开
                    {
                        qslInput_list.removeAt(nCount);
                    }
                }
            }
        }    
        /************将数据的路径，即list写入工程下的路径文件中***********/
        QMap<QString, QString>::iterator it_Propath = qmTreeWidget_path_gv.find(qtwiCurrent_item->text(0));//查找工程路径
        if(it_Propath.key() == qtwiCurrent_item->text(0) && it_Propath != qmTreeWidget_path_gv.end())
        {
            QString qsPropath = it_Propath.value();//工程路径
            QString qsPathFile = qsPropath + "/" + defPATHFILE_NAME;//路径文件的路径
            QFile qfPathFile(qsPathFile);//打开文件
            qfPathFile.open(QFile::WriteOnly | QIODevice::Text | QIODevice::Append);
            QTextStream out(&qfPathFile);
            for(int nCount = 0; nCount < qslInput_list.count(); nCount++)
            {
                out<<qslInput_list.at(nCount)<<endl;
                out.flush();
            }
            qfPathFile.close();
        }
        /*******************在工程下建相关文件和树形图节点***********************/
        QTreeWidgetItem *qtwiSeismic_item = qtwiCurrent_item->child(0);//"地震数据"节点，如果有其他节点，可以根据这里来更改
        for(int nNum_list = 0; nNum_list < qslInput_list.count(); nNum_list++)//在子节点下建立节点，每一个文件单独建一个节点
        {
            QString qsInputFile = qslInput_list.at(nNum_list);//找出每一个地址
            QFileInfo qfiInputFile_info = QFileInfo(qsInputFile);//用于找出地址对应文件名
            QString qsInputFile_name = qfiInputFile_info.baseName();//找出文件名
            QTreeWidgetItem *qtwiNewSeismicFile_item = new QTreeWidgetItem(qtwiSeismic_item,QStringList()<<qsInputFile_name);//添加地震数据文件的节点
            qtwiNewSeismicFile_item->setData(0,Qt::UserRole,"node");
            QString qsCurrent_item_name = qmiCurrent_index.data().toString();//获取工程名，这里是父节点，所以直接使用这个名字就行，如果不是父节点，就需要先找到父节点，再获取工程名
            qmTreeWidget_item_gv[qsCurrent_item_name+ defSEISMIC_DATA +qsInputFile_name] = *qtwiNewSeismicFile_item;//这里不论是打开还是新建，都需要吧item保存在map里，以便其他时间使用;

            /********新建文件夹***********/
            QMap<QString,QString>::iterator it_path = qmTreeWidget_path_gv.find(qsCurrent_item_name + defSEISMIC_DATA);
            if(it_path != qmTreeWidget_path_gv.end() && it_path.key() == qsCurrent_item_name + defSEISMIC_DATA)//找到工程名下面的“地震数据”节点的路径
            {
                QDir qdData_path(it_path.value());//创建以数据名命名的文件夹
                qdData_path.mkdir(qsInputFile_name);
                QString qsData_path = qdData_path.absoluteFilePath(qsInputFile_name);//获取新建文件夹的绝对路径以便保存
                qmTreeWidget_path_gv[qsCurrent_item_name + defSEISMIC_DATA + qsInputFile_name] = qsData_path;//每一次新建或者打开文件夹后都需要保存在map里面，每一次删除也需要把map里对应的内容删除

                QString qsNavi_name = defNAVI_FILE_NAME;
                QDir qdUnderDataNavi_path(qsData_path);//新建文件夹下的路径
                QString qsUnderDataNavi_path = qdUnderDataNavi_path.absoluteFilePath(qsNavi_name);//获取导航数据文件路径//用于画底图
                QFile qfNavigation(qsUnderDataNavi_path);//创建
//                write_naviData(qfNavigation,qsInputFile,true);//把导入的数据的路径传给函数处理
                qmTreeWidget_path_gv[qsCurrent_item_name + defSEISMIC_DATA + qsInputFile_name + defNAVI_DATA] = qsUnderDataNavi_path;


                QString qsOrig_name = defORIG_FILE_NAME;
                QDir qdUnderDataOrig_path(qsData_path);//新建文件夹下的路径
                QString qsUnderDataOrig_path = qdUnderDataOrig_path.absoluteFilePath(qsOrig_name);//获取原始数据文件路径//其中保存数据的路径，用于以后使用
                QFile qfOriginal(qsUnderDataOrig_path);//创建
                write_Path(qfOriginal,qsInputFile,true);//创建对应的文件，并写入路径
                qmTreeWidget_path_gv[qsCurrent_item_name + defSEISMIC_DATA + qsInputFile_name + defORIG_DATA] = qsUnderDataOrig_path;

                /**********新建文件的节点***********/
                QTreeWidgetItem *qtwiNavi_item = new QTreeWidgetItem(qtwiNewSeismicFile_item,QStringList(defNAVI_DATA));//导航数据节点
                QTreeWidgetItem *qtwiOrig_item = new QTreeWidgetItem(qtwiNewSeismicFile_item,QStringList(defORIG_DATA));//原始数据节点
                qtwiNavi_item->setData(0,Qt::UserRole,"node");
                qtwiOrig_item->setData(0,Qt::UserRole,"node");
                qmTreeWidget_item_gv[qsCurrent_item_name+ defSEISMIC_DATA +qsInputFile_name + defNAVI_DATA] = *qtwiNavi_item;
                qmTreeWidget_item_gv[qsCurrent_item_name+ defSEISMIC_DATA +qsInputFile_name + defORIG_DATA] = *qtwiOrig_item;
            }
        }

    }
    saveProject(qtwiCurrent_item);
}

/*
 ***************************************************
 * 函数名：slot_Input3D()
 * 作用：输入3D数据，设置树形图，
 * 输入：无
 * 返回：无
 * 编写：蔡华鹏 20/4/6
 * 修改：蔡华鹏 20/4/6 将两种情况分开处理改为一种处理方式，通过统一获得父节点的方式整合
 * 备注：每次读取需要做的事：添加树形图，map值添加
 ****************************************************
 */
void MainWindow::slot_Input3D()
{
    QTreeWidgetItem *qtwiCurrent_item = ui->treeWidget->currentItem();//获取当前选中item
    QModelIndex qmiCurrent_index = ui->treeWidget->currentIndex();
    if(qtwiCurrent_item == nullptr || qmiCurrent_index.parent().parent().isValid())//没选中任何项目或者选择了底层节点
    {
        QMessageBox::warning(this, tr("Tips"), tr("请先选择要导入数据的工程"),QMessageBox::tr("好的"));
        return;
    }
    input3d_dialog = new IInput3D(this);
    input3d_dialog->setModal(true);//模态
    input3d_dialog->show();
    if(input2d_dialog->exec() == QDialog::Accepted)
    {
        QStringList qslInput_list = input2d_dialog->get_Inputfile_list();//获取输入列表
        if(qslInput_list.count() == 0)
        {
            return;//判断有无文件，无则退出
        }
        /**********添加树形图，新建文件夹（此时仅有地震数据节点）************/
        QTreeWidgetItem *qtwiCurrent_parent_item = qtwiCurrent_item->parent();//当前节点的父节点
        if(qtwiCurrent_parent_item != nullptr)//选中不是父节点
        {
            qtwiCurrent_item = toolkit->getTopParent(qtwiCurrent_item);//获得父节点
            qmiCurrent_index = toolkit->getTopParent(qmiCurrent_index);
        }
        /*****************通过文件名判断是否有已经打开的文件，有则将list中相关项删除，避免再新建节点****************/
        for(int nLayer1 = 0;nLayer1 < qtwiCurrent_item->childCount();++nLayer1)//sgy级
        {
            for(int nLayer2 = 0;nLayer2 < qtwiCurrent_item->child(nLayer1)->childCount();++nLayer2)//文件级
            {
                QString qsNode_name = qtwiCurrent_item->child(nLayer1)->child(nLayer2)->text(0);//节点名称
                for(int nCount = 0;nCount < qslInput_list.count();++nCount)
                {
                    QString qsInputFile = qslInput_list.at(nCount);//找出每一个地址
                    QFileInfo qfiInputFile_info = QFileInfo(qsInputFile);//用于找出地址对应文件名
                    QString qsInputFile_name = qfiInputFile_info.baseName();//找出文件名
                    if(qsNode_name == qsInputFile_name)//文件已经打开
                    {
                        qslInput_list.removeAt(nCount);
                    }
                }
            }
        }
        /************将数据的路径，即list写入工程下的路径文件中***********/
        QMap<QString, QString>::iterator it_Propath = qmTreeWidget_path_gv.find(qtwiCurrent_item->text(0));//查找工程路径
        if(it_Propath.key() == qtwiCurrent_item->text(0) && it_Propath != qmTreeWidget_path_gv.end())
        {
            QString qsPropath = it_Propath.value();//工程路径
            QString qsPathFile = qsPropath + "/" + defPATHFILE_NAME;//路径文件的路径
            QFile qfPathFile(qsPathFile);//打开文件
            qfPathFile.open(QFile::WriteOnly | QIODevice::Text | QIODevice::Append);
            QTextStream out(&qfPathFile);
            for(int nCount = 0; nCount < qslInput_list.count(); nCount++)
            {
                out<<qslInput_list.at(nCount)<<endl;
                out.flush();
            }
            qfPathFile.close();
        }
        /*******************在工程下建相关文件和树形图节点***********************/
        QTreeWidgetItem *qtwiSeismic_item = qtwiCurrent_item->child(0);//"地震数据"节点，如果有其他节点，可以根据这里来更改
        for(int nNum_list = 0; nNum_list < qslInput_list.count(); nNum_list++)//在子节点下建立节点，每一个文件单独建一个节点
        {
            QString qsInputFile = qslInput_list.at(nNum_list);//找出每一个地址
            QFileInfo qfiInputFile_info = QFileInfo(qsInputFile);//用于找出地址对应文件名
            QString qsInputFile_name = qfiInputFile_info.baseName();//找出文件名
            QTreeWidgetItem *qtwiNewSeismicFile_item = new QTreeWidgetItem(qtwiSeismic_item,QStringList()<<qsInputFile_name);//添加地震数据文件的节点
            qtwiNewSeismicFile_item->setData(0,Qt::UserRole,"node");
            QString qsCurrent_item_name = qmiCurrent_index.data().toString();//获取工程名，这里是父节点，所以直接使用这个名字就行，如果不是父节点，就需要先找到父节点，再获取工程名
            qmTreeWidget_item_gv[qsCurrent_item_name+ defSEISMIC_DATA +qsInputFile_name] = *qtwiNewSeismicFile_item;//这里不论是打开还是新建，都需要吧item保存在map里，以便其他时间使用;

            /********新建文件夹***********/
            QMap<QString,QString>::iterator it_path = qmTreeWidget_path_gv.find(qsCurrent_item_name + defSEISMIC_DATA);
            if(it_path != qmTreeWidget_path_gv.end() && it_path.key() == qsCurrent_item_name + defSEISMIC_DATA)//找到工程名下面的“地震数据”节点的路径
            {
                QDir qdData_path(it_path.value());//创建以数据名命名的文件夹
                qdData_path.mkdir(qsInputFile_name);
                QString qsData_path = qdData_path.absoluteFilePath(qsInputFile_name);//获取新建文件夹的绝对路径以便保存
                qmTreeWidget_path_gv[qsCurrent_item_name + defSEISMIC_DATA + qsInputFile_name] = qsData_path;//每一次新建或者打开文件夹后都需要保存在map里面，每一次删除也需要把map里对应的内容删除

                QString qsNavi_name = defNAVI_FILE_NAME;
                QDir qdUnderDataNavi_path(qsData_path);//新建文件夹下的路径
                QString qsUnderDataNavi_path = qdUnderDataNavi_path.absoluteFilePath(qsNavi_name);//获取导航数据文件路径//用于画底图
                QFile qfNavigation(qsUnderDataNavi_path);//创建
//                write_naviData(qfNavigation,qsInputFile,true);//把导入的数据的路径传给函数处理
                qmTreeWidget_path_gv[qsCurrent_item_name + defSEISMIC_DATA + qsInputFile_name + defNAVI_DATA] = qsUnderDataNavi_path;


                QString qsOrig_name = defORIG_FILE_NAME;
                QDir qdUnderDataOrig_path(qsData_path);//新建文件夹下的路径
                QString qsUnderDataOrig_path = qdUnderDataOrig_path.absoluteFilePath(qsOrig_name);//获取原始数据文件路径//其中保存数据的路径，用于以后使用
                QFile qfOriginal(qsUnderDataOrig_path);//创建
                write_Path(qfOriginal,qsInputFile,true);//创建对应的文件，并写入路径
                qmTreeWidget_path_gv[qsCurrent_item_name + defSEISMIC_DATA + qsInputFile_name + defORIG_DATA] = qsUnderDataOrig_path;

                /**********新建文件的节点***********/
                QTreeWidgetItem *qtwiNavi_item = new QTreeWidgetItem(qtwiNewSeismicFile_item,QStringList(defNAVI_DATA));//导航数据节点
                QTreeWidgetItem *qtwiOrig_item = new QTreeWidgetItem(qtwiNewSeismicFile_item,QStringList(defORIG_DATA));//原始数据节点
                qtwiNavi_item->setData(0,Qt::UserRole,"node");
                qtwiOrig_item->setData(0,Qt::UserRole,"node");
                qmTreeWidget_item_gv[qsCurrent_item_name+ defSEISMIC_DATA +qsInputFile_name + defNAVI_DATA] = *qtwiNavi_item;
                qmTreeWidget_item_gv[qsCurrent_item_name+ defSEISMIC_DATA +qsInputFile_name + defORIG_DATA] = *qtwiOrig_item;
            }
        }

    }
    saveProject(qtwiCurrent_item);

}


/*
 ***************************************************
 * 函数名：write_origData()
 * 作用：向文件写入原始数据的地址
 * 输入：文件类和路径
 * 返回：无
 * 编写：vgGwen 18/5/20
 * 修改：
 ****************************************************
 */
void MainWindow::write_Path(QFile &file,QString &path,bool toD)
{
    if(toD)
    {
        file.open(QFile::WriteOnly | QIODevice::Text);
        QTextStream qtsWrite(&file);
        qtsWrite<<path;//写入原始数据的路径
        file.close();
    }

}

/*
 ***************************************************
 * 函数名：slot_GFCompute2D()
 * 作用：打开2D引导滤波界面
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：vgGwen 18/6/21 不再使用全局变量，数据路径直接从文件中读取
 ****************************************************
 */
void MainWindow::slot_GFCompute2D()
{
    QStringList qslFilelist;//用于保存工程中存在的数据的路径
    QTreeWidgetItem *qtwiCurrentItem = ui->treeWidget->currentItem();
    if(qtwiCurrentItem != NULL )//选中了一个Item
    {
        QTreeWidgetItem *qtwiTopItem = toolkit->getTopParent(qtwiCurrentItem);//获得工程节点
        QMap<QString, QString>::iterator it_Propath = qmTreeWidget_path_gv.find(qtwiTopItem->text(0));//查找工程路径
        if(it_Propath.key() == qtwiTopItem->text(0) && it_Propath != qmTreeWidget_path_gv.end())
        {
            QString qsPropath = it_Propath.value();//工程路径
            QString qsPathFile = qsPropath + "/" + defPATHFILE_NAME;//路径文件的路径
            QFile qfPathFile(qsPathFile);//打开文件
            qfPathFile.open(QFile::ReadOnly | QIODevice::Text);
            QTextStream qtsStream(&qfPathFile);
            QString qsTmp_str;//存临时数据
            while(!qtsStream.atEnd())
            {
                qsTmp_str = qtsStream.readLine();//一行一行的读取
                qslFilelist.append(qsTmp_str);
            }

            qfPathFile.close();
        }

        if(QMessageBox::Yes == QMessageBox::question(this,tr("2D数据引导滤波处理"),tr("是否使用已经导入的文件列表？"),QMessageBox::Yes | QMessageBox::No))//判断用户是否使用已经导入的文件列表
        {
            iodisplay_doalog = new IODisplay(this,qslFilelist);
            iodisplay_doalog->show();//显示
        }
        else
        {
            iodisplay_doalog = new IODisplay(this);
            iodisplay_doalog->show();//显示
        }
    }
    else
    {
        iodisplay_doalog = new IODisplay(this);
        iodisplay_doalog->show();//显示
    }
}

/*
 ***************************************************
 * 函数名：slot_GFCompute3D()
 * 作用：打开3D引导滤波界面
 * 输入：无
 * 返回：无
 * 编写：蔡华鹏 20/4/6
 * 修改：蔡华鹏 20/4/6 不再使用全局变量，数据路径直接从文件中读取
 ****************************************************
 */
void MainWindow::slot_GFCompute3D()
{

    QStringList qslFilelist;//用于保存工程中存在的数据的路径
    QTreeWidgetItem *qtwiCurrentItem = ui->treeWidget->currentItem();
    if(qtwiCurrentItem != NULL )//选中了一个Item
    {
        QTreeWidgetItem *qtwiTopItem = toolkit->getTopParent(qtwiCurrentItem);//获得工程节点
        QMap<QString, QString>::iterator it_Propath = qmTreeWidget_path_gv.find(qtwiTopItem->text(0));//查找工程路径
        if(it_Propath.key() == qtwiTopItem->text(0) && it_Propath != qmTreeWidget_path_gv.end())
        {
            QString qsPropath = it_Propath.value();//工程路径
            QString qsPathFile = qsPropath + "/" + defPATHFILE_NAME;//路径文件的路径
            QFile qfPathFile(qsPathFile);//打开文件
            qfPathFile.open(QFile::ReadOnly | QIODevice::Text);
            QTextStream qtsStream(&qfPathFile);
            QString qsTmp_str;//存临时数据
            while(!qtsStream.atEnd())
            {
                qsTmp_str = qtsStream.readLine();//一行一行的读取
                qslFilelist.append(qsTmp_str);
            }

            qfPathFile.close();
        }

        if(QMessageBox::Yes == QMessageBox::question(this,tr("3D数据引导滤波处理"),tr("是否使用已经导入的文件列表？"),QMessageBox::Yes | QMessageBox::No))//判断用户是否使用已经导入的文件列表
        {
            iodisplay3d = new IODisplay3d(this);
            iodisplay3d->show();//显示
        }
        else
        {
            iodisplay3d = new IODisplay3d(this);
            iodisplay3d->show();//显示
        }
    }
    else
    {
        iodisplay3d = new IODisplay3d(this);
        iodisplay3d->show();//显示
    }
}


/*
 ***************************************************
 * 函数名：slot_DFCompute2D()
 * 作用：打开2D扩散滤波界面
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
//void MainWindow::slot_DFCompute2D()
//{
//    qDebug()<<"DF2D"<<endl;
//}

/*
 ***************************************************
 * 函数名：slot_DFCompute3D()
 * 作用：打开3D扩散滤波界面
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/25
 * 修改：
 ****************************************************
 */
//void MainWindow::slot_DFCompute3D()
//{
//    iodisplay3d = new IODisplay3d(this);
//    iodisplay3d->show();
//}

/*
 ***************************************************
 * 函数名：slot_About()
 * 作用：打开版权界面
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/4/29
 * 修改：
 ****************************************************
 */
void MainWindow::slot_About()
{

    about_dialog = new AboutDialog(this);
    about_dialog->setModal(true);//模态
    about_dialog->setFixedSize(531,311);//让窗口大小不变
    about_dialog->show();//显示
}
/*
 ***************************************************
 * 函数名：slot_TreeWidget_Right_Clicked
 * 作用：树形图鼠标右键，不同级节点右键菜单和操作不同
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/5/4
 * 修改：
 ****************************************************
 */
void MainWindow::slot_TreeWidget_Right_Clicked(const QPoint pos)
{
    //获取当前选中项，判断是哪一级节点
    //根据哪一级节点设置菜单，连接信号槽
    QModelIndex qmiCurrent_index = ui->treeWidget->currentIndex();
    QTreeWidgetItem *qtwiCurrent_item = ui->treeWidget->itemAt(pos);//返回当前选中项
    if(qtwiCurrent_item == NULL) return;//没选中
    /*******设置菜单栏选项*********/
    QAction qaQuit_Pro_action(tr("退出工程"),this);
    QAction qaSave_Pro_action(tr("保存工程"),this);
    QAction qaInput_2D_action(tr("导入地震数据"),this);
//    QAction qaInput_3D_action(tr("导入3D地震数据"),this);
    QAction qaDelete_file_action(tr("删除文件"),this);
    QAction qaOpenFile_action(tr("打开文件"),this);
    QAction qaUnfold_action(tr("展开该列表"),this);
    QAction qaFold_action(tr("折叠该列表"),this);
    /***************连接信号槽**************/
    connect(&qaQuit_Pro_action,SIGNAL(triggered(bool)),this,SLOT(slot_QuitProject()));
    connect(&qaSave_Pro_action,SIGNAL(triggered(bool)),this,SLOT(slot_SaveProject()));
    connect(&qaInput_2D_action,SIGNAL(triggered(bool)),this,SLOT(slot_Input2D()));
//    connect(&qaInput_3D_action,SIGNAL(triggered(bool)),this,SLOT(slot_Input3D()));

    connect(&qaUnfold_action,SIGNAL(triggered(bool)),this,SLOT(slot_FoldOr_not()));
    connect(&qaFold_action,SIGNAL(triggered(bool)),this,SLOT(slot_FoldOr_not()));

    connect(&qaOpenFile_action,SIGNAL(triggered(bool)),this,SLOT(slot_DoubleClick()));//和双击打开文件使用同一个槽函数
    connect(&qaDelete_file_action,SIGNAL(triggered(bool)),this,SLOT(slot_Delete_file()));
    /************添加菜单栏//判断哪一级************/
    int nLayersOf_item;//用于判断当前节点是哪一级节点
    nLayersOf_item = toolkit->getNumberOf_layers(qtwiCurrent_item,0);
    switch(nLayersOf_item)
    {
    case 0://工程节点
        {
        QMenu qmPro_Right_menu(this);
        qmPro_Right_menu.addAction(&qaSave_Pro_action);
        qmPro_Right_menu.addAction(&qaQuit_Pro_action);
        qmPro_Right_menu.addAction(&qaInput_2D_action);
//        qmPro_Right_menu.addAction(&qaInput_3D_action);

        if(ui->treeWidget->isExpanded(qmiCurrent_index))//根据树形图当前状态来决定显示折叠或者展开与否//已经展开在，则只能显示折叠
        {
            qmPro_Right_menu.addAction(&qaFold_action);;
        }
        else
        {
            qmPro_Right_menu.addAction(&qaUnfold_action);
        }

        qmPro_Right_menu.exec(QCursor::pos());//在当前鼠标位置显示
        break;
        }
    case 1://"地震数据"级
        {
        QMenu qmLayer1_Right_menu(this);
        qmLayer1_Right_menu.addAction(&qaInput_2D_action);
//        qmLayer1_Right_menu.addAction(&qaInput_3D_action);

        if(ui->treeWidget->isExpanded(qmiCurrent_index))//根据树形图当前状态来决定显示折叠或者展开与否//已经展开在，则只能显示折叠
        {
            qmLayer1_Right_menu.addAction(&qaFold_action);;
        }
        else
        {
            qmLayer1_Right_menu.addAction(&qaUnfold_action);
        }

        qmLayer1_Right_menu.exec(QCursor::pos());//在当前鼠标位置显示
        break;
        }
    case 2:
        {
        QMenu qmLayer2_Right_menu(this);
        qmLayer2_Right_menu.addAction(&qaDelete_file_action);

        if(ui->treeWidget->isExpanded(qmiCurrent_index))//根据树形图当前状态来决定显示折叠或者展开与否//已经展开在，则只能显示折叠
        {
            qmLayer2_Right_menu.addAction(&qaFold_action);;
        }
        else
        {
            qmLayer2_Right_menu.addAction(&qaUnfold_action);
        }

        qmLayer2_Right_menu.exec(QCursor::pos());//在当前鼠标位置显示
        break;
        }
    case 3:
    {
        QMenu qmLayer3_Right_menu(this);
        qmLayer3_Right_menu.addAction(&qaOpenFile_action);
        qmLayer3_Right_menu.exec(QCursor::pos());//在当前鼠标位置显示
        break;
    }
    default: {break;}
    }
}

/*
 ***************************************************
 * 函数名：slot_FoldOr_not
 * 作用：折叠或者展开子节点
 * 输入：
 * 返回：无
 * 编写：vgGwen 18/5/4
 * 修改：
 ****************************************************
 */
void MainWindow::slot_FoldOr_not()
{
    QModelIndex qmiCurrent_index = ui->treeWidget->currentIndex();
    if(ui->treeWidget->isExpanded(qmiCurrent_index))
    {
        ui->treeWidget->collapse(qmiCurrent_index);//折叠
    }
    else
    {
        ui->treeWidget->expand(qmiCurrent_index);//展开
    }


}

/*
 ***************************************************
 * 函数名：slot_DoubleClick
 * 作用：双击打开文件
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/5/4
 * 修改：
 ****************************************************
 */
void MainWindow::slot_DoubleClick()
{
    QTreeWidgetItem *qtwiCurrent_item = ui->treeWidget->currentItem();
    int nLayers = toolkit->getNumberOf_layers(qtwiCurrent_item,0);
    if(nLayers == 3)
    {
        //选页面
        if(qtwiCurrent_item->text(0) == defNAVI_DATA)//道头信息节点
        {
            QString qsKey = get_key(qtwiCurrent_item,defORIG_DATA);
            QMap<QString,QString>::Iterator it_path = qmTreeWidget_path_gv.find(qsKey);//读取文件路径（是文本文件的路径不是原始数据的路径）
            if(it_path != qmTreeWidget_path_gv.end() && it_path.key() == qsKey)
            {
                QString qsPath = it_path.value();
                QFile file(qsPath);
                file.open(QIODevice::ReadOnly | QIODevice::Text);
                QTextStream stream(&file);
                QString fileName = stream.readLine();

                srw.readSegy(fileName);
           }

            ui->tabWidget->setEnabled(true);
            ui->tabWidget->setCurrentIndex(1);
            ui->radioButton_overView->setChecked(true);
            on_radioButton_overView_clicked();
            ui->widget_2->showTraceHead(srw);

       }
       else if(qtwiCurrent_item->text(0) == defORIG_DATA)//原始数据节点
       {
            ui->tabWidget->setCurrentIndex(0);//跳到剖面图界面
            QString qsKey = get_key(qtwiCurrent_item,qtwiCurrent_item->text(0));
            QMap<QString,QString>::Iterator it_path = qmTreeWidget_path_gv.find(qsKey);//读取文件路径（是文本文件的路径不是原始数据的路径）
            if(it_path != qmTreeWidget_path_gv.end() && it_path.key() == qsKey)
            {
                QString qsPath = it_path.value();
                QFile file(qsPath);
                file.open(QIODevice::ReadOnly | QIODevice::Text);
                QTextStream stream(&file);
                QString fileName = stream.readLine();

                srw.readSegy(fileName);
                ui->tabWidget->setEnabled(true);
                if(srw.is2D())
                {
                    ui->widget_baseMap->hide();
                }
                else {
                    paint_BaseMap(srw);//3D数据需要绘制底图
                    ui->widget_baseMap->show();
                }
                showProfile(srw,0,mapType,presetColor);//绘制剖面图,默认:inline,变面积图
           }
       }
    }
}
/*
 ***************************************************
 * 函数名：slot_Delete_file
 * 作用：节点上删除数据文件
 * 输入：无
 * 返回：无
 * 编写：vgGwen 18/5/4
 * 修改：
 * 备注：需要完成的工作：1.删除节点信息，删除xml文件相关信息（下次打开时不能有这个节点），删除map中信息（先判断是否彻底删除文件，测地删除文件还需要将相关文件和文件夹删除）,删除路径文件中的路径
 ****************************************************
 */
void MainWindow::slot_Delete_file()
{
    QTreeWidgetItem* qtwiCurrentItem = ui->treeWidget->currentItem();//获取当前选中的Item
    QTreeWidgetItem *qtwiCurrentProject = toolkit->getTopParent(qtwiCurrentItem);//提前获得当前工程以便保存，后面会删除该节点指针，到时候找不到工程
    QModelIndex qmiCurrentIndex = ui->treeWidget->currentIndex();
    QString qsCurrentKey = get_key(qtwiCurrentItem,qtwiCurrentItem->text(0));//获得键值
    QString qsCurrentKey_child1 = get_key(qtwiCurrentItem->child(0),qtwiCurrentItem->child(0)->text(0));
    QString qsCurrentKey_child2 = get_key(qtwiCurrentItem->child(1),qtwiCurrentItem->child(1)->text(0));
    QString qsCurrentKey_child3 = get_key(qtwiCurrentItem->child(2),qtwiCurrentItem->child(2)->text(0));

//    ui->statusBar->showMessage(tr("修改工程文件信息"),100);
    /*删除xml文件里的相应节点，让下一次打开时不再显示该节点及其子节点*/
    deleteNode_xml(qtwiCurrentItem);
    //判断用户是退出工程还是删除工程
    ckmessagebox_dialog = new ICkMessageBox(this,tr("Tips"),tr("是否删除文件？（不会删除原始数据文件）"),tr("删除文件夹"));
    ckmessagebox_dialog->set_CheckBox_default(false);//默认复选框不选中
    ckmessagebox_dialog->setModal(true);
    ckmessagebox_dialog->show();
//    ui->statusBar->showMessage(tr("删除相关资源"),100);
    if(ckmessagebox_dialog->exec() == QDialog::Accepted)//dialog已经退出
    {
        bool bOk = false;
        bool bCancel = false;
        bool bCheckBox = false;
        ckmessagebox_dialog->get_Status(bOk,bCancel,bCheckBox);//读取状态的值
        if(bOk == true && bCheckBox == true)//这种情况下需要删除相关文件夹
        {
            /*删除相关文件夹*/
            QMap<QString,QString>::Iterator it_path = qmTreeWidget_path_gv.find(qsCurrentKey);
            if(it_path != qmTreeWidget_path_gv.end() && it_path.key() == qsCurrentKey)
            {
                bool bTmp = toolkit->DeleteDirectory(it_path.value());
                if(bTmp == false)//删除失败
                {
                    QMessageBox::warning(this,tr("Tips"),tr("删除文件夹失败，请手动删除该文件的文件夹。"),QMessageBox::tr("好的"));
                }
            }
            /*删除路径文件中的相关信息*/
            QMap<QString, QString>::iterator it_Propath = qmTreeWidget_path_gv.find(qtwiCurrentProject->text(0));//查找工程路径
            if(it_Propath.key() == qtwiCurrentProject->text(0) && it_Propath != qmTreeWidget_path_gv.end())
            {
                QString qsPropath = it_Propath.value();//工程路径
                QString qsPathFile = qsPropath + "/" + defPATHFILE_NAME;//路径文件的路径
                toolkit->deleteOnelineInFile(qtwiCurrentItem->text(0),qsPathFile);
            }

            /*删除map信息*/
            qmTreeWidget_path_gv.remove(qsCurrentKey);
            qmTreeWidget_item_gv.remove(qsCurrentKey);
            qmTreeWidget_path_gv.remove(qsCurrentKey_child1);
            qmTreeWidget_item_gv.remove(qsCurrentKey_child1);
            qmTreeWidget_path_gv.remove(qsCurrentKey_child2);
            qmTreeWidget_item_gv.remove(qsCurrentKey_child2);
            qmTreeWidget_path_gv.remove(qsCurrentKey_child3);
            qmTreeWidget_item_gv.remove(qsCurrentKey_child3);
            /*删除节点*/
            delete qtwiCurrentItem->parent()->takeChild(qmiCurrentIndex.row());
        }
        else if(bOk == true && bCheckBox == false)//不用删除相关文件夹
        {
            /*删除路径文件中的相关信息*/
            QMap<QString, QString>::iterator it_Propath = qmTreeWidget_path_gv.find(qtwiCurrentProject->text(0));//查找工程路径
            if(it_Propath.key() == qtwiCurrentProject->text(0) && it_Propath != qmTreeWidget_path_gv.end())
            {
                QString qsPropath = it_Propath.value();//工程路径
                QString qsPathFile = qsPropath + "/" + defPATHFILE_NAME;//路径文件的路径
                toolkit->deleteOnelineInFile(qtwiCurrentItem->text(0),qsPathFile);
            }


            /*删除map信息*/
            qmTreeWidget_path_gv.remove(qsCurrentKey);
            qmTreeWidget_item_gv.remove(qsCurrentKey);
            qmTreeWidget_path_gv.remove(qsCurrentKey_child1);
            qmTreeWidget_item_gv.remove(qsCurrentKey_child1);
            qmTreeWidget_path_gv.remove(qsCurrentKey_child2);
            qmTreeWidget_item_gv.remove(qsCurrentKey_child2);
            qmTreeWidget_path_gv.remove(qsCurrentKey_child3);
            qmTreeWidget_item_gv.remove(qsCurrentKey_child3);
            /*删除节点*/
            delete qtwiCurrentItem->parent()->takeChild(qmiCurrentIndex.row());
        }
       else if(bCheckBox == true)//取消，返回
        {
            return ;
        }
    }
    saveProject(qtwiCurrentProject);//删除节点后自动保存一次工程
//    ui->statusBar->showMessage(tr("删除完成"),1000);

}
/*
 ***************************************************
 * 函数名：get_key
 * 作用：获取节点在map中的key值
 * 输入：节点和节点名称
 * 返回：key值
 * 编写：vgGwen 18/5/4
 * 修改：
 ****************************************************
 */
QString MainWindow::get_key(QTreeWidgetItem *item,QString name)
{
    QString qsItem_name = name;
    QTreeWidgetItem *qtwiItem_parent = nullptr;
    if(item->parent() == nullptr)
    {
        return qsItem_name;
    }
    else
    {
        qtwiItem_parent = item->parent();
        qsItem_name = qtwiItem_parent->text(0) + qsItem_name;
        qsItem_name = get_key(qtwiItem_parent,qsItem_name);//递归查找上一级
    }
}
/*
 ***************************************************
 * 函数名：deleteNode_xml
 * 作用：删除与树形图节点对应的xml文件节点
 * 输入：要删除的树形图节点
 * 返回：
 * 编写：vgGwen 18/5/4
 * 修改：
 ****************************************************
 */
void MainWindow::deleteNode_xml(QTreeWidgetItem *item)
{
    QTreeWidgetItem* project_item = toolkit->getTopParent(item);//获得工程节点
    QMap<QString,QString>::iterator it_path_pro = qmTreeWidget_path_gv.find(project_item->text(0));
    if(it_path_pro != qmTreeWidget_path_gv.end() && it_path_pro.key() == project_item->text(0))
    {
         writexml = new IWXml();
         QString qsPath = it_path_pro.value()+"/"+defNODEXML_NAME;
         writexml->DeleteXml(qsPath,item);
    }
}


/*
 ***************************************************
 * 函数名：saveProject
 * 作用：保存工程，供退出工程和保存工程等操作调用：写xml文件
 * 输入：要保存的工程节点的item和index
 * 返回：无
 * 编写：vgGwen 18/5/15
 * 修改：
 ****************************************************
 */
void MainWindow::saveProject(QTreeWidgetItem *item)
{
    //将节点信息写入xml文件
//    ui->statusBar->showMessage(tr("正在保存工程..."),1000);
    QTreeWidgetItem *qtwiCurrentProject = toolkit->getTopParent(item);
    writexml = new IWXml();
    QMap<QString,QString>::iterator it_path_pro = qmTreeWidget_path_gv.find(qtwiCurrentProject->text(0));
    if(it_path_pro != qmTreeWidget_path_gv.end() && it_path_pro.key() == qtwiCurrentProject->text(0))
    {
        QString path = it_path_pro.value()+"/"+defNODEXML_NAME;
        writexml->WriteXml(path,qtwiCurrentProject);
    }
//    ui->statusBar->showMessage(tr("保存完成..."),1000);
}

/**
 * @brief MainWindow::showProfile	在自定义部件中显示2D剖面图
 * @param path 要显示的文件的绝对路径
 */
void MainWindow::showProfile(const SegyReadWrite& s, int lineType, int mapType, int presetColor)
{
    ui->widget_paint2d->openSGY(s,lineType,mapType,presetColor);
}


/*
 ***************************************************
 * 函数名：paintBaseMap
 * 作用：绘制底图
 * 输入：导航数据文件路径
 * 返回：
 * 编写：vgGwen 18/7/2
 * 修改：
 ****************************************************
 */
void MainWindow::paint_BaseMap(const SegyReadWrite& s)
{
    ui->widget_baseMap->paintBaseMap(s);

}

void MainWindow::on_radioButton_toggled(bool checked)
{
    if(checked)
    {
        this->mapType = 1;
        ui->widget_paint2d->swithImage(1);
    }
    else {
        this->mapType = 0;
        ui->widget_paint2d->swithImage(0);
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->widget_paint2d->resore();
}

void MainWindow::on_slider_sliderReleased()
{
    int k = ui->slider->value();
    ui->widget_paint2d->zoomInOut(k);
}

void MainWindow::on_pushButton_zoomRect_clicked()
{
    ui->widget_paint2d->zoomRect();
}

void MainWindow::on_toggleProfile(int lineType, int num)
{
    if(lineType ==0)
    {
        showProfile(srw.getInLine(num),0,mapType,presetColor);
    }
    else if(lineType == 1)
    {
        showProfile(srw.getXLine(num),1,mapType,presetColor);
    }
    else if(lineType ==2)
    {
        showProfile(srw.getTLine(num),2,mapType,presetColor);
    }
}

void MainWindow::on_radioButton_overView_clicked()
{
    BinaryHeadtable->hide();

    ptxt->clear();
    ui->widget_overView->layout()->addWidget(ptxt);
    ptxt->appendPlainText("file:     " + srw.getInputFile());
    if(srw.getDataType()==1)
    {
        ptxt->appendPlainText("format:   " + QString::number(srw.getDataType())+"\n\t"+"IBM float 32bit");
    }
    else {
        ptxt->appendPlainText("format:   " + QString::number(srw.getDataType())+"\n\t" + "IEEE float 32bit");
    }
    ptxt->appendPlainText("traces count:   " + QString::number(srw.getTraceCount()));
    ptxt->appendPlainText("samples count:  " + QString::number(srw.getSamplePerTrace()));
    ptxt->appendPlainText("interval: " + QString::number(srw.getInterval()));
    ptxt->appendPlainText("--------------------------------------");
    ptxt->appendPlainText("first FFID:" + QString::number(srw.getXlineBegin()));
    ptxt->appendPlainText("last FFID:" + QString::number(srw.getXlineEnd()));
    ptxt->appendPlainText("first trace number:" + QString::number(srw.getInlineBegin()));
    ptxt->appendPlainText("last trace number:" + QString::number(srw.getInlineEnd()));
    ptxt->appendPlainText("time begin:" + QString::number(srw.getTimeBegin()));
    ptxt->appendPlainText("time end:" + QString::number(srw.getTimeEnd()));

    if(ptxt->isHidden())
    {
        ptxt->show();
    }
}

void MainWindow::on_tabWidget_tabBarClicked(int index)
{
    if(index ==1)
    {
        on_radioButton_overView_clicked();
        ui->widget_2->showTraceHead(srw);
    }else{
        ui->radioButton_overView->setChecked(true);
            if(srw.is2D())
            {
                ui->widget_baseMap->hide();
            }
            else {
                ui->widget_baseMap->show();
                paint_BaseMap(srw);//3D数据需要绘制底图
            }
            showProfile(srw,0,0);//绘制剖面图
    }
}

void MainWindow::on_radioButton_EBCDIC_clicked()
{
    BinaryHeadtable->hide();

    ptxt->clear();
    ui->widget_overView->layout()->addWidget(ptxt);
    for(int i=0;i<40;i++){
        QString text="";
        for(int j=0; j<80; j++)
        {
            text.append(srw.getEBCDIC()[i*80+j]);
        }
        ptxt->appendPlainText(text);
    }
//    ptxt->appendPlainText(QString(srw.getEBCDIC()[0]));
//    ptxt->appendPlainText(QString(srw.getEBCDIC()[1]));
//    ptxt->appendPlainText(QString(srw.getEBCDIC()[2]));

    if(ptxt->isHidden())
    {
        ptxt->show();
    }
}

void MainWindow::slot_fileData()
{
    // ui->groupBox_2
}

void MainWindow::on_radioButton_BinaryHead_clicked()
{
    ptxt->hide();

    BinaryHeadtable->clear();
    BinaryHeadtable->setColumnCount(4);
    BinaryHeadtable->setRowCount(27);
    ui->widget_overView->layout()->addWidget(BinaryHeadtable);

    QStringList header;  //QString类型的List容器
    header<<"Index"<<"Value"<<"bytes"<<"Description";
    BinaryHeadtable->setHorizontalHeaderLabels(header);
    BinaryHeadtable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    //自适应列宽,根据内容显示列
    BinaryHeadtable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    BinaryHeadtable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    BinaryHeadtable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    BinaryHeadtable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    BinaryHeadtable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    BinaryHeadtable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

//    BinaryHeadtable->horizontalHeader()->resizeSection(0, 30);
//    BinaryHeadtable->horizontalHeader()->resizeSection(1, 30);
//    BinaryHeadtable->horizontalHeader()->resizeSection(2, 30);
//    BinaryHeadtable->horizontalHeader()->resizeSection(3, 80);
//    BinaryHeadtable->verticalHeader()->setSectionResizeMode(QHeaderView::Interactive);

//    BinaryHeadtable->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
//    BinaryHeadtable->verticalHeader()->setDefaultSectionSize(10);
    BinaryHeadtable->verticalHeader()->setVisible(false);
    BinaryHeadtable->resizeColumnsToContents();
    BinaryHeadtable->resizeRowsToContents();
    BinaryHeadtable->show();

   // srw.getBinaryHead();

    int BinaryHeadValue[27]={srw.getBinaryHead()->jobid,srw.getBinaryHead()->lino,
                             srw.getBinaryHead()->reno,srw.getBinaryHead()->ntrpr,
                             srw.getBinaryHead()->nart,srw.getBinaryHead()->hdt,
                             srw.getBinaryHead()->dto,srw.getBinaryHead()->hns,
                             srw.getBinaryHead()->nso,srw.getBinaryHead()->format,
                             srw.getBinaryHead()->fold,srw.getBinaryHead()->tsort,
                             srw.getBinaryHead()->vscode,srw.getBinaryHead()->hsfs,
                             srw.getBinaryHead()->hsfe,srw.getBinaryHead()->hslen,
                             srw.getBinaryHead()->hstyp,srw.getBinaryHead()->schn,
                             srw.getBinaryHead()->hstas,srw.getBinaryHead()->hstae,
                             srw.getBinaryHead()->htatyp,srw.getBinaryHead()->hcorr,
                             srw.getBinaryHead()->bgrcv,srw.getBinaryHead()->rcvm,
                             srw.getBinaryHead()->mfeet,srw.getBinaryHead()->polyt,
                             srw.getBinaryHead()->vpol};

    QString BinaryHeadDes[27][2]={{"job identification number","1-4"},{"line number","5-8"},
                                  {"reel number","9-12"},{"number of data traces per record","13-14"},
                                  {"number of auxiliary traces per record","15-16"},{"sample interval in micro secs for this reel","17-18"},
                                  {"same for original field recording","19-20"},{"number of samples per trace for this reel","21-22"},
                                  {"same for original field recording","23-24"},{"data sample format code","25-26"},
                                  {"CDP fold expected per CDP ensemble","27-28"},{"trace sorting code","29-30"},
                                  {"vertical sum code","31-32"},{"sweep frequency at start ","33-34"},
                                  {"sweep frequency at end","35-36"},{"sweep length (ms)","37-38"},
                                  {"sweep type code","39-40"},{"trace number of sweep channel","41-42"},
                                  {" sweep trace taper length at start if tapered","43-44"},{"sweep trace taper length at end","45-46"},
                                  {"sweep trace taper type code","47-48"},{"correlated data traces code","49-50"},
                                  {"binary gain recovered code","51-52"},{"amplitude recovery method code","53-54"},
                                  {"measurement system code","55-56"},{"impulse signal polarity code","57-58"},
                                  {" vibratory polarity code","59-60"}
                                 };

    for(int i=0;i<27;i++){
        BinaryHeadtable->setItem(i,0,new QTableWidgetItem(QString::number(i+1)));
        BinaryHeadtable->setItem(i,1,new QTableWidgetItem(QString::number(BinaryHeadValue[i])));
        BinaryHeadtable->setItem(i,2,new QTableWidgetItem(BinaryHeadDes[i][1]));
        BinaryHeadtable->setItem(i,3,new QTableWidgetItem(BinaryHeadDes[i][0]));
    }

    if(BinaryHeadtable->isHidden())
    {
        BinaryHeadtable->show();
    }
}

//void MainWindow::slot_trace_data()
//{

//    if(ui->tabWidget_2->currentIndex()==0){
//        //当此时是道头页面
//        qDebug()<<"道头页面";
//        qDebug()<<srw.getInlineEnd();

//       // table=new QTableWidget(ui->tab_3);
//        table->setColumnCount(4);
//        table->setRowCount(srw.getTracePerLine());
//        table->setHorizontalHeaderLabels(QStringList()<<"道号"<<"字节范围"<<"x坐标"<<"y坐标");
//        table->show();
//        table->setGeometry(QRect(100,100,401,241));
//        table->verticalHeader()->setDefaultSectionSize(40);
//        int linebegin=srw.getInlineBegin();
////        ui->spinBox_2->setValue(linebegin);
////        ui->spinBox_2->setMinimum(1);
////        ui->spinBox_2->setMaximum(5000);
//        qDebug()<<srw.getInlineEnd();
//        qDebug()<<srw.getTracePerLine();

//        for(int i=0;i<table->rowCount();i++)
//        {
//            QString a1 = QString("%1").arg(srw.getXlineBegin()+i);
//            table->setItem(i,0, new QTableWidgetItem(a1));
//            QString a2=QString::fromStdString("13-16");
//            table->setItem(i,1, new QTableWidgetItem(a2));
//            QString a3 = QString("%1").arg((srw.getTraceHead())[i].sx);
//            table->setItem(i,2, new QTableWidgetItem(a3));
//            QString a4 = QString("%1").arg((srw.getTraceHead())[i].sy);
//            table->setItem(i,3, new QTableWidgetItem(a4));

//         }
//    }else{
//        //当此时是道数据
////        qDebug()<<"道数据";
////        table=new QTableWidget(ui->tab_4);
////        QVBoxLayout *vBoxLayout=new QVBoxLayout;
////        vBoxLayout->addWidget(ui->spinBox);
////        vBoxLayout->addWidget(table);
////        ui->tab_4->setLayout(vBoxLayout);

////        ui->spinBox->setRange(1,srw.getTraceCount());

//        QHeaderView *header1 = table->verticalHeader();
//        header1->setHidden(true);

//        table->setRowCount(srw.getSamplePerTrace());
//        table->setColumnCount(3);
//        QStringList header;  //QString类型的List容器
//        header<<"Index"<<"Times(ms)"<<"Sample";
//        table->setHorizontalHeaderLabels(header);
//        table->resizeColumnsToContents();
//        table->resizeRowsToContents();
//        table->setEditTriggers(QAbstractItemView::NoEditTriggers);

//        table->show();


//      //  int num = ui->spinBox->text().toInt();

//        for(int i=0;i<srw.getSamplePerTrace();i++){
//            QString a1 = QString("%1").arg(srw.getTimeBegin()+srw.getInterval()*i/1000);
//            QString a2 =QString::number((srw.getData())[num-1][i], 'f', 3);
//            table->setItem(i,0,new QTableWidgetItem(QString::number(i)));
//            table->setItem(i,1,new QTableWidgetItem(a1));
//            table->setItem(i,2,new QTableWidgetItem(a2));

//        }

//    }
//}

//void MainWindow::slot_change_traceData()
//{
//    table->clear();
//  //  int num = ui->spinBox->text().toInt();
//    for(int i=0;i<srw.getSamplePerTrace();i++){
//        QString a1 = QString("%1").arg(srw.getTimeBegin()+srw.getInterval()*i/1000);
//       // QString a2 = QString::number((srw.getData())[num-1][i], 'f', 3);
//        table->setItem(i,0,new QTableWidgetItem(QString::number(i)));
//        table->setItem(i,1,new QTableWidgetItem(a1));
//        table->setItem(i,2,new QTableWidgetItem(QString::number((srw.getData())[num-1][i], 'f', 3)));

//    }
//}

void MainWindow::colorChanged()
{
    ui->widget_paint2d->colorChanged();
}

void MainWindow::presetColorChanged(int i)
{
    ui->widget_paint2d->presetColorChanged(i);
    this->presetColor = i;
}




//截图工具
void MainWindow::on_action_jietu_triggered()
{
        //获取全屏截图
            QPixmap p = QPixmap::grabWindow(QApplication::desktop()->winId());
            //打开文件对话框
            QString fileName = QFileDialog::getSaveFileName(this, "文件另存为","",tr("Config Files (*.bmp)"));
            //保存截图
            if(fileName.length() > 0 && p.save(fileName,"bmp"))
            {
                QMessageBox::information(this, "提示", "保存成功!",QMessageBox::Ok);
            }


//    CaptureScreen *captureHelper = new CaptureScreen();
//    connect(captureHelper,SIGNAL(signalCompleteCature(QPixmap)),this,SLOT(onCompleteCature(QPixmap)));
//    captureHelper->show();
}
////截图功能，接上
//void MainWindow::onCompleteCature(QPixmap captureImage)
//{

//    ui->label->setPixmap(captureImage);
//}

//打开大文件分割ui
void MainWindow::slot_filesplit()
{
    filesplit = new FileSplit;
    filesplit->show();
}

//打开带通滤波器ui
void MainWindow::slot_bandpass()
{
    bandpass = new BandPass();
    bandpass->show();
}
