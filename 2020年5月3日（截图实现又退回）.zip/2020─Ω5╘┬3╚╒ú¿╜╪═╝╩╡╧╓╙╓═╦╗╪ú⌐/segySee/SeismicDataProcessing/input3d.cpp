#include "input3d.h"
#include "ui_input3d.h"

IInput3D::IInput3D(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::IInput3D)
{
    ui->setupUi(this);
}

IInput3D::~IInput3D()
{
    delete ui;
}
