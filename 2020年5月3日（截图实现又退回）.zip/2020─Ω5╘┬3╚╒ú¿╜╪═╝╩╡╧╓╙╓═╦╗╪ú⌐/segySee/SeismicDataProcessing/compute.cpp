#include "compute.h"

Compute::Compute()
{

}

Compute::~Compute()
{

}

void Compute::compute_guidedfilter2d(char *filename_input, char *filename_output, int length_x, int length_t)
{
        //guidedfilter2d_profile(filename_input,filename_output,length_x,length_t);
}
