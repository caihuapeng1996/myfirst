#ifndef TYPECONVERSION_H
#define TYPECONVERSION_H
#include <QString>
#include <QTextCodec>

class ITypeConversion
{
public:
    ITypeConversion();
    //数据转换
    QString int2qstring(int num);//十进制表示
    int qstring2int(QString string);

    QString float2qstring(float num);
    float qstring2float(QString string);

    QString char2qstring(char *ch);
    char *qstring2char(QString string);

    std::string qstring2cstring(QString string);

    //解决中文路径问题
    //windows本地编码gb2312转utf-8
    static std::string codec(QString s);
};

#endif // TYPECONVERSION_H
