/*
 *用于2D数据的引导滤波处理
 *
 */
#ifndef IODISPLAY_H
#define IODISPLAY_H
#pragma once

#include <QMainWindow>
#include <QFileDialog>
#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QTextStream>
#include <QString>
#include <QTextCodec>//中文支持

#include <QWidget>
#include <QCloseEvent>
#include <QMessageBox>
#include <QDateTime>
#include <QTimer>
#include <stdio.h>
#include <string>


#include "Gwen_use/GST.h"
#include "../libUtil/alloc.h"
#include "Gwen_use/sgy.h"
#include "aboutdialog.h"
#include "mythread.h"
#include "typeconversion.h"
#include "tempfiledialog.h"

#define TEMP_FILE_NAME  "/tempfile.txt"

class TempFileDialog;

extern QString Temp_File_Name;//存储临时文件路径

namespace Ui {
class IODisplay;
}

class IODisplay : public QMainWindow
{
    Q_OBJECT

public:
    explicit IODisplay(QWidget *parent = 0);
    IODisplay(QWidget *parent ,QStringList &);//用于接收参数的构造函数
    ~IODisplay();

    void setOutputFileName(QString input, QString &input_name, QString &output, QString &output_name, QString &output_path, QString &output_suffix);//设置输出文件的文件名

    void clearex();//清除上一次文件残留下的显示信息

    void sleep(unsigned int msec);//延时函数 毫秒

    void readproperty(QString filename, int &nt, int &nx, int &ddt, float &dt, QString &filetype);//读取输入文件中的数据属性

    void createFile(QString filePath,QString fileName);

    void fillInform(QString input, bool &flag);//填充面板信息

    void ComputeOperation();//计算操作

    void closeEvent(QCloseEvent * event);//关闭程序事件

    bool isDirExist(QString fullPath);//判断路径是否存在

    QString getTempDir();//获取临时文件路径


signals:
    void signal_mainSendPara(QString input, QString output, int x, int t);//向子程序传参数

private slots:

    void slot_mainGetString(QString tep);//接受子线程信号的槽函数

    void slot_mainGetNum(int num);//接受子线程信号的槽函数

//    void slot_mainGetOver();//接受子线程的计算结束信号

    void on_OpenFile_pushButton_clicked();//用于显示已存在文件

    void on_StartCompute_pushButton_clicked();//start键

    void slot_clearOutput();//clear键

    void on_About_pushButton_clicked();//about

    void slot_CancelCompute();//Cancel

    void on_LengthX_SpainBox_valueChanged(int arg1);

    void on_LengthT_SpainBox_valueChanged(int arg1);

    void slot_CheckTempFile();//查看临时文件

private:
    Ui::IODisplay *ui;
    AboutDialog *aboutdialog;//版权界面
    TempFileDialog *tempfiledialog;//打开临时文件
    Mythread *mythread;//线程
    ITypeConversion *mytypeconversion;//数据转换

    QString Input_File;//输入文件
    QString Input_Name_qstr;//输入文件名
    QString Output_FileSuffix_qstr;//输出名后缀
    QString Input_FileName_qstr;//记录输入文件的绝对路径+文件名
    QString Output_FileName_qstr;//记录输出文件的绝对路径+文件名

    QStringList Input_FileList;//输入文件列表
    QString Output_FilePath_qstr;//记录绝对路径
    std::string Input_FileName_cstr;//c++类型的string，用于打开文件
    int FileList_count_i = 0 ;//文件列表长度
    int File_count_i = 0;//记录计算到第几个文件
    bool first_read = true;//判断是不是第一次读取

};

#endif // IODISPLAY_H
