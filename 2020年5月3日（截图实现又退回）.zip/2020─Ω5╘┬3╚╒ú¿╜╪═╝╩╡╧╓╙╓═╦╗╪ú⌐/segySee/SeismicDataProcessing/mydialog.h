#include <QDialog>
#include <QCheckBox>
#include <QWidget>
#include <QTableWidget>
#include <QStandardItemModel>

#include "amenddialog.h"

#ifndef MYDIALOG_H
#define MYDIALOG_H
namespace Ui {
    class MyDialog;
}

class MyDialog : public QDialog
{
    Q_OBJECT

public:
    explicit MyDialog(QWidget *parent = 0);
    ~MyDialog();

private:
    Ui::MyDialog *ui;
    QTableWidget *tableWidget;//实例一个表格
    AmendDialog *amend;

    int traceNum = 0;
    QString inputfile;
    ITypeConversion *mytypeconversion;
    int nxx;//每一个测线的地震道数
    int nyy;//测线数
    int start_time;//记录的起始时间
    int end_time;//记录的终止时间
    int scanTraces = 20;
    QStringList inputList;

    void readproperty(QString filename, int &nt, int &nx, float &dt, QString &filetype,int &first_trace_FFID, int &last_trace_FFID, int &first_trace_CDP, int &last_trace_CDP,int &start_time, int &end_time);

signals:
    void signal_sendTraces(int traces,QString inputFile,int flag);

private slots:
    void slot_childGetTracePar(QStringList fileList);
    void on_scan_button_clicked();
    void primeInfo();//显示基本信息
    void on_cancel_button_clicked();
    void on_showAllTraces_pushButton_clicked();
};

#endif // MYDIALOG_H
