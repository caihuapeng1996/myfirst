#ifndef FILESPLIT_H
#define FILESPLIT_H

#include <QWidget>
#include <QMainWindow>
#include <QLineEdit>
#include <QComboBox>
#include <QProgressBar>
#include <QTextEdit>
#include <QPushButton>
#include <QFile>
#include <QThread>
#include <QMouseEvent>
#include <QPoint>

namespace Ui {
class FileSplit;
}

class FileSplit : public QWidget
{
    Q_OBJECT

public:
    explicit FileSplit(QWidget *parent = 0);
    ~FileSplit();

protected:
    virtual void mousePressEvent(QMouseEvent* e);    // 鼠标的单击事件
    virtual void mouseMoveEvent(QMouseEvent* e);    // 鼠标的移动事件
    virtual void mouseReleaseEvent(QMouseEvent* e);  // 鼠标的单击释放事件

protected slots:
    void onClickOpen();
    void onClickScan();
    void onClickStart();
    void onHandleUpdate(int value);
    void onHandleAppend(const QString& appendText);

private:
    Ui::FileSplit *ui;
    QLineEdit *mFilePathEdit;
    QLineEdit *mDirPathEdit;
    QLineEdit *mFileSizeEdit;
    QComboBox *mSizeUnit;
    QProgressBar *mProgressBar;
    QTextEdit *mTextEdit;
    QPushButton *mBtnStart;
    QPoint mPressPos;
    bool mPressed;
};

//工作线程
class WorkerThread : public QThread
{
    Q_OBJECT

public:
    explicit WorkerThread(QObject  *parent = 0);
    ~WorkerThread();

public:
    void setWorkerParams(const QString& filePath,const QString& dirPath,const qint64 splitSize);

protected:
    virtual void run() Q_DECL_OVERRIDE;

 signals:
    void signalUpdate(int value);
    void signalAppend(const QString& appendText);

private:
    QString mFilePath;
    QString mDirPath;
    qint64 mSplitSize;
};

#endif // FILESPLIT_H
