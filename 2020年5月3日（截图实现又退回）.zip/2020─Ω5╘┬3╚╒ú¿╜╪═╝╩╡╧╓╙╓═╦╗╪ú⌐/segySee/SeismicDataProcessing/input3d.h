#ifndef INPUT3D_H
#define INPUT3D_H

#include <QDialog>

namespace Ui {
class IInput3D;
}

class IInput3D : public QDialog
{
    Q_OBJECT

public:
    explicit IInput3D(QWidget *parent = 0);
    ~IInput3D();

private:
    Ui::IInput3D *ui;
};

#endif // INPUT3D_H
