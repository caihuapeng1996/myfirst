#ifndef FILESPLITCONFIG_H
#define FILESPLITCONFIG_H

#include <QString>

//窗口的大小
const int CONF_WIN_WIDTH =  640;
const int CONF_WIN_HEIGHT =  500;

//主窗口的外边距
const int CONF_WIN_MARGIN = 0;

//自定义标题窗口的组件间距
const int CONF_WIN_TOP_SPACING = 0;

//到主窗口的边距
const int CONF_DEFAULT_MARGIN = 3;

//自定义标题窗口的标题名称
const QString CONF_WIN_TOP_TITLE = QWidget::tr("FileSplit");

//标签组件上的文字
const QString CONF_LAB_FILE_PATH = QWidget::tr("文件路径:");
const QString CONF_LAB_DIR_PATH = QWidget::tr("保存路径:");
const QString CONF_LAB_SPLIT_SIZE = QWidget::tr("分割大小:");

//按钮上的文字
const QString CONF_BTN_STR_OPEN = QWidget::tr("打开");
const QString CONF_BTN_STR_SCAN = QWidget::tr("浏览");
const QString CONF_BTN_STR_START = QWidget::tr("开始切割");

//文件对话框的标题
const QString CONF_FILE_DIALOG_TITLE = QWidget::tr("请选择文件");
const QString CONF_DIR_DIALOG_TITLE = QWidget::tr("请选择目录");

//每次读取文件的size
const qint64 BUFF_SIZE_KB = 4*1024;    //一个page 4k
const qint64 BUFF_SIZE_MB = 1024*1024; //

#endif // FILESPLITCONFIG_H
