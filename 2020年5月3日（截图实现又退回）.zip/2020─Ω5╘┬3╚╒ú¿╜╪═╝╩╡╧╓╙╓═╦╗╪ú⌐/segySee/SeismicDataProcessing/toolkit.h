#ifndef ITOOLKIT_H
#define ITOOLKIT_H
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QTreeWidget>
#include <QStandardItemModel>
#include "Gwen_use/sgy.h"
#include "../libUtil/alloc.h"
#include "typeconversion.h"

#include <QDebug>


class IToolkit
{
public:
    IToolkit();
    /*文件相关*/
    void deleteOnelineInFile(QString str,QString &filename);

    void deleteOnelineInFile(int nNumLine, QString &filename);//删除文件中的一行

    bool DeleteDirectory(const QString &path);//删除非空文件夹

    /*树形图相关*/
    //QStandardItem *getTopParent(QStandardItem *item);//获得父节点

    QTreeWidgetItem *getTopParent(QTreeWidgetItem *item);

    QModelIndex getTopParent(QModelIndex itemIndex);//获得父节点index

    int getNumberOf_layers(QTreeWidgetItem *item, int layer);//获得节点的级数

    int getNumberOf_layers(QModelIndex &itemIndex, int layer);


private:
    void DeleteOneline(int nNum, QString &strall);//供deleteOnelineInFile()使用
    ITypeConversion *mytypecoversion = NULL;//数据转换
};

#endif // ITOOLKIT_H
